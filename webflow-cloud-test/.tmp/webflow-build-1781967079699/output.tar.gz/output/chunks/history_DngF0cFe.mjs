globalThis.process ??= {};
globalThis.process.env ??= {};
const historyJson = `{
  "state": {
    "watchlist": [],
    "scroll": {
      "horse": 0,
      "horses": 0,
      "riders": 0,
      "years": 0,
      "types": 0,
      "videos": 0
    },
    "competitions": [
      {
        "competitionId": "2043",
        "competitionName": "HAMPTON CLASSIC (2043)",
        "id": "2043",
        "name": "HAMPTON CLASSIC (2043)",
        "startDate": "8/26/2018",
        "endDate": "9/2/2018",
        "start": "2018-08-26T04:00:00.000Z",
        "end": "2018-09-02T04:00:00.000Z",
        "year": 2018,
        "state": "NY",
        "zone": "2",
        "viewUrl": "https://www.usef.org/search/competitions/display/zxF-s31L4w4",
        "sections": [
          {
            "sectionId": "9951",
            "sectionName": "Walk/Trot classes (exempt non-member fee)",
            "classes": [
              {
                "classCode": "886",
                "classTitle": "886 - SHORT STIRRUP EQU 10&U WT, SEC D",
                "classUrl": "https://www.usef.org/search/competitions/class/K3xBmrwgZzk",
                "horse": {
                  "name": "FOGGY NOTION",
                  "usefHorseId": "4620503",
                  "link": "https://www.usef.org/search/horses/display/a5lfQaAcE6I?year=2018"
                },
                "entries": "19",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1260",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "2043",
        "competitionName": "HAMPTON CLASSIC (2043)",
        "id": "2043",
        "name": "HAMPTON CLASSIC (2043)",
        "startDate": "8/25/2019",
        "endDate": "9/1/2019",
        "start": "2019-08-25T04:00:00.000Z",
        "end": "2019-09-01T04:00:00.000Z",
        "year": 2019,
        "state": "NY",
        "zone": "2",
        "viewUrl": "https://www.usef.org/search/competitions/display/CuE-56CfiiA",
        "sections": [
          {
            "sectionId": "3100",
            "sectionName": "MISC. HUNTER (No points earned)",
            "classes": [
              {
                "classCode": "787",
                "classTitle": "787 - SHORT STIRRUP EQU 10&U WTC, SEC C",
                "classUrl": "https://www.usef.org/search/competitions/class/jPknX1w8sQA",
                "horse": {
                  "name": "HIGHWINDS DELIGHTFUL",
                  "usefHorseId": "5184187",
                  "link": "https://www.usef.org/search/horses/display/-S19sCzfTBk?year=2019"
                },
                "entries": "24",
                "placing": "8",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1321",
                "dressagePercentage": null
              },
              {
                "classCode": "788",
                "classTitle": "788 - SHORT STIRRUP EQU 10&U FENCES, SEC C",
                "classUrl": "https://www.usef.org/search/competitions/class/bC93CfQq3nA",
                "horse": {
                  "name": "HIGHWINDS DELIGHTFUL",
                  "usefHorseId": "5184187",
                  "link": "https://www.usef.org/search/horses/display/-S19sCzfTBk?year=2019"
                },
                "entries": "24",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1321",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "9951",
            "sectionName": "Walk/Trot classes (exempt non-member fee)",
            "classes": [
              {
                "classCode": "786",
                "classTitle": "786 - SHORT STIRRUP EQU 10&U WT, SEC C",
                "classUrl": "https://www.usef.org/search/competitions/class/i2-6b-SeRJY",
                "horse": {
                  "name": "HIGHWINDS DELIGHTFUL",
                  "usefHorseId": "5184187",
                  "link": "https://www.usef.org/search/horses/display/-S19sCzfTBk?year=2019"
                },
                "entries": "24",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1321",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "1094",
        "competitionName": "SAGAPONACK HORSE SHOW II (1094)",
        "id": "1094",
        "name": "SAGAPONACK HORSE SHOW II (1094)",
        "startDate": "8/7/2019",
        "endDate": "8/7/2019",
        "start": "2019-08-07T04:00:00.000Z",
        "end": "2019-08-07T04:00:00.000Z",
        "year": 2019,
        "state": "NY",
        "zone": "2",
        "viewUrl": "https://www.usef.org/search/competitions/display/2cq-X84PPJ0",
        "sections": [
          {
            "sectionId": "3100",
            "sectionName": "MISC. HUNTER (No points earned)",
            "classes": [
              {
                "classCode": "17",
                "classTitle": "17 - LIPHA BEGINNER/PRE-EQUITATION, W/T/C",
                "classUrl": "https://www.usef.org/search/competitions/class/VSdLlPuHc8U",
                "horse": {
                  "name": "HIGHWINDS DELIGHTFUL",
                  "usefHorseId": "5184187",
                  "link": "https://www.usef.org/search/horses/display/-S19sCzfTBk?year=2019"
                },
                "entries": "11",
                "placing": "5",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "463",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "9951",
            "sectionName": "Walk/Trot classes (exempt non-member fee)",
            "classes": [
              {
                "classCode": "15",
                "classTitle": "15 - LIPHA BEGINNER/PRE-EQUITATION, W/T",
                "classUrl": "https://www.usef.org/search/competitions/class/pIVxY6QH3f8",
                "horse": {
                  "name": "HIGHWINDS DELIGHTFUL",
                  "usefHorseId": "5184187",
                  "link": "https://www.usef.org/search/horses/display/-S19sCzfTBk?year=2019"
                },
                "entries": "8",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "463",
                "dressagePercentage": null
              },
              {
                "classCode": "16",
                "classTitle": "16 - LIPHA BEGINNER/PRE-EQUITATION, W/T",
                "classUrl": "https://www.usef.org/search/competitions/class/bWzT_DgnK04",
                "horse": {
                  "name": "HIGHWINDS DELIGHTFUL",
                  "usefHorseId": "5184187",
                  "link": "https://www.usef.org/search/horses/display/-S19sCzfTBk?year=2019"
                },
                "entries": "8",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "463",
                "dressagePercentage": null
              },
              {
                "classCode": "18",
                "classTitle": "18 - LIPHA BEGINNER/PRE-EQUITATION, W/T-1 XRAIL",
                "classUrl": "https://www.usef.org/search/competitions/class/K690f163ulM",
                "horse": {
                  "name": "HIGHWINDS DELIGHTFUL",
                  "usefHorseId": "5184187",
                  "link": "https://www.usef.org/search/horses/display/-S19sCzfTBk?year=2019"
                },
                "entries": "8",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "463",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "3",
        "competitionName": "OLD SALEM FARM DECEMBER (3)",
        "id": "3",
        "name": "OLD SALEM FARM DECEMBER (3)",
        "startDate": "12/24/2019",
        "endDate": "12/29/2019",
        "start": "2019-12-24T05:00:00.000Z",
        "end": "2019-12-29T05:00:00.000Z",
        "year": 2019,
        "state": "NY",
        "zone": "2",
        "viewUrl": "https://www.usef.org/search/competitions/display/jE7XqrncVoc",
        "sections": [
          {
            "sectionId": "3100",
            "sectionName": "MISC. HUNTER (No points earned)",
            "classes": [
              {
                "classCode": "11",
                "classTitle": "11 - SHORT STIRRUP WALK -TROT-CANTER",
                "classUrl": "https://www.usef.org/search/competitions/class/C6vW_tOBanw",
                "horse": {
                  "name": "GOOD GOLLY MISS HOLLY",
                  "usefHorseId": "5575483",
                  "link": "https://www.usef.org/search/horses/display/GhUBl3ehoMs?year=2020"
                },
                "entries": "4",
                "placing": "2",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "747",
                "dressagePercentage": null
              },
              {
                "classCode": "12",
                "classTitle": "12 - SHORT STIRRUP CROSS RAILS",
                "classUrl": "https://www.usef.org/search/competitions/class/13g3_MHJcAU",
                "horse": {
                  "name": "GOOD GOLLY MISS HOLLY",
                  "usefHorseId": "5575483",
                  "link": "https://www.usef.org/search/horses/display/GhUBl3ehoMs?year=2020"
                },
                "entries": "2",
                "placing": "2",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "747",
                "dressagePercentage": null
              },
              {
                "classCode": "13",
                "classTitle": "13 - SHORT STIRRUP CROSS RAILS",
                "classUrl": "https://www.usef.org/search/competitions/class/DVva5Fj2g_M",
                "horse": {
                  "name": "GOOD GOLLY MISS HOLLY",
                  "usefHorseId": "5575483",
                  "link": "https://www.usef.org/search/horses/display/GhUBl3ehoMs?year=2020"
                },
                "entries": "2",
                "placing": "1",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "747",
                "dressagePercentage": null
              },
              {
                "classCode": null,
                "classTitle": "AAAA - SHORT STIRRUP EQUITATION - CHAMPIONSHIP",
                "classUrl": "https://www.usef.org/search/competitions/class/eXxiDK2-ONA",
                "horse": {
                  "name": "GOOD GOLLY MISS HOLLY",
                  "usefHorseId": "5575483",
                  "link": "https://www.usef.org/search/horses/display/GhUBl3ehoMs?year=2020"
                },
                "entries": "4",
                "placing": "2",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "747",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "9951",
            "sectionName": "Walk/Trot classes (exempt non-member fee)",
            "classes": [
              {
                "classCode": "10",
                "classTitle": "10 - SHORT STIRRUP WALK -TROT",
                "classUrl": "https://www.usef.org/search/competitions/class/5FHamWA51zg",
                "horse": {
                  "name": "GOOD GOLLY MISS HOLLY",
                  "usefHorseId": "5575483",
                  "link": "https://www.usef.org/search/horses/display/GhUBl3ehoMs?year=2020"
                },
                "entries": "4",
                "placing": "3",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "747",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "965",
        "competitionName": "CHEMUNG COUNTY CLASSIC HORSE SHOW (965)",
        "id": "965",
        "name": "CHEMUNG COUNTY CLASSIC HORSE SHOW (965)",
        "startDate": "7/16/2020",
        "endDate": "7/18/2020",
        "start": "2020-07-16T04:00:00.000Z",
        "end": "2020-07-18T04:00:00.000Z",
        "year": 2020,
        "state": "NY",
        "zone": "2",
        "viewUrl": "https://www.usef.org/search/competitions/display/CuXpJsDmI3Y",
        "sections": [
          {
            "sectionId": "5702",
            "sectionName": "OPPORTUNITY CLASS",
            "classes": [
              {
                "classCode": "515",
                "classTitle": "515 - Opportunity Crossrail Hunter U/S",
                "classUrl": "https://www.usef.org/search/competitions/class/r6tjDQVXxxo",
                "horse": {
                  "name": "GOOD GOLLY MISS HOLLY",
                  "usefHorseId": "5575483",
                  "link": "https://www.usef.org/search/horses/display/GhUBl3ehoMs?year=2020"
                },
                "entries": "5",
                "placing": "2",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "117",
                "dressagePercentage": null
              },
              {
                "classCode": "516",
                "classTitle": "516 - Opportunity Crossrail Hunter NTE 18",
                "classUrl": "https://www.usef.org/search/competitions/class/au1Rz7DXrEw",
                "horse": {
                  "name": "GOOD GOLLY MISS HOLLY",
                  "usefHorseId": "5575483",
                  "link": "https://www.usef.org/search/horses/display/GhUBl3ehoMs?year=2020"
                },
                "entries": "5",
                "placing": "3",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "117",
                "dressagePercentage": null
              },
              {
                "classCode": "517",
                "classTitle": "517 - Opportunity Crossrail Hunter NTE 18",
                "classUrl": "https://www.usef.org/search/competitions/class/i-zQ6K1fOgw",
                "horse": {
                  "name": "GOOD GOLLY MISS HOLLY",
                  "usefHorseId": "5575483",
                  "link": "https://www.usef.org/search/horses/display/GhUBl3ehoMs?year=2020"
                },
                "entries": "5",
                "placing": "3",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "117",
                "dressagePercentage": null
              },
              {
                "classCode": "518",
                "classTitle": "518 - Opportunity Crossrail Hunter NTE 18",
                "classUrl": "https://www.usef.org/search/competitions/class/gmXZNhYo2Ao",
                "horse": {
                  "name": "GOOD GOLLY MISS HOLLY",
                  "usefHorseId": "5575483",
                  "link": "https://www.usef.org/search/horses/display/GhUBl3ehoMs?year=2020"
                },
                "entries": "5",
                "placing": "4",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "117",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "3589",
        "competitionName": "OLD SALEM FARM SEPTEMBER (3589)",
        "id": "3589",
        "name": "OLD SALEM FARM SEPTEMBER (3589)",
        "startDate": "8/29/2020",
        "endDate": "8/30/2020",
        "start": "2020-08-29T04:00:00.000Z",
        "end": "2020-08-30T04:00:00.000Z",
        "year": 2020,
        "state": "NY",
        "zone": "2",
        "viewUrl": "https://www.usef.org/search/competitions/display/p_tIQWtcHvU",
        "sections": [
          {
            "sectionId": "3100",
            "sectionName": "MISC. HUNTER (No points earned)",
            "classes": [
              {
                "classCode": "11",
                "classTitle": "11 - SHORT STIRRUP WALK TROT CANTER",
                "classUrl": "https://www.usef.org/search/competitions/class/mZYm47DCj08",
                "horse": {
                  "name": "GOOD GOLLY MISS HOLLY",
                  "usefHorseId": "5575483",
                  "link": "https://www.usef.org/search/horses/display/GhUBl3ehoMs?year=2020"
                },
                "entries": "3",
                "placing": "1",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1014",
                "dressagePercentage": null
              },
              {
                "classCode": "12",
                "classTitle": "12 - SHORT STIRRUP CROSS RAILS",
                "classUrl": "https://www.usef.org/search/competitions/class/eqV6CtPUzdw",
                "horse": {
                  "name": "GOOD GOLLY MISS HOLLY",
                  "usefHorseId": "5575483",
                  "link": "https://www.usef.org/search/horses/display/GhUBl3ehoMs?year=2020"
                },
                "entries": "3",
                "placing": "2",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1014",
                "dressagePercentage": null
              },
              {
                "classCode": "13",
                "classTitle": "13 - SHORT STIRRUP CROSS RAILS",
                "classUrl": "https://www.usef.org/search/competitions/class/XgaEN_tYyX4",
                "horse": {
                  "name": "GOOD GOLLY MISS HOLLY",
                  "usefHorseId": "5575483",
                  "link": "https://www.usef.org/search/horses/display/GhUBl3ehoMs?year=2020"
                },
                "entries": "3",
                "placing": "3",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1014",
                "dressagePercentage": null
              },
              {
                "classCode": null,
                "classTitle": "CH1 - SHORT STIRRUP CHAMPIONSHIP",
                "classUrl": "https://www.usef.org/search/competitions/class/-WB9ECBRX1I",
                "horse": {
                  "name": "GOOD GOLLY MISS HOLLY",
                  "usefHorseId": "5575483",
                  "link": "https://www.usef.org/search/horses/display/GhUBl3ehoMs?year=2020"
                },
                "entries": "3",
                "placing": "1",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1014",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "9951",
            "sectionName": "Walk/Trot classes (exempt non-member fee)",
            "classes": [
              {
                "classCode": "10",
                "classTitle": "10 - SHORT STIRRUP WALK TROT",
                "classUrl": "https://www.usef.org/search/competitions/class/ow9QZTJx8os",
                "horse": {
                  "name": "GOOD GOLLY MISS HOLLY",
                  "usefHorseId": "5575483",
                  "link": "https://www.usef.org/search/horses/display/GhUBl3ehoMs?year=2020"
                },
                "entries": "3",
                "placing": "1",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1014",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "464",
        "competitionName": "SMITHTOWN HUNT (464)",
        "id": "464",
        "name": "SMITHTOWN HUNT (464)",
        "startDate": "6/12/2021",
        "endDate": "6/13/2021",
        "start": "2021-06-12T04:00:00.000Z",
        "end": "2021-06-13T04:00:00.000Z",
        "year": 2021,
        "state": "NY",
        "zone": "2",
        "viewUrl": "https://www.usef.org/search/competitions/display/bE04Ou8iSZA",
        "sections": [
          {
            "sectionId": "2701",
            "sectionName": "CHILDRENS HUNTER-PONY",
            "classes": [
              {
                "classCode": "161",
                "classTitle": "161 - Childrens Hunter Pony (Sm/Med) U/S",
                "classUrl": "https://www.usef.org/search/competitions/class/_g8J3aa2WMY",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "9",
                "placing": "2",
                "natlPoints": "0.00",
                "zonePoints": "15.00",
                "backNumber": "92",
                "dressagePercentage": null
              },
              {
                "classCode": "162",
                "classTitle": "162 - Childrens Hunter Pony (Sm/Med) O/F 2'",
                "classUrl": "https://www.usef.org/search/competitions/class/LxIMyV-mjes",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "9",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "92",
                "dressagePercentage": null
              },
              {
                "classCode": "163",
                "classTitle": "163 - Childrens Hunter Pony (Sm/Med) O/F",
                "classUrl": "https://www.usef.org/search/competitions/class/Kpn5fm1VlVw",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "9",
                "placing": "6",
                "natlPoints": "0.00",
                "zonePoints": "10.50",
                "backNumber": "92",
                "dressagePercentage": null
              },
              {
                "classCode": "164",
                "classTitle": "164 - Childrens Hunter Pony (Sm/Med) O/F",
                "classUrl": "https://www.usef.org/search/competitions/class/Ki8sxUwkSdU",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "9",
                "placing": "5",
                "natlPoints": "0.00",
                "zonePoints": "11.00",
                "backNumber": "92",
                "dressagePercentage": null
              },
              {
                "classCode": "403",
                "classTitle": "403 - M&S Children's Hunter Pony Classic COMBINED",
                "classUrl": "https://www.usef.org/search/competitions/class/sU14TkR77FI",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "12",
                "placing": "6",
                "natlPoints": "0.00",
                "zonePoints": "16.88",
                "backNumber": "92",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "340539",
        "competitionName": "PRINCETON SHOW JUMPING MAY III (340539)",
        "id": "340539",
        "name": "PRINCETON SHOW JUMPING MAY III (340539)",
        "startDate": "5/19/2021",
        "endDate": "5/23/2021",
        "start": "2021-05-19T04:00:00.000Z",
        "end": "2021-05-23T04:00:00.000Z",
        "year": 2021,
        "state": "NJ",
        "zone": "2",
        "viewUrl": "https://www.usef.org/search/competitions/display/6VGJaQkjNBk",
        "sections": [
          {
            "sectionId": "2501",
            "sectionName": "PONY HUNTER-SMALL",
            "classes": [
              {
                "classCode": "200",
                "classTitle": "200 - Small Pony Hunter Model",
                "classUrl": "https://www.usef.org/search/competitions/class/KcEolE_SYg4",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "3",
                "placing": "2",
                "natlPoints": "13.00",
                "zonePoints": "8.00",
                "backNumber": "2062",
                "dressagePercentage": null
              },
              {
                "classCode": "201",
                "classTitle": "201 - Small Pony Hunter 2'3 FP",
                "classUrl": "https://www.usef.org/search/competitions/class/QyfH9zl24zA",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "3",
                "placing": "3",
                "natlPoints": "19.00",
                "zonePoints": "11.00",
                "backNumber": "2062",
                "dressagePercentage": null
              },
              {
                "classCode": "202",
                "classTitle": "202 - Small Pony Hunter 2'3 (1st Rd Classic)",
                "classUrl": "https://www.usef.org/search/competitions/class/sjd-PUuW5cs",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "3",
                "placing": "3",
                "natlPoints": "19.00",
                "zonePoints": "11.00",
                "backNumber": "2062",
                "dressagePercentage": null
              },
              {
                "classCode": "203",
                "classTitle": "203 - Small Pony Hunter 2'3",
                "classUrl": "https://www.usef.org/search/competitions/class/09nq09VxJsM",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "3",
                "placing": "3",
                "natlPoints": "19.00",
                "zonePoints": "11.00",
                "backNumber": "2062",
                "dressagePercentage": null
              },
              {
                "classCode": "204",
                "classTitle": "204 - Small Pony Handy Hunter 2'3",
                "classUrl": "https://www.usef.org/search/competitions/class/22JkePkO2uU",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "3",
                "placing": "1",
                "natlPoints": "28.00",
                "zonePoints": "18.00",
                "backNumber": "2062",
                "dressagePercentage": null
              },
              {
                "classCode": "205",
                "classTitle": "205 - Small Pony Hunter U/S",
                "classUrl": "https://www.usef.org/search/competitions/class/8QAv_gP9Qfo",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "3",
                "placing": "2",
                "natlPoints": "23.00",
                "zonePoints": "13.00",
                "backNumber": "2062",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3010",
            "sectionName": "HUNTER PONY CLASSIC",
            "classes": [
              {
                "classCode": "804",
                "classTitle": "804 - $500 Pony Hunter Classic",
                "classUrl": "https://www.usef.org/search/competitions/class/9t9ubVTFAj4",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "17",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "2062",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "748",
        "competitionName": "LONG ISLAND PHA (748)",
        "id": "748",
        "name": "LONG ISLAND PHA (748)",
        "startDate": "5/15/2021",
        "endDate": "5/16/2021",
        "start": "2021-05-15T04:00:00.000Z",
        "end": "2021-05-16T04:00:00.000Z",
        "year": 2021,
        "state": "NY",
        "zone": "2",
        "viewUrl": "https://www.usef.org/search/competitions/display/6Ej0TwMEzpU",
        "sections": [
          {
            "sectionId": "2501",
            "sectionName": "PONY HUNTER-SMALL",
            "classes": [
              {
                "classCode": "21",
                "classTitle": "21 - Pony Hunter Small Model",
                "classUrl": "https://www.usef.org/search/competitions/class/WrpIJVgntaU",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "3",
                "placing": "2",
                "natlPoints": "10.50",
                "zonePoints": "8.00",
                "backNumber": "217",
                "dressagePercentage": null
              },
              {
                "classCode": "22",
                "classTitle": "22 - Small Pony Hunter U/S",
                "classUrl": "https://www.usef.org/search/competitions/class/fdqSbGj5-MI",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "3",
                "placing": "2",
                "natlPoints": "18.00",
                "zonePoints": "13.00",
                "backNumber": "217",
                "dressagePercentage": null
              },
              {
                "classCode": "23",
                "classTitle": "23 - Small Pony Hunter O/F FP",
                "classUrl": "https://www.usef.org/search/competitions/class/neuseS8np9E",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "3",
                "placing": "2",
                "natlPoints": "18.00",
                "zonePoints": "13.00",
                "backNumber": "217",
                "dressagePercentage": null
              },
              {
                "classCode": "24",
                "classTitle": "24 - Small Pony Handy Hunter O/F",
                "classUrl": "https://www.usef.org/search/competitions/class/eLIJbL3TSxo",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "3",
                "placing": "1",
                "natlPoints": "23.00",
                "zonePoints": "18.00",
                "backNumber": "217",
                "dressagePercentage": null
              },
              {
                "classCode": "25",
                "classTitle": "25 - Small Pony Hunter Conformation",
                "classUrl": "https://www.usef.org/search/competitions/class/vKn5fw__vjY",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "3",
                "placing": "2",
                "natlPoints": "18.00",
                "zonePoints": "13.00",
                "backNumber": "217",
                "dressagePercentage": null
              },
              {
                "classCode": null,
                "classTitle": "SPCH - Pony Hunter Small Championship",
                "classUrl": "https://www.usef.org/search/competitions/class/XqSbdodsfQg",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "3",
                "placing": "2",
                "natlPoints": "27.60",
                "zonePoints": "21.60",
                "backNumber": "217",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3010",
            "sectionName": "HUNTER PONY CLASSIC",
            "classes": [
              {
                "classCode": "410",
                "classTitle": "410 - Pony Hunter Classic",
                "classUrl": "https://www.usef.org/search/competitions/class/GgMkDmaIMbU",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "6",
                "placing": "6",
                "natlPoints": "22.75",
                "zonePoints": "16.25",
                "backNumber": "217",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "5062",
        "competitionName": "OLD SALEM FARM FEBRUARY I (5062)",
        "id": "5062",
        "name": "OLD SALEM FARM FEBRUARY I (5062)",
        "startDate": "2/18/2021",
        "endDate": "2/20/2021",
        "start": "2021-02-18T05:00:00.000Z",
        "end": "2021-02-20T05:00:00.000Z",
        "year": 2021,
        "state": "NY",
        "zone": "2",
        "viewUrl": "https://www.usef.org/search/competitions/display/EGD0HNDtlNM",
        "sections": [
          {
            "sectionId": "2701",
            "sectionName": "CHILDRENS HUNTER-PONY",
            "classes": [
              {
                "classCode": "119",
                "classTitle": "119 - SM/MED CHILD PONY",
                "classUrl": "https://www.usef.org/search/competitions/class/qPqTFnh9PNo",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "4",
                "placing": "2",
                "natlPoints": "0.00",
                "zonePoints": "10.00",
                "backNumber": "958",
                "dressagePercentage": null
              },
              {
                "classCode": "120",
                "classTitle": "120 - SM/MED CHILD PONY",
                "classUrl": "https://www.usef.org/search/competitions/class/c2yws9duId4",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "4",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "958",
                "dressagePercentage": null
              },
              {
                "classCode": "121",
                "classTitle": "121 - SM/MED CHILD PONY",
                "classUrl": "https://www.usef.org/search/competitions/class/dT_ZSkGEbGs",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "4",
                "placing": "4",
                "natlPoints": "0.00",
                "zonePoints": "7.00",
                "backNumber": "958",
                "dressagePercentage": null
              },
              {
                "classCode": "122",
                "classTitle": "122 - SM/MED CHILD PONY U/S",
                "classUrl": "https://www.usef.org/search/competitions/class/y5UlZDxrn8E",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "4",
                "placing": "3",
                "natlPoints": "0.00",
                "zonePoints": "8.00",
                "backNumber": "958",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3100",
            "sectionName": "MISC. HUNTER (No points earned)",
            "classes": [
              {
                "classCode": "201",
                "classTitle": "201 - M&S CHILDREN'S CLASSIC (NO PTS DUE TO COMBINATION W/HORSES WITH NO MONEY)",
                "classUrl": "https://www.usef.org/search/competitions/class/2FoBnbFA_vY",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "6",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "958",
                "dressagePercentage": null
              },
              {
                "classCode": "30A",
                "classTitle": "30A - SCHOOLING HUNTER",
                "classUrl": "https://www.usef.org/search/competitions/class/KEXjeki-xnU",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "14",
                "placing": "6",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "958",
                "dressagePercentage": null
              },
              {
                "classCode": "31A",
                "classTitle": "31A - SCHOOLING HUNTER",
                "classUrl": "https://www.usef.org/search/competitions/class/MJzYRHYtR2w",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "14",
                "placing": "4",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "958",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "1023",
        "competitionName": "CAPITAL CHALLENGE HUNTER JUMPER (1023)",
        "id": "1023",
        "name": "CAPITAL CHALLENGE HUNTER JUMPER (1023)",
        "startDate": "10/4/2021",
        "endDate": "10/10/2021",
        "start": "2021-10-04T04:00:00.000Z",
        "end": "2021-10-10T04:00:00.000Z",
        "year": 2021,
        "state": "MD",
        "zone": "3",
        "viewUrl": "https://www.usef.org/search/competitions/display/mMYGjTXn_hk",
        "sections": [
          {
            "sectionId": "2501",
            "sectionName": "PONY HUNTER-SMALL",
            "classes": [
              {
                "classCode": "112",
                "classTitle": "112 - SMALL PONY HUNTER CONFORMATION FP",
                "classUrl": "https://www.usef.org/search/competitions/class/vJ0X2nU8xKk",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "41",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1317",
                "dressagePercentage": null
              },
              {
                "classCode": "113",
                "classTitle": "113 - SMALL PONY HUNTER",
                "classUrl": "https://www.usef.org/search/competitions/class/bXbe8XLcPEI",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "41",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1317",
                "dressagePercentage": null
              },
              {
                "classCode": "114",
                "classTitle": "114 - SMALL PONY HUNTER HANDY STAKE",
                "classUrl": "https://www.usef.org/search/competitions/class/GmGtuNv_VxY",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "41",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1317",
                "dressagePercentage": null
              },
              {
                "classCode": "115",
                "classTitle": "115 - SMALL PONY HUNTER U/S",
                "classUrl": "https://www.usef.org/search/competitions/class/I4aR7DNfmb8",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "41",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1317",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "2043",
        "competitionName": "HAMPTON CLASSIC (2043)",
        "id": "2043",
        "name": "HAMPTON CLASSIC (2043)",
        "startDate": "8/29/2021",
        "endDate": "9/5/2021",
        "start": "2021-08-29T04:00:00.000Z",
        "end": "2021-09-05T04:00:00.000Z",
        "year": 2021,
        "state": "NY",
        "zone": "2",
        "viewUrl": "https://www.usef.org/search/competitions/display/nWs0WR7KxJQ",
        "sections": [
          {
            "sectionId": "2501",
            "sectionName": "PONY HUNTER-SMALL",
            "classes": [
              {
                "classCode": "72",
                "classTitle": "72 - $200 SNAKS FIFTH AVENCHEW SMALL PONY HTR U/S",
                "classUrl": "https://www.usef.org/search/competitions/class/6cYb5gqn2Bg",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "10",
                "placing": "4",
                "natlPoints": "22.00",
                "zonePoints": "16.00",
                "backNumber": "1116",
                "dressagePercentage": null
              },
              {
                "classCode": "73",
                "classTitle": "73 - $500 SNAKS FIFTH AVENCHEW SM PONY HTR CONF 2'3\\" FP",
                "classUrl": "https://www.usef.org/search/competitions/class/yArAgJPWfcc",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "10",
                "placing": "7",
                "natlPoints": "19.00",
                "zonePoints": "13.00",
                "backNumber": "1116",
                "dressagePercentage": null
              },
              {
                "classCode": "74",
                "classTitle": "74 - $500 SNAKS FIFTH AVENCHEW SM PONY HANDY HTR 2'3\\"",
                "classUrl": "https://www.usef.org/search/competitions/class/eKW5B9psme0",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "10",
                "placing": "5",
                "natlPoints": "21.00",
                "zonePoints": "15.00",
                "backNumber": "1116",
                "dressagePercentage": null
              },
              {
                "classCode": "75",
                "classTitle": "75 - $500 SNAKS FIFTH AVENCHEW  SM PONY HUNTER O/F 2'3\\"",
                "classUrl": "https://www.usef.org/search/competitions/class/A9CutTwKbZM",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "10",
                "placing": "7",
                "natlPoints": "19.00",
                "zonePoints": "13.00",
                "backNumber": "1116",
                "dressagePercentage": null
              },
              {
                "classCode": "76",
                "classTitle": "76 - $500 SNAKS FIFTH AVENCHEW  SM PONY HUNTER O/F 2'3\\"",
                "classUrl": "https://www.usef.org/search/competitions/class/AM6EGMAcHFg",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "10",
                "placing": "10",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1116",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3100",
            "sectionName": "MISC. HUNTER (No points earned)",
            "classes": [
              {
                "classCode": "670",
                "classTitle": "670 - CHILD'S EQ LOW/FLAT SEC B",
                "classUrl": "https://www.usef.org/search/competitions/class/sLrw9xmcr7I",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "28",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1116",
                "dressagePercentage": null
              },
              {
                "classCode": "671",
                "classTitle": "671 - CHILD'S EQ LOW/FENCES SEC B",
                "classUrl": "https://www.usef.org/search/competitions/class/FK_UfipP-2c",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "25",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1116",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "6200",
            "sectionName": "U.S. PONY MEDAL",
            "classes": [
              {
                "classCode": "339",
                "classTitle": "339 - MARSHALL & STERLING / USEF PONY MEDAL",
                "classUrl": "https://www.usef.org/search/competitions/class/v-VqGPgJMjc",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "22",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1116",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "322139",
        "competitionName": "USEF PONY FINALS (322139)",
        "id": "322139",
        "name": "USEF PONY FINALS (322139)",
        "startDate": "8/10/2021",
        "endDate": "8/15/2021",
        "start": "2021-08-10T04:00:00.000Z",
        "end": "2021-08-15T04:00:00.000Z",
        "year": 2021,
        "state": "KY",
        "zone": "5",
        "viewUrl": "https://www.usef.org/search/competitions/display/O-1F3CeKf-U",
        "sections": [
          {
            "sectionId": "2501",
            "sectionName": "PONY HUNTER-SMALL",
            "classes": [
              {
                "classCode": "16",
                "classTitle": "16 - SMALL PONY MODEL",
                "classUrl": "https://www.usef.org/search/competitions/class/i96lXYHyebk",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "87",
                "placing": "37",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "787",
                "dressagePercentage": null
              },
              {
                "classCode": "17",
                "classTitle": "17 - SMALL PONY U/S",
                "classUrl": "https://www.usef.org/search/competitions/class/9EgS0vjCLFc",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "87",
                "placing": "14",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "787",
                "dressagePercentage": null
              },
              {
                "classCode": "18",
                "classTitle": "18 - SMALL PONY O/F",
                "classUrl": "https://www.usef.org/search/competitions/class/HOh2Z7K-__Q",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "84",
                "placing": "52",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "787",
                "dressagePercentage": null
              },
              {
                "classCode": "19",
                "classTitle": "19 - SMALL PONY MODEL & U/S",
                "classUrl": "https://www.usef.org/search/competitions/class/T8jOSoxfTAk",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "87",
                "placing": "21",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "787",
                "dressagePercentage": null
              },
              {
                "classCode": "20",
                "classTitle": "20 - SMALL PONY OVERALL RESULTS",
                "classUrl": "https://www.usef.org/search/competitions/class/74BDrqCzP24",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "87",
                "placing": "36",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "787",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "965",
        "competitionName": "CHEMUNG COUNTY CLASSIC HORSE SHOW (965)",
        "id": "965",
        "name": "CHEMUNG COUNTY CLASSIC HORSE SHOW (965)",
        "startDate": "7/22/2021",
        "endDate": "7/24/2021",
        "start": "2021-07-22T04:00:00.000Z",
        "end": "2021-07-24T04:00:00.000Z",
        "year": 2021,
        "state": "NY",
        "zone": "2",
        "viewUrl": "https://www.usef.org/search/competitions/display/ZCaGh4zL5TA",
        "sections": [
          {
            "sectionId": "2701",
            "sectionName": "CHILDRENS HUNTER-PONY",
            "classes": [
              {
                "classCode": "95",
                "classTitle": "95 - Children's Hunter Pony U/S",
                "classUrl": "https://www.usef.org/search/competitions/class/2Jsd_Vw4bX0",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "4",
                "placing": "1",
                "natlPoints": "0.00",
                "zonePoints": "16.00",
                "backNumber": "106",
                "dressagePercentage": null
              },
              {
                "classCode": "96",
                "classTitle": "96 - Children's Hunter Pony FP",
                "classUrl": "https://www.usef.org/search/competitions/class/S7dk_hlFsxg",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "6",
                "placing": "2",
                "natlPoints": "0.00",
                "zonePoints": "12.00",
                "backNumber": "106",
                "dressagePercentage": null
              },
              {
                "classCode": "97",
                "classTitle": "97 - Children's Hunter Pony",
                "classUrl": "https://www.usef.org/search/competitions/class/RGtMbXMJYOg",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "6",
                "placing": "4",
                "natlPoints": "0.00",
                "zonePoints": "9.00",
                "backNumber": "106",
                "dressagePercentage": null
              },
              {
                "classCode": "98",
                "classTitle": "98 - Children's Hunter Pony",
                "classUrl": "https://www.usef.org/search/competitions/class/oMjNr1cO_-0",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "5",
                "placing": "1",
                "natlPoints": "0.00",
                "zonePoints": "16.00",
                "backNumber": "106",
                "dressagePercentage": null
              },
              {
                "classCode": "99",
                "classTitle": "99 - Children's Hunter Pony",
                "classUrl": "https://www.usef.org/search/competitions/class/YuEKJSPO2_Q",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "5",
                "placing": "1",
                "natlPoints": "0.00",
                "zonePoints": "16.00",
                "backNumber": "106",
                "dressagePercentage": null
              },
              {
                "classCode": null,
                "classTitle": "CHCP - Children's Hunter Pony Championship",
                "classUrl": "https://www.usef.org/search/competitions/class/BWryA4xDM-w",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "6",
                "placing": "1",
                "natlPoints": "0.00",
                "zonePoints": "32.00",
                "backNumber": "106",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "9301",
            "sectionName": "CHILDREN/ADULT AMATEUR HUNTER",
            "classes": [
              {
                "classCode": "401",
                "classTitle": "401 - NAL/M&S Children's/Adult Amateur Hunter Classic",
                "classUrl": "https://www.usef.org/search/competitions/class/2d4xXNR4bfQ",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "13",
                "placing": "4",
                "natlPoints": "0.00",
                "zonePoints": "20.00",
                "backNumber": "106",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "9950",
            "sectionName": "Non-member exempted classes",
            "classes": [
              {
                "classCode": "410",
                "classTitle": "410 - Chemung County Hunt and Go Exhibition",
                "classUrl": "https://www.usef.org/search/competitions/class/CMyiqKbNVTU",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "35",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "106",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "6675",
        "competitionName": "MARK TWAIN FESTIVAL (6675)",
        "id": "6675",
        "name": "MARK TWAIN FESTIVAL (6675)",
        "startDate": "7/20/2021",
        "endDate": "7/21/2021",
        "start": "2021-07-20T04:00:00.000Z",
        "end": "2021-07-21T04:00:00.000Z",
        "year": 2021,
        "state": "NY",
        "zone": "2",
        "viewUrl": "https://www.usef.org/search/competitions/display/3zrunE0j_0I",
        "sections": [
          {
            "sectionId": "2701",
            "sectionName": "CHILDRENS HUNTER-PONY",
            "classes": [
              {
                "classCode": "95",
                "classTitle": "95 - Children's Hunter Pony U/S",
                "classUrl": "https://www.usef.org/search/competitions/class/9BvSqiyKzq8",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "4",
                "placing": "4",
                "natlPoints": "0.00",
                "zonePoints": "8.00",
                "backNumber": "106",
                "dressagePercentage": null
              },
              {
                "classCode": "96",
                "classTitle": "96 - Children's Hunter Pony FP",
                "classUrl": "https://www.usef.org/search/competitions/class/TJPZWkdcfAk",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "5",
                "placing": "3",
                "natlPoints": "0.00",
                "zonePoints": "9.00",
                "backNumber": "106",
                "dressagePercentage": null
              },
              {
                "classCode": "97",
                "classTitle": "97 - Children's Hunter Pony",
                "classUrl": "https://www.usef.org/search/competitions/class/QMVZkIONWmc",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "5",
                "placing": "1",
                "natlPoints": "0.00",
                "zonePoints": "15.00",
                "backNumber": "106",
                "dressagePercentage": null
              },
              {
                "classCode": "98",
                "classTitle": "98 - Children's Hunter Pony",
                "classUrl": "https://www.usef.org/search/competitions/class/IhS9buoohJw",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "5",
                "placing": "4",
                "natlPoints": "0.00",
                "zonePoints": "8.00",
                "backNumber": "106",
                "dressagePercentage": null
              },
              {
                "classCode": "99",
                "classTitle": "99 - Childrens Hunter Pony",
                "classUrl": "https://www.usef.org/search/competitions/class/y24pETC4iek",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "5",
                "placing": "3",
                "natlPoints": "0.00",
                "zonePoints": "9.00",
                "backNumber": "106",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "9301",
            "sectionName": "CHILDREN/ADULT AMATEUR HUNTER",
            "classes": [
              {
                "classCode": "401",
                "classTitle": "401 - NAL/M&W Child/Adult Amateur Hunter Classic",
                "classUrl": "https://www.usef.org/search/competitions/class/QUUJoQJJJwM",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "12",
                "placing": "5",
                "natlPoints": "0.00",
                "zonePoints": "17.50",
                "backNumber": "106",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "6674",
        "competitionName": "HUCK FINN CLASSIC (6674)",
        "id": "6674",
        "name": "HUCK FINN CLASSIC (6674)",
        "startDate": "7/17/2021",
        "endDate": "7/18/2021",
        "start": "2021-07-17T04:00:00.000Z",
        "end": "2021-07-18T04:00:00.000Z",
        "year": 2021,
        "state": "NY",
        "zone": "2",
        "viewUrl": "https://www.usef.org/search/competitions/display/9szBco-sgOU",
        "sections": [
          {
            "sectionId": "2701",
            "sectionName": "CHILDRENS HUNTER-PONY",
            "classes": [
              {
                "classCode": "95",
                "classTitle": "95 - Childrens Hunter Pony U/S",
                "classUrl": "https://www.usef.org/search/competitions/class/vAKI3w2RIzo",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "3",
                "placing": "2",
                "natlPoints": "0.00",
                "zonePoints": "9.00",
                "backNumber": "106",
                "dressagePercentage": null
              },
              {
                "classCode": "96",
                "classTitle": "96 - Childrens Hunter Pony FP",
                "classUrl": "https://www.usef.org/search/competitions/class/jkDZI-c6-Xk",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "3",
                "placing": "2",
                "natlPoints": "0.00",
                "zonePoints": "9.00",
                "backNumber": "106",
                "dressagePercentage": null
              },
              {
                "classCode": "97",
                "classTitle": "97 - Childrens Hunter Pony",
                "classUrl": "https://www.usef.org/search/competitions/class/CfbNwf3gS2U",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "3",
                "placing": "2",
                "natlPoints": "0.00",
                "zonePoints": "9.00",
                "backNumber": "106",
                "dressagePercentage": null
              },
              {
                "classCode": null,
                "classTitle": "CPCH - Childrens Hunter Pony Championship",
                "classUrl": "https://www.usef.org/search/competitions/class/VAT3q1_AOl8",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2021"
                },
                "entries": "3",
                "placing": "2",
                "natlPoints": "0.00",
                "zonePoints": "15.60",
                "backNumber": "106",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "1918",
        "competitionName": "WEF 7  (1918)",
        "id": "1918",
        "name": "WEF 7  (1918)",
        "startDate": "2/22/2022",
        "endDate": "2/27/2022",
        "start": "2022-02-22T05:00:00.000Z",
        "end": "2022-02-27T05:00:00.000Z",
        "year": 2022,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/7SLnZoJzXhY",
        "sections": [
          {
            "sectionId": "2701",
            "sectionName": "CHILDRENS HUNTER-PONY",
            "classes": [
              {
                "classCode": "2885",
                "classTitle": "2885 - Small/Medium Children's Hunter Pony U/S (Sec. B)",
                "classUrl": "https://www.usef.org/search/competitions/class/pNUiKozBXzg",
                "horse": {
                  "name": "FARNLEY CORTLAND",
                  "usefHorseId": "5062007",
                  "link": "https://www.usef.org/search/horses/display/XthyNbV9XQc?year=2022"
                },
                "entries": "15",
                "placing": "4",
                "natlPoints": "0.00",
                "zonePoints": "18.00",
                "backNumber": "5854",
                "dressagePercentage": null
              },
              {
                "classCode": "2886",
                "classTitle": "2886 - Small/Medium Children's Hunter Pony (Sec. B)",
                "classUrl": "https://www.usef.org/search/competitions/class/-XLamd_nJpA",
                "horse": {
                  "name": "FARNLEY CORTLAND",
                  "usefHorseId": "5062007",
                  "link": "https://www.usef.org/search/horses/display/XthyNbV9XQc?year=2022"
                },
                "entries": "15",
                "placing": "1",
                "natlPoints": "0.00",
                "zonePoints": "25.00",
                "backNumber": "5854",
                "dressagePercentage": null
              },
              {
                "classCode": "2887",
                "classTitle": "2887 - Small/Medium Children's Hunter Pony (Sec. B)",
                "classUrl": "https://www.usef.org/search/competitions/class/RnSJrkLLBUE",
                "horse": {
                  "name": "FARNLEY CORTLAND",
                  "usefHorseId": "5062007",
                  "link": "https://www.usef.org/search/horses/display/XthyNbV9XQc?year=2022"
                },
                "entries": "15",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "5854",
                "dressagePercentage": null
              },
              {
                "classCode": "2888",
                "classTitle": "2888 - Small/Medium Children's Hunter Pony (Sec. B)",
                "classUrl": "https://www.usef.org/search/competitions/class/fkHREZ_rwxA",
                "horse": {
                  "name": "FARNLEY CORTLAND",
                  "usefHorseId": "5062007",
                  "link": "https://www.usef.org/search/horses/display/XthyNbV9XQc?year=2022"
                },
                "entries": "15",
                "placing": "8",
                "natlPoints": "0.00",
                "zonePoints": "15.50",
                "backNumber": "5854",
                "dressagePercentage": null
              },
              {
                "classCode": null,
                "classTitle": "CSMPCHB - Children's Pony Hunter - Small/Medium (Sec. B) CHAMPIONSHIP",
                "classUrl": "https://www.usef.org/search/competitions/class/_xexrQ7xsDA",
                "horse": {
                  "name": "FARNLEY CORTLAND",
                  "usefHorseId": "5062007",
                  "link": "https://www.usef.org/search/horses/display/XthyNbV9XQc?year=2022"
                },
                "entries": "15",
                "placing": "2",
                "natlPoints": "0.00",
                "zonePoints": "30.00",
                "backNumber": "5854",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "200",
        "competitionName": "WEF 6 EQUESTRIAN SPORT PRODUCTIONS, LLC (200)",
        "id": "200",
        "name": "WEF 6 EQUESTRIAN SPORT PRODUCTIONS, LLC (200)",
        "startDate": "2/16/2022",
        "endDate": "2/20/2022",
        "start": "2022-02-16T05:00:00.000Z",
        "end": "2022-02-20T05:00:00.000Z",
        "year": 2022,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/uZGIhTPgW0E",
        "sections": [
          {
            "sectionId": "2701",
            "sectionName": "CHILDRENS HUNTER-PONY",
            "classes": [
              {
                "classCode": "2881",
                "classTitle": "2881 - Small/Medium Children's Hunter Pony U/S Sec. A",
                "classUrl": "https://www.usef.org/search/competitions/class/FkRUEGWeUGE",
                "horse": {
                  "name": "FARNLEY CORTLAND",
                  "usefHorseId": "5062007",
                  "link": "https://www.usef.org/search/horses/display/XthyNbV9XQc?year=2022"
                },
                "entries": "25",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "5854",
                "dressagePercentage": null
              },
              {
                "classCode": "2882",
                "classTitle": "2882 - Small/Medium Children's Hunter Pony Sec. A",
                "classUrl": "https://www.usef.org/search/competitions/class/xg3BoTabkac",
                "horse": {
                  "name": "FARNLEY CORTLAND",
                  "usefHorseId": "5062007",
                  "link": "https://www.usef.org/search/horses/display/XthyNbV9XQc?year=2022"
                },
                "entries": "25",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "5854",
                "dressagePercentage": null
              },
              {
                "classCode": "2883",
                "classTitle": "2883 - Small/Medium Children's Hunter Pony Sec. A",
                "classUrl": "https://www.usef.org/search/competitions/class/BPsoTlJBjQs",
                "horse": {
                  "name": "FARNLEY CORTLAND",
                  "usefHorseId": "5062007",
                  "link": "https://www.usef.org/search/horses/display/XthyNbV9XQc?year=2022"
                },
                "entries": "25",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "5854",
                "dressagePercentage": null
              },
              {
                "classCode": "2884",
                "classTitle": "2884 - Small/Medium Children's Hunter Pony Sec. A (1st Round Classic)",
                "classUrl": "https://www.usef.org/search/competitions/class/TypEdZH99x0",
                "horse": {
                  "name": "FARNLEY CORTLAND",
                  "usefHorseId": "5062007",
                  "link": "https://www.usef.org/search/horses/display/XthyNbV9XQc?year=2022"
                },
                "entries": "25",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "5854",
                "dressagePercentage": null
              },
              {
                "classCode": "605",
                "classTitle": "605 - $2500 Florida Small/Medium Children's Pony Hunter Classic-TOP 12 RETURN",
                "classUrl": "https://www.usef.org/search/competitions/class/0BUFzwPcGR4",
                "horse": {
                  "name": "FARNLEY CORTLAND",
                  "usefHorseId": "5062007",
                  "link": "https://www.usef.org/search/horses/display/XthyNbV9XQc?year=2022"
                },
                "entries": "46",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "5854",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "1892",
        "competitionName": "WEF 4 (1892)",
        "id": "1892",
        "name": "WEF 4 (1892)",
        "startDate": "2/1/2022",
        "endDate": "2/6/2022",
        "start": "2022-02-01T05:00:00.000Z",
        "end": "2022-02-06T05:00:00.000Z",
        "year": 2022,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/lMNhsTjKaP0",
        "sections": [
          {
            "sectionId": "2701",
            "sectionName": "CHILDRENS HUNTER-PONY",
            "classes": [
              {
                "classCode": "2881B",
                "classTitle": "2881B - Small/Medium Children's Hunter Pony U/S CALI",
                "classUrl": "https://www.usef.org/search/competitions/class/4YCGALvswno",
                "horse": {
                  "name": "FARNLEY CORTLAND",
                  "usefHorseId": "5062007",
                  "link": "https://www.usef.org/search/horses/display/XthyNbV9XQc?year=2022"
                },
                "entries": "15",
                "placing": "4",
                "natlPoints": "0.00",
                "zonePoints": "18.00",
                "backNumber": "5854",
                "dressagePercentage": null
              },
              {
                "classCode": "2882B",
                "classTitle": "2882B - Small/Medium Children's Hunter Pony CALI",
                "classUrl": "https://www.usef.org/search/competitions/class/C6cmVqcEK0I",
                "horse": {
                  "name": "FARNLEY CORTLAND",
                  "usefHorseId": "5062007",
                  "link": "https://www.usef.org/search/horses/display/XthyNbV9XQc?year=2022"
                },
                "entries": "15",
                "placing": "6",
                "natlPoints": "0.00",
                "zonePoints": "16.50",
                "backNumber": "5854",
                "dressagePercentage": null
              },
              {
                "classCode": "2883B",
                "classTitle": "2883B - Small/Medium Children's Hunter Pony CALI",
                "classUrl": "https://www.usef.org/search/competitions/class/cHnzNC_uPcE",
                "horse": {
                  "name": "FARNLEY CORTLAND",
                  "usefHorseId": "5062007",
                  "link": "https://www.usef.org/search/horses/display/XthyNbV9XQc?year=2022"
                },
                "entries": "15",
                "placing": "8",
                "natlPoints": "0.00",
                "zonePoints": "15.50",
                "backNumber": "5854",
                "dressagePercentage": null
              },
              {
                "classCode": "2884B",
                "classTitle": "2884B - Small/Medium Children's Hunter Pony CALI",
                "classUrl": "https://www.usef.org/search/competitions/class/npAViTgzcKk",
                "horse": {
                  "name": "FARNLEY CORTLAND",
                  "usefHorseId": "5062007",
                  "link": "https://www.usef.org/search/horses/display/XthyNbV9XQc?year=2022"
                },
                "entries": "15",
                "placing": "5",
                "natlPoints": "0.00",
                "zonePoints": "17.00",
                "backNumber": "5854",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "1893",
        "competitionName": "WEF 1 (1893)",
        "id": "1893",
        "name": "WEF 1 (1893)",
        "startDate": "1/12/2022",
        "endDate": "1/16/2022",
        "start": "2022-01-12T05:00:00.000Z",
        "end": "2022-01-16T05:00:00.000Z",
        "year": 2022,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/6kou6H7i_aE",
        "sections": [
          {
            "sectionId": "2501",
            "sectionName": "PONY HUNTER-SMALL",
            "classes": [
              {
                "classCode": "2901A",
                "classTitle": "2901A - $100 Small Pony Hunter U/S CALI",
                "classUrl": "https://www.usef.org/search/competitions/class/2-7tQxmHTkE",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2022"
                },
                "entries": "15",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "5859",
                "dressagePercentage": null
              },
              {
                "classCode": "2902B",
                "classTitle": "2902B - $600 Small Pony Hunter CALI",
                "classUrl": "https://www.usef.org/search/competitions/class/aodTO5uehy4",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2022"
                },
                "entries": "15",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "5859",
                "dressagePercentage": null
              },
              {
                "classCode": "2903A",
                "classTitle": "2903A - $500 Small Pony Hunter CALI",
                "classUrl": "https://www.usef.org/search/competitions/class/1SYU7m4i0cw",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2022"
                },
                "entries": "15",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "5859",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3010",
            "sectionName": "HUNTER PONY CLASSIC",
            "classes": [
              {
                "classCode": "401",
                "classTitle": "401 - $500 Small Pony Hunter Classic",
                "classUrl": "https://www.usef.org/search/competitions/class/rPW1LfTp2Do",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2022"
                },
                "entries": "25",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "5859",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "340201",
        "competitionName": "ESP HOLIDAY FINALE (340201)",
        "id": "340201",
        "name": "ESP HOLIDAY FINALE (340201)",
        "startDate": "12/29/2021",
        "endDate": "1/2/2022",
        "start": "2021-12-29T05:00:00.000Z",
        "end": "2022-01-02T05:00:00.000Z",
        "year": 2021,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/hn7ZKuWGC-c",
        "sections": [
          {
            "sectionId": "2501",
            "sectionName": "PONY HUNTER-SMALL",
            "classes": [
              {
                "classCode": "411",
                "classTitle": "411 - Small Pony Hunter U/S",
                "classUrl": "https://www.usef.org/search/competitions/class/AvCmUY--b8w",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2022"
                },
                "entries": "13",
                "placing": "7",
                "natlPoints": "22.00",
                "zonePoints": "16.00",
                "backNumber": "2412",
                "dressagePercentage": null
              },
              {
                "classCode": "412",
                "classTitle": "412 - Small Pony Hunter FP",
                "classUrl": "https://www.usef.org/search/competitions/class/DVz_f84clGg",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2022"
                },
                "entries": "13",
                "placing": "3",
                "natlPoints": "29.00",
                "zonePoints": "21.00",
                "backNumber": "2412",
                "dressagePercentage": null
              },
              {
                "classCode": "413",
                "classTitle": "413 - Small Pony Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/7NBDOnfdR0I",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2022"
                },
                "entries": "12",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "2412",
                "dressagePercentage": null
              },
              {
                "classCode": "414",
                "classTitle": "414 - Small Pony Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/UU__9X2V6Fo",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2022"
                },
                "entries": "13",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "2412",
                "dressagePercentage": null
              },
              {
                "classCode": "415",
                "classTitle": "415 - Small Pony Hunter Handy",
                "classUrl": "https://www.usef.org/search/competitions/class/w0BTU88S2PE",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2022"
                },
                "entries": "13",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "2412",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "322723",
        "competitionName": "HOLIDAY FESTIVAL III (322723)",
        "id": "322723",
        "name": "HOLIDAY FESTIVAL III (322723)",
        "startDate": "12/20/2021",
        "endDate": "12/23/2021",
        "start": "2021-12-20T05:00:00.000Z",
        "end": "2021-12-23T05:00:00.000Z",
        "year": 2021,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/JHpvukqpS3g",
        "sections": [
          {
            "sectionId": "2501",
            "sectionName": "PONY HUNTER-SMALL",
            "classes": [
              {
                "classCode": "411",
                "classTitle": "411 - Small Pony Hunter U/S",
                "classUrl": "https://www.usef.org/search/competitions/class/8sawVltoQac",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2022"
                },
                "entries": "4",
                "placing": "2",
                "natlPoints": "19.00",
                "zonePoints": "14.00",
                "backNumber": "2412",
                "dressagePercentage": null
              },
              {
                "classCode": "412",
                "classTitle": "412 - Small Pony Hunter FP",
                "classUrl": "https://www.usef.org/search/competitions/class/6P03UggPPgs",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2022"
                },
                "entries": "4",
                "placing": "3",
                "natlPoints": "16.00",
                "zonePoints": "12.00",
                "backNumber": "2412",
                "dressagePercentage": null
              },
              {
                "classCode": "413",
                "classTitle": "413 - Small Pony Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/sWq_srGiPWg",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2022"
                },
                "entries": "4",
                "placing": "3",
                "natlPoints": "16.00",
                "zonePoints": "12.00",
                "backNumber": "2412",
                "dressagePercentage": null
              },
              {
                "classCode": "414",
                "classTitle": "414 - Small Pony Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/HEr-B_2T3zs",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2022"
                },
                "entries": "4",
                "placing": "4",
                "natlPoints": "13.00",
                "zonePoints": "10.00",
                "backNumber": "2412",
                "dressagePercentage": null
              },
              {
                "classCode": "415",
                "classTitle": "415 - Small Pony Hunter Handy",
                "classUrl": "https://www.usef.org/search/competitions/class/dcR1RrlF4Ys",
                "horse": {
                  "name": "Q-2",
                  "usefHorseId": "4966146",
                  "link": "https://www.usef.org/search/horses/display/TqFT93I55xY?year=2022"
                },
                "entries": "4",
                "placing": "2",
                "natlPoints": "19.00",
                "zonePoints": "14.00",
                "backNumber": "2412",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "2043",
        "competitionName": "HAMPTON CLASSIC (2043)",
        "id": "2043",
        "name": "HAMPTON CLASSIC (2043)",
        "startDate": "8/28/2022",
        "endDate": "9/4/2022",
        "start": "2022-08-28T04:00:00.000Z",
        "end": "2022-09-04T04:00:00.000Z",
        "year": 2022,
        "state": "NY",
        "zone": "2",
        "viewUrl": "https://www.usef.org/search/competitions/display/QCLZ_vSKF3s",
        "sections": [
          {
            "sectionId": "2701",
            "sectionName": "CHILDRENS HUNTER-PONY",
            "classes": [
              {
                "classCode": "417",
                "classTitle": "417 - $2,500 CHILD HTR CLASSIC-SM/MED PONY",
                "classUrl": "https://www.usef.org/search/competitions/class/wStvsT4T_K8",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "29",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1270",
                "dressagePercentage": null
              },
              {
                "classCode": "90",
                "classTitle": "90 - $200 CHILD HUNTER PONY SM/MED U/S - 2'",
                "classUrl": "https://www.usef.org/search/competitions/class/IGTzxVF0mLw",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "35",
                "placing": "5",
                "natlPoints": "0.00",
                "zonePoints": "37.00",
                "backNumber": "1270",
                "dressagePercentage": null
              },
              {
                "classCode": "91",
                "classTitle": "91 - $200 CHILD HUNTER PONY SM/MED O/F - 2'",
                "classUrl": "https://www.usef.org/search/competitions/class/Pr8eypwVs0Y",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "35",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1270",
                "dressagePercentage": null
              },
              {
                "classCode": "92",
                "classTitle": "92 - $200 CHILD HUNTER PONY SM/MED O/F - 2'",
                "classUrl": "https://www.usef.org/search/competitions/class/Nj2rVAnXvGQ",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "35",
                "placing": "2",
                "natlPoints": "0.00",
                "zonePoints": "41.00",
                "backNumber": "1270",
                "dressagePercentage": null,
                "clipmyhorse_url": "https://www.clipmyhorse.tv/en_EU/ondemand/event/9509/competition/156218?start_at=6884866"
              },
              {
                "classCode": "93",
                "classTitle": "93 - $200 CHILD HUNTER PONY SM/MED O/F - 2'",
                "classUrl": "https://www.usef.org/search/competitions/class/2MtMNqdiPWQ",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "35",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1270",
                "dressagePercentage": null
              },
              {
                "classCode": "94",
                "classTitle": "94 - $200 CHILD HUNTER PONY SM/MED O/F - 2' *",
                "classUrl": "https://www.usef.org/search/competitions/class/96j0dt1U2N0",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "35",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1270",
                "dressagePercentage": null,
                "clipmyhorse_url": "https://www.clipmyhorse.tv/en_EU/ondemand/event/9509/competition/156438?start_at=6888963"
              }
            ]
          },
          {
            "sectionId": "3199",
            "sectionName": "Misc Equitation",
            "classes": [
              {
                "classCode": "870",
                "classTitle": "870 - CHILD'S EQ LOW/FLAT SEC D",
                "classUrl": "https://www.usef.org/search/competitions/class/J3Q1BuqVfAM",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "11",
                "placing": "2",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1270",
                "dressagePercentage": null
              },
              {
                "classCode": "871",
                "classTitle": "871 - CHILD'S EQ LOW/FENCES SEC D",
                "classUrl": "https://www.usef.org/search/competitions/class/NjMnpIZ039Y",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "20",
                "placing": "6",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1270",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "352",
        "competitionName": "NEW YORK HORSE & PONY (352)",
        "id": "352",
        "name": "NEW YORK HORSE & PONY (352)",
        "startDate": "8/3/2022",
        "endDate": "8/7/2022",
        "start": "2022-08-03T04:00:00.000Z",
        "end": "2022-08-07T04:00:00.000Z",
        "year": 2022,
        "state": "NY",
        "zone": "2",
        "viewUrl": "https://www.usef.org/search/competitions/display/AuyWG2OVZDI",
        "sections": [
          {
            "sectionId": "2701",
            "sectionName": "CHILDRENS HUNTER-PONY",
            "classes": [
              {
                "classCode": "150",
                "classTitle": "150 - CHILDREN'S HUNTER PONY SMALL/MEDIUM O/F",
                "classUrl": "https://www.usef.org/search/competitions/class/vAC8ISaK64Y",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "16",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "458",
                "dressagePercentage": null
              },
              {
                "classCode": "151",
                "classTitle": "151 - CHILDREN'S HUNTER PONY SMALL/MEDIUM O/F*",
                "classUrl": "https://www.usef.org/search/competitions/class/sui7ULdvJaY",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "16",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "458",
                "dressagePercentage": null
              },
              {
                "classCode": "152",
                "classTitle": "152 - CHILDREN'S HUNTER PONY SMALL/MEDIUM O/F",
                "classUrl": "https://www.usef.org/search/competitions/class/WY24Z5bCwmg",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "16",
                "placing": "8",
                "natlPoints": "0.00",
                "zonePoints": "16.50",
                "backNumber": "458",
                "dressagePercentage": null
              },
              {
                "classCode": "153",
                "classTitle": "153 - CHILDREN'S HUNTER PONY SMALL/MEDIUM O/F",
                "classUrl": "https://www.usef.org/search/competitions/class/OT6TITB4ULg",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "16",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "458",
                "dressagePercentage": null
              },
              {
                "classCode": "154",
                "classTitle": "154 - CHILDREN'S HUNTER PONY SMALL/MEDIUM U/S",
                "classUrl": "https://www.usef.org/search/competitions/class/y0aDC3YWmJc",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "16",
                "placing": "2",
                "natlPoints": "0.00",
                "zonePoints": "22.00",
                "backNumber": "458",
                "dressagePercentage": null
              },
              {
                "classCode": "504",
                "classTitle": "504 - $500 M&S CHILD HUNTER CLASSIC - PONY",
                "classUrl": "https://www.usef.org/search/competitions/class/T7JwxIPJMeA",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "14",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "458",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3100",
            "sectionName": "MISC. HUNTER (No points earned)",
            "classes": [
              {
                "classCode": "1706",
                "classTitle": "1706 - CHILDREN'S HUNTER PONY FINAL - MEDIUM MODEL",
                "classUrl": "https://www.usef.org/search/competitions/class/0RRPdUGxPeg",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "10",
                "placing": "4",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "458",
                "dressagePercentage": null
              },
              {
                "classCode": "2706",
                "classTitle": "2706 - CHILDREN'S HUNTER PONY FINAL - MEDIUM U/S",
                "classUrl": "https://www.usef.org/search/competitions/class/l0RdN5UiYgY",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "8",
                "placing": "2",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "458",
                "dressagePercentage": null
              },
              {
                "classCode": "3706",
                "classTitle": "3706 - CHILDREN'S HUNTER PONY FINAL - MEDIUM O/F",
                "classUrl": "https://www.usef.org/search/competitions/class/gDy2mIUiTDI",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "10",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "458",
                "dressagePercentage": null
              },
              {
                "classCode": "4706",
                "classTitle": "4706 - CHILDREN'S HUNTER PONY FINAL - MEDIUM OVERALL",
                "classUrl": "https://www.usef.org/search/competitions/class/8LbFFyg_eWs",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "10",
                "placing": "8",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "458",
                "dressagePercentage": null
              },
              {
                "classCode": "706",
                "classTitle": "706 - CHILDREN'S HUNTER PONY FINAL - MEDIUM",
                "classUrl": "https://www.usef.org/search/competitions/class/KC-g18Q32I8",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "2",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "458",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "965",
        "competitionName": "CHEMUNG COUNTY CLASSIC HORSE SHOW (965)",
        "id": "965",
        "name": "CHEMUNG COUNTY CLASSIC HORSE SHOW (965)",
        "startDate": "7/21/2022",
        "endDate": "7/23/2022",
        "start": "2022-07-21T04:00:00.000Z",
        "end": "2022-07-23T04:00:00.000Z",
        "year": 2022,
        "state": "NY",
        "zone": "2",
        "viewUrl": "https://www.usef.org/search/competitions/display/pR_hvenoCL8",
        "sections": [
          {
            "sectionId": "2701",
            "sectionName": "CHILDRENS HUNTER-PONY",
            "classes": [
              {
                "classCode": "401",
                "classTitle": "401 - $500 M&S Childrens Pony Hunter Classic 2'/2'6",
                "classUrl": "https://www.usef.org/search/competitions/class/pAbgkB18LlQ",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "7",
                "placing": "1",
                "natlPoints": "0.00",
                "zonePoints": "21.25",
                "backNumber": "160",
                "dressagePercentage": null
              },
              {
                "classCode": "95",
                "classTitle": "95 - Childrens Hunter Pony - Combined  U/S",
                "classUrl": "https://www.usef.org/search/competitions/class/54sRGkfwLQQ",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "7",
                "placing": "1",
                "natlPoints": "0.00",
                "zonePoints": "17.00",
                "backNumber": "160",
                "dressagePercentage": null
              },
              {
                "classCode": "96",
                "classTitle": "96 - Childrens Hunter Pony - Combined FP",
                "classUrl": "https://www.usef.org/search/competitions/class/SWVgNyaHa00",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "7",
                "placing": "5",
                "natlPoints": "0.00",
                "zonePoints": "9.00",
                "backNumber": "160",
                "dressagePercentage": null
              },
              {
                "classCode": "97",
                "classTitle": "97 - Childrens Hunter Pony - Combined O/F",
                "classUrl": "https://www.usef.org/search/competitions/class/_8b1y2CyP6E",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "7",
                "placing": "1",
                "natlPoints": "0.00",
                "zonePoints": "17.00",
                "backNumber": "160",
                "dressagePercentage": null
              },
              {
                "classCode": "98",
                "classTitle": "98 - Childrens Hunter Pony - Combined O/F",
                "classUrl": "https://www.usef.org/search/competitions/class/SDpVlXz24uE",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "7",
                "placing": "1",
                "natlPoints": "0.00",
                "zonePoints": "17.00",
                "backNumber": "160",
                "dressagePercentage": null
              },
              {
                "classCode": "99",
                "classTitle": "99 - Childrens Hunter Pony - Combined O/F",
                "classUrl": "https://www.usef.org/search/competitions/class/ewHp-yXtEgI",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "7",
                "placing": "1",
                "natlPoints": "0.00",
                "zonePoints": "17.00",
                "backNumber": "160",
                "dressagePercentage": null
              },
              {
                "classCode": null,
                "classTitle": "CHPCH - Children's Hunter Pony - Combined Championship",
                "classUrl": "https://www.usef.org/search/competitions/class/spoa0AIR-7Q",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "7",
                "placing": "1",
                "natlPoints": "0.00",
                "zonePoints": "34.00",
                "backNumber": "160",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "6675",
        "competitionName": "MARK TWAIN FESTIVAL (6675)",
        "id": "6675",
        "name": "MARK TWAIN FESTIVAL (6675)",
        "startDate": "7/19/2022",
        "endDate": "7/20/2022",
        "start": "2022-07-19T04:00:00.000Z",
        "end": "2022-07-20T04:00:00.000Z",
        "year": 2022,
        "state": "NY",
        "zone": "2",
        "viewUrl": "https://www.usef.org/search/competitions/display/GcREFZeQbyw",
        "sections": [
          {
            "sectionId": "2701",
            "sectionName": "CHILDRENS HUNTER-PONY",
            "classes": [
              {
                "classCode": "401",
                "classTitle": "401 - $500 M&S Childrens Pony Hunter Classic 2'/2'6",
                "classUrl": "https://www.usef.org/search/competitions/class/RzPhywDgc6c",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "6",
                "placing": "4",
                "natlPoints": "0.00",
                "zonePoints": "11.25",
                "backNumber": "160",
                "dressagePercentage": null
              },
              {
                "classCode": "95",
                "classTitle": "95 - Children's Hunter Pony - Combined U/S",
                "classUrl": "https://www.usef.org/search/competitions/class/Sn5Pn4c0VL8",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "7",
                "placing": "3",
                "natlPoints": "0.00",
                "zonePoints": "11.00",
                "backNumber": "160",
                "dressagePercentage": null
              },
              {
                "classCode": "96",
                "classTitle": "96 - Children's Hunter Pony - Combined FP",
                "classUrl": "https://www.usef.org/search/competitions/class/UNL8Wi2THWY",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "7",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "160",
                "dressagePercentage": null
              },
              {
                "classCode": "97",
                "classTitle": "97 - Children's Hunter Pony - Combined (1st Round Classic)",
                "classUrl": "https://www.usef.org/search/competitions/class/zpAkamVv0qY",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "7",
                "placing": "2",
                "natlPoints": "0.00",
                "zonePoints": "13.00",
                "backNumber": "160",
                "dressagePercentage": null
              },
              {
                "classCode": "98",
                "classTitle": "98 - Children's Hunter Pony - Combined",
                "classUrl": "https://www.usef.org/search/competitions/class/GEPRhBNMww4",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "7",
                "placing": "5",
                "natlPoints": "0.00",
                "zonePoints": "9.00",
                "backNumber": "160",
                "dressagePercentage": null
              },
              {
                "classCode": "99",
                "classTitle": "99 - Children's Hunter Pony - Combined",
                "classUrl": "https://www.usef.org/search/competitions/class/rVSOnZogzeQ",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "7",
                "placing": "7",
                "natlPoints": "0.00",
                "zonePoints": "8.00",
                "backNumber": "160",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "6674",
        "competitionName": "HUCK FINN CLASSIC (6674)",
        "id": "6674",
        "name": "HUCK FINN CLASSIC (6674)",
        "startDate": "7/16/2022",
        "endDate": "7/17/2022",
        "start": "2022-07-16T04:00:00.000Z",
        "end": "2022-07-17T04:00:00.000Z",
        "year": 2022,
        "state": "NY",
        "zone": "2",
        "viewUrl": "https://www.usef.org/search/competitions/display/DRGAMlyzyFU",
        "sections": [
          {
            "sectionId": "2701",
            "sectionName": "CHILDRENS HUNTER-PONY",
            "classes": [
              {
                "classCode": "95",
                "classTitle": "95 - Children's Hunter Pony U/S",
                "classUrl": "https://www.usef.org/search/competitions/class/2zeIMDKdQKE",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "3",
                "placing": "1",
                "natlPoints": "0.00",
                "zonePoints": "13.00",
                "backNumber": "160",
                "dressagePercentage": null
              },
              {
                "classCode": "96",
                "classTitle": "96 - Children's Hunter Pony FP",
                "classUrl": "https://www.usef.org/search/competitions/class/qh6nGEDp2mQ",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "3",
                "placing": "3",
                "natlPoints": "0.00",
                "zonePoints": "7.00",
                "backNumber": "160",
                "dressagePercentage": null
              },
              {
                "classCode": "97",
                "classTitle": "97 - Children's Hunter Pony 1st Round Classic",
                "classUrl": "https://www.usef.org/search/competitions/class/fJz9LFQ4mvY",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "3",
                "placing": "3",
                "natlPoints": "0.00",
                "zonePoints": "7.00",
                "backNumber": "160",
                "dressagePercentage": null
              },
              {
                "classCode": "98",
                "classTitle": "98 - Childrens Hunter Pony",
                "classUrl": "https://www.usef.org/search/competitions/class/8DetqWMAUVI",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "3",
                "placing": "3",
                "natlPoints": "0.00",
                "zonePoints": "7.00",
                "backNumber": "160",
                "dressagePercentage": null
              },
              {
                "classCode": "99",
                "classTitle": "99 - Childrens Hunter Pony",
                "classUrl": "https://www.usef.org/search/competitions/class/zKt8dJYRWq4",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "3",
                "placing": "2",
                "natlPoints": "0.00",
                "zonePoints": "9.00",
                "backNumber": "160",
                "dressagePercentage": null
              },
              {
                "classCode": null,
                "classTitle": "CHCP - Childrens Hunter Pony Championship",
                "classUrl": "https://www.usef.org/search/competitions/class/QPpCkSwjmaU",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "3",
                "placing": "2",
                "natlPoints": "0.00",
                "zonePoints": "15.60",
                "backNumber": "160",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "2800",
            "sectionName": "ADULT AMATEUR HUNTER",
            "classes": [
              {
                "classCode": "401",
                "classTitle": "401 - NAL/M&W Adult Amateur 3' Hunter Classic",
                "classUrl": "https://www.usef.org/search/competitions/class/fleljL_hq9A",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "6",
                "placing": "5",
                "natlPoints": "0.00",
                "zonePoints": "10.00",
                "backNumber": "160",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "5702",
            "sectionName": "OPPORTUNITY CLASS",
            "classes": [
              {
                "classCode": "1",
                "classTitle": "1 - Syracuse PHA Opportunity Jr/Amateur 2' Hunter U/S",
                "classUrl": "https://www.usef.org/search/competitions/class/TkdX6xFj7iQ",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "4",
                "placing": "2",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "160",
                "dressagePercentage": null
              },
              {
                "classCode": "2",
                "classTitle": "2 - Syracuse PHA Opportunity Jr/Amateur 2' Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/drQL14c_rMA",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "4",
                "placing": "4",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "160",
                "dressagePercentage": null
              },
              {
                "classCode": "3",
                "classTitle": "3 - Syracuse PHA Opportunity Jr/Amateur 2' Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/9kVxP7pNSBI",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "4",
                "placing": "4",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "160",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "9950",
            "sectionName": "Non-member exempted classes",
            "classes": [
              {
                "classCode": "410",
                "classTitle": "410 - Chemung County Hunt and Go Exhibition * Needs 6 to Run*",
                "classUrl": "https://www.usef.org/search/competitions/class/Ti9k_VV3jv4",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "20",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "160",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "6845",
        "competitionName": "SARATOGA CLASSIC I (6845)",
        "id": "6845",
        "name": "SARATOGA CLASSIC I (6845)",
        "startDate": "6/15/2022",
        "endDate": "6/19/2022",
        "start": "2022-06-15T04:00:00.000Z",
        "end": "2022-06-19T04:00:00.000Z",
        "year": 2022,
        "state": "NY",
        "zone": "2",
        "viewUrl": "https://www.usef.org/search/competitions/display/MBbOZnudxDY",
        "sections": [
          {
            "sectionId": "2051",
            "sectionName": "USHJA HUNTER 2'0\\"",
            "classes": [
              {
                "classCode": "601",
                "classTitle": "601 - USHJA HUNTER 2' O/F FP",
                "classUrl": "https://www.usef.org/search/competitions/class/ZSNx9T3hylk",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "12",
                "placing": "8",
                "natlPoints": "0.00",
                "zonePoints": "12.50",
                "backNumber": "1041",
                "dressagePercentage": null
              },
              {
                "classCode": "602",
                "classTitle": "602 - USHJA HUNTER 2' O/F",
                "classUrl": "https://www.usef.org/search/competitions/class/jX-O4HxiZpI",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "11",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1041",
                "dressagePercentage": null
              },
              {
                "classCode": "603",
                "classTitle": "603 - USHJA HUNTER 2' O/F",
                "classUrl": "https://www.usef.org/search/competitions/class/V1-LI3gLCvg",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "17",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1041",
                "dressagePercentage": null
              },
              {
                "classCode": "604",
                "classTitle": "604 - USHJA HUNTER 2' O/F",
                "classUrl": "https://www.usef.org/search/competitions/class/7x4optq9_IE",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "15",
                "placing": "1",
                "natlPoints": "0.00",
                "zonePoints": "22.00",
                "backNumber": "1041",
                "dressagePercentage": null
              },
              {
                "classCode": "605",
                "classTitle": "605 - USHJA HUNTER 2' U/S",
                "classUrl": "https://www.usef.org/search/competitions/class/MePYYt7BlDg",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "12",
                "placing": "2",
                "natlPoints": "0.00",
                "zonePoints": "18.00",
                "backNumber": "1041",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "2701",
            "sectionName": "CHILDRENS HUNTER-PONY",
            "classes": [
              {
                "classCode": "138",
                "classTitle": "138 - CHILD HUNTER PONY O/F (Comb) FP",
                "classUrl": "https://www.usef.org/search/competitions/class/UDC2eJFYGlI",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "5",
                "placing": "4",
                "natlPoints": "0.00",
                "zonePoints": "8.00",
                "backNumber": "1041",
                "dressagePercentage": null
              },
              {
                "classCode": "139",
                "classTitle": "139 - CHILD HUNTER PONY O/F (Comb)",
                "classUrl": "https://www.usef.org/search/competitions/class/hUQ3WFooV6k",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "5",
                "placing": "5",
                "natlPoints": "0.00",
                "zonePoints": "7.00",
                "backNumber": "1041",
                "dressagePercentage": null
              },
              {
                "classCode": "140",
                "classTitle": "140 - CHILD HUNTER PONY O/F (Comb)",
                "classUrl": "https://www.usef.org/search/competitions/class/PJwmhzQqBWQ",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "5",
                "placing": "5",
                "natlPoints": "0.00",
                "zonePoints": "7.00",
                "backNumber": "1041",
                "dressagePercentage": null
              },
              {
                "classCode": "141",
                "classTitle": "141 - CHILD HUNTER PONY O/F (Comb)",
                "classUrl": "https://www.usef.org/search/competitions/class/uK-6cmUCO8I",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "5",
                "placing": "5",
                "natlPoints": "0.00",
                "zonePoints": "7.00",
                "backNumber": "1041",
                "dressagePercentage": null
              },
              {
                "classCode": "142",
                "classTitle": "142 - CHILD HUNTER PONY U/S (Comb)",
                "classUrl": "https://www.usef.org/search/competitions/class/HVtx63Ha_wk",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "5",
                "placing": "3",
                "natlPoints": "0.00",
                "zonePoints": "9.00",
                "backNumber": "1041",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3100",
            "sectionName": "MISC. HUNTER (No points earned)",
            "classes": [
              {
                "classCode": "205",
                "classTitle": "205 - SCHOOLING PONY O/F",
                "classUrl": "https://www.usef.org/search/competitions/class/xojZAUs4ZWU",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "10",
                "placing": "8",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1041",
                "dressagePercentage": null
              },
              {
                "classCode": "206",
                "classTitle": "206 - SCHOOLING PONY O/F",
                "classUrl": "https://www.usef.org/search/competitions/class/2ihGY7vNGEs",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "6",
                "placing": "6",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1041",
                "dressagePercentage": null
              },
              {
                "classCode": "512",
                "classTitle": "512 - LOW LOW HUNTER O/F",
                "classUrl": "https://www.usef.org/search/competitions/class/trmsczlE28o",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "12",
                "placing": "8",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1041",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3102",
            "sectionName": "HUNTER EQUITATION 14&U",
            "classes": [
              {
                "classCode": "303",
                "classTitle": "303 - EQUITATION 11 & U FLAT",
                "classUrl": "https://www.usef.org/search/competitions/class/aBmgA5OQyko",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "5",
                "placing": "4",
                "natlPoints": "0.00",
                "zonePoints": "6.00",
                "backNumber": "1041",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "9950",
            "sectionName": "Non-member exempted classes",
            "classes": [
              {
                "classCode": "401",
                "classTitle": "401 - BEST JUNIOR RIDER ON PONY",
                "classUrl": "https://www.usef.org/search/competitions/class/qRONemrwHsE",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "7",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1041",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "464",
        "competitionName": "SMITHTOWN HUNT (464)",
        "id": "464",
        "name": "SMITHTOWN HUNT (464)",
        "startDate": "6/11/2022",
        "endDate": "6/12/2022",
        "start": "2022-06-11T04:00:00.000Z",
        "end": "2022-06-12T04:00:00.000Z",
        "year": 2022,
        "state": "NY",
        "zone": "2",
        "viewUrl": "https://www.usef.org/search/competitions/display/f_44_U-YL8Q",
        "sections": [
          {
            "sectionId": "2701",
            "sectionName": "CHILDRENS HUNTER-PONY",
            "classes": [
              {
                "classCode": "161",
                "classTitle": "161 - Childrens Hunter Pony (Sm/Med) U/S",
                "classUrl": "https://www.usef.org/search/competitions/class/6UJK5CQdzUQ",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "5",
                "placing": "1",
                "natlPoints": "0.00",
                "zonePoints": "15.00",
                "backNumber": "432",
                "dressagePercentage": null
              },
              {
                "classCode": "162",
                "classTitle": "162 - Childrens Hunter Pony (Sm/Med) O/F 2'",
                "classUrl": "https://www.usef.org/search/competitions/class/f9zee66mymI",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "5",
                "placing": "5",
                "natlPoints": "0.00",
                "zonePoints": "7.00",
                "backNumber": "432",
                "dressagePercentage": null
              },
              {
                "classCode": "163",
                "classTitle": "163 - Childrens Hunter Pony (Sm/Med) O/F 2'",
                "classUrl": "https://www.usef.org/search/competitions/class/-3nGu7-7B_s",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "5",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "432",
                "dressagePercentage": null
              },
              {
                "classCode": "164",
                "classTitle": "164 - Childrens Hunter Pony (Sm/Med) O/F 2'",
                "classUrl": "https://www.usef.org/search/competitions/class/XH_fuEy_RYU",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "5",
                "placing": "4",
                "natlPoints": "0.00",
                "zonePoints": "8.00",
                "backNumber": "432",
                "dressagePercentage": null
              },
              {
                "classCode": "403",
                "classTitle": "403 - M&S Children's Hunter Pony Classic 2'/2'6 COMBINED",
                "classUrl": "https://www.usef.org/search/competitions/class/FO-0aRTAf0E",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "9",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "432",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "200",
        "competitionName": "WEF 6 EQUESTRIAN SPORT PRODUCTIONS, LLC (200)",
        "id": "200",
        "name": "WEF 6 EQUESTRIAN SPORT PRODUCTIONS, LLC (200)",
        "startDate": "2/15/2023",
        "endDate": "2/19/2023",
        "start": "2023-02-15T05:00:00.000Z",
        "end": "2023-02-19T05:00:00.000Z",
        "year": 2023,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/yFlRjP-x1Lk",
        "sections": [
          {
            "sectionId": "2701",
            "sectionName": "CHILDRENS HUNTER-PONY",
            "classes": [
              {
                "classCode": "2881A",
                "classTitle": "2881A - Small/Medium Children's Pony Hunter U/S CALI",
                "classUrl": "https://www.usef.org/search/competitions/class/DVTT7r00Zkk",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "18",
                "placing": "3",
                "natlPoints": "16.00",
                "zonePoints": "16.00",
                "backNumber": "4544",
                "dressagePercentage": null
              },
              {
                "classCode": "2882A",
                "classTitle": "2882A - Small/Medium Children's Pony Hunter CALI",
                "classUrl": "https://www.usef.org/search/competitions/class/YmVkIdZazjs",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "25",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "4544",
                "dressagePercentage": null
              },
              {
                "classCode": "2883B",
                "classTitle": "2883B - Small/Medium Children's Pony Hunter CALI",
                "classUrl": "https://www.usef.org/search/competitions/class/_KM_pc_WUO0",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "25",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "4544",
                "dressagePercentage": null
              },
              {
                "classCode": "2884A",
                "classTitle": "2884A - Small/Medium Children's Pony Hunter CALI (1st Round Classic)",
                "classUrl": "https://www.usef.org/search/competitions/class/iDTocGoIa3E",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "25",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "4544",
                "dressagePercentage": null
              },
              {
                "classCode": "605",
                "classTitle": "605 - $2500 WCHR Florida Small/Medium Children's Pony Hunter Classic",
                "classUrl": "https://www.usef.org/search/competitions/class/Z41edkYVIIc",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "45",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "4544",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "619",
        "competitionName": "WEF 5  (619)",
        "id": "619",
        "name": "WEF 5  (619)",
        "startDate": "2/7/2023",
        "endDate": "2/12/2023",
        "start": "2023-02-07T05:00:00.000Z",
        "end": "2023-02-12T05:00:00.000Z",
        "year": 2023,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/dcG2wjofuI0",
        "sections": [
          {
            "sectionId": "2701",
            "sectionName": "CHILDRENS HUNTER-PONY",
            "classes": [
              {
                "classCode": "2881A",
                "classTitle": "2881A - Small/Medium Children's Pony Hunter U/S CALI @ 30+",
                "classUrl": "https://www.usef.org/search/competitions/class/Q3ye4-Dw9Ok",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "18",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "4544",
                "dressagePercentage": null
              },
              {
                "classCode": "2882A",
                "classTitle": "2882A - Small/Medium Children's Pony Hunter CALI @ 30+",
                "classUrl": "https://www.usef.org/search/competitions/class/AyoXG1GUiFI",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "19",
                "placing": "5",
                "natlPoints": "11.00",
                "zonePoints": "11.00",
                "backNumber": "4544",
                "dressagePercentage": null
              },
              {
                "classCode": "2883A",
                "classTitle": "2883A - Small/Medium Children's Pony Hunter CALI @ 30+",
                "classUrl": "https://www.usef.org/search/competitions/class/6qmITDchXY0",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "19",
                "placing": "2",
                "natlPoints": "20.00",
                "zonePoints": "20.00",
                "backNumber": "4544",
                "dressagePercentage": null
              },
              {
                "classCode": "2884A",
                "classTitle": "2884A - Small/Medium Children's Pony Hunter CALI @ 30+",
                "classUrl": "https://www.usef.org/search/competitions/class/zVHjOBbodt8",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "19",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "4544",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "962",
        "competitionName": "WEF 3 (962)",
        "id": "962",
        "name": "WEF 3 (962)",
        "startDate": "1/24/2023",
        "endDate": "1/29/2023",
        "start": "2023-01-24T05:00:00.000Z",
        "end": "2023-01-29T05:00:00.000Z",
        "year": 2023,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/OyWzHX81lVo",
        "sections": [
          {
            "sectionId": "2701",
            "sectionName": "CHILDRENS HUNTER-PONY",
            "classes": [
              {
                "classCode": "2881",
                "classTitle": "2881 - Small/Medium Children's Pony Hunter U/S",
                "classUrl": "https://www.usef.org/search/competitions/class/rfYdCURE69g",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "22",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "4544",
                "dressagePercentage": null
              },
              {
                "classCode": "2882",
                "classTitle": "2882 - Small/Medium Children's Pony Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/MHVPBLmXvYg",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "22",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "4544",
                "dressagePercentage": null
              },
              {
                "classCode": "2883",
                "classTitle": "2883 - Small/Medium Children's Pony Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/9-ChEfGmqn4",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "22",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "4544",
                "dressagePercentage": null
              },
              {
                "classCode": "2884",
                "classTitle": "2884 - Small/Medium Children's Pony Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/UP08U6LQBdg",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "22",
                "placing": "4",
                "natlPoints": "12.00",
                "zonePoints": "12.00",
                "backNumber": "4544",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "1893",
        "competitionName": "WEF 1 (1893)",
        "id": "1893",
        "name": "WEF 1 (1893)",
        "startDate": "1/11/2023",
        "endDate": "1/15/2023",
        "start": "2023-01-11T05:00:00.000Z",
        "end": "2023-01-15T05:00:00.000Z",
        "year": 2023,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/FDg_mW4X7lU",
        "sections": [
          {
            "sectionId": "2701",
            "sectionName": "CHILDRENS HUNTER-PONY",
            "classes": [
              {
                "classCode": "2881A",
                "classTitle": "2881A - Small/Medium Children's Pony Hunter U/S CALI @ 30+",
                "classUrl": "https://www.usef.org/search/competitions/class/p71CDMANQ9U",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "15",
                "placing": "8",
                "natlPoints": "5.00",
                "zonePoints": "5.00",
                "backNumber": "4544",
                "dressagePercentage": null
              },
              {
                "classCode": "2882B",
                "classTitle": "2882B - Small/Medium Children's Pony Hunter CALI @ 30+",
                "classUrl": "https://www.usef.org/search/competitions/class/X6gAyVCqmG4",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "16",
                "placing": "2",
                "natlPoints": "20.00",
                "zonePoints": "20.00",
                "backNumber": "4544",
                "dressagePercentage": null
              },
              {
                "classCode": "2883A",
                "classTitle": "2883A - Small/Medium Children's Pony Hunter CALI @ 30+",
                "classUrl": "https://www.usef.org/search/competitions/class/TN1V9x0S9ZQ",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "16",
                "placing": "2",
                "natlPoints": "20.00",
                "zonePoints": "20.00",
                "backNumber": "4544",
                "dressagePercentage": null
              },
              {
                "classCode": "2884A",
                "classTitle": "2884A - Small/Medium Children's Pony Hunter CALI @ 30+",
                "classUrl": "https://www.usef.org/search/competitions/class/r308DRz7KDs",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "16",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "4544",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "316542",
        "competitionName": "HOLIDAY FESTIVAL II (316542)",
        "id": "316542",
        "name": "HOLIDAY FESTIVAL II (316542)",
        "startDate": "12/15/2022",
        "endDate": "12/18/2022",
        "start": "2022-12-15T05:00:00.000Z",
        "end": "2022-12-18T05:00:00.000Z",
        "year": 2022,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/JtJqN-nrcqs",
        "sections": [
          {
            "sectionId": "2701",
            "sectionName": "CHILDRENS HUNTER-PONY",
            "classes": [
              {
                "classCode": "405",
                "classTitle": "405 - Children's Hunter Pony U/S",
                "classUrl": "https://www.usef.org/search/competitions/class/Zl0YJRjf63Q",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "18",
                "placing": "8",
                "natlPoints": "8.00",
                "zonePoints": "8.00",
                "backNumber": "2275",
                "dressagePercentage": null
              },
              {
                "classCode": "406",
                "classTitle": "406 - Children's Hunter Pony FP",
                "classUrl": "https://www.usef.org/search/competitions/class/ySn2gybrOdc",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "18",
                "placing": "3",
                "natlPoints": "16.00",
                "zonePoints": "16.00",
                "backNumber": "2275",
                "dressagePercentage": null
              },
              {
                "classCode": "407",
                "classTitle": "407 - Children's Hunter Pony",
                "classUrl": "https://www.usef.org/search/competitions/class/sU4jA110F9Y",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "18",
                "placing": "7",
                "natlPoints": "9.00",
                "zonePoints": "9.00",
                "backNumber": "2275",
                "dressagePercentage": null
              },
              {
                "classCode": "408",
                "classTitle": "408 - Children's Hunter Pony",
                "classUrl": "https://www.usef.org/search/competitions/class/q9kc6KLWgAM",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "17",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "2275",
                "dressagePercentage": null
              },
              {
                "classCode": "409",
                "classTitle": "409 - Children's Hunter Pony",
                "classUrl": "https://www.usef.org/search/competitions/class/4Lxa5DC7zK4",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "15",
                "placing": "6",
                "natlPoints": "10.00",
                "zonePoints": "10.00",
                "backNumber": "2275",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "247834",
        "competitionName": "HOLIDAY FESTIVAL I (247834)",
        "id": "247834",
        "name": "HOLIDAY FESTIVAL I (247834)",
        "startDate": "12/12/2022",
        "endDate": "12/14/2022",
        "start": "2022-12-12T05:00:00.000Z",
        "end": "2022-12-14T05:00:00.000Z",
        "year": 2022,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/4BRDid2Nntk",
        "sections": [
          {
            "sectionId": "2701",
            "sectionName": "CHILDRENS HUNTER-PONY",
            "classes": [
              {
                "classCode": "405",
                "classTitle": "405 - Children's Hunter Pony U/S",
                "classUrl": "https://www.usef.org/search/competitions/class/2o7Bok43Uyc",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "2",
                "placing": "2",
                "natlPoints": "10.00",
                "zonePoints": "10.00",
                "backNumber": "2275",
                "dressagePercentage": null
              },
              {
                "classCode": "406",
                "classTitle": "406 - Children's Hunter Pony",
                "classUrl": "https://www.usef.org/search/competitions/class/h3lL2Fo4B34",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "2",
                "placing": "1",
                "natlPoints": "15.00",
                "zonePoints": "15.00",
                "backNumber": "2275",
                "dressagePercentage": null
              },
              {
                "classCode": "407",
                "classTitle": "407 - Children's Hunter Pony",
                "classUrl": "https://www.usef.org/search/competitions/class/MZ_CidI2vCc",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "2",
                "placing": "2",
                "natlPoints": "10.00",
                "zonePoints": "10.00",
                "backNumber": "2275",
                "dressagePercentage": null
              },
              {
                "classCode": "408",
                "classTitle": "408 - Children's Hunter Pony",
                "classUrl": "https://www.usef.org/search/competitions/class/TrZNmfnfH74",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "2",
                "placing": "1",
                "natlPoints": "15.00",
                "zonePoints": "15.00",
                "backNumber": "2275",
                "dressagePercentage": null
              },
              {
                "classCode": "409",
                "classTitle": "409 - Children's Hunter Pony",
                "classUrl": "https://www.usef.org/search/competitions/class/dnsFSxMJ_8A",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "2",
                "placing": "2",
                "natlPoints": "10.00",
                "zonePoints": "10.00",
                "backNumber": "2275",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "1023",
        "competitionName": "CAPITAL CHALLENGE HUNTER JUMPER (1023)",
        "id": "1023",
        "name": "CAPITAL CHALLENGE HUNTER JUMPER (1023)",
        "startDate": "10/3/2022",
        "endDate": "10/9/2022",
        "start": "2022-10-03T04:00:00.000Z",
        "end": "2022-10-09T04:00:00.000Z",
        "year": 2022,
        "state": "MD",
        "zone": "3",
        "viewUrl": "https://www.usef.org/search/competitions/display/V3acrz9xeW8",
        "sections": [
          {
            "sectionId": "2701",
            "sectionName": "CHILDRENS HUNTER-PONY",
            "classes": [
              {
                "classCode": "108",
                "classTitle": "108 - CHILDREN'S HUNTER PONY FP",
                "classUrl": "https://www.usef.org/search/competitions/class/CXRPHFeKvEU",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "23",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1051",
                "dressagePercentage": null
              },
              {
                "classCode": "109",
                "classTitle": "109 - CHILDREN'S HUNTER PONY",
                "classUrl": "https://www.usef.org/search/competitions/class/5MtSEmNNg9M",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "27",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1051",
                "dressagePercentage": null
              },
              {
                "classCode": "110",
                "classTitle": "110 - CHILDREN'S HUNTER PONY U/S",
                "classUrl": "https://www.usef.org/search/competitions/class/7XM9u7nntAs",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2022"
                },
                "entries": "27",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1051",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "319687",
        "competitionName": "HITS ON THE HUDSON IV (319687)",
        "id": "319687",
        "name": "HITS ON THE HUDSON IV (319687)",
        "startDate": "7/19/2023",
        "endDate": "7/23/2023",
        "start": "2023-07-19T04:00:00.000Z",
        "end": "2023-07-23T04:00:00.000Z",
        "year": 2023,
        "state": "NY",
        "zone": "2",
        "viewUrl": "https://www.usef.org/search/competitions/display/651leMhq3-g",
        "sections": [
          {
            "sectionId": "2603",
            "sectionName": "GREEN PONY HUNTER-MEDIUM",
            "classes": [
              {
                "classCode": "1170",
                "classTitle": "1170 - MEDIUM GREEN PONY HUNTER MODEL",
                "classUrl": "https://www.usef.org/search/competitions/class/newxLheDc4k",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "6",
                "placing": "6",
                "natlPoints": "2.00",
                "zonePoints": "2.00",
                "backNumber": "679",
                "dressagePercentage": null
              },
              {
                "classCode": "1171",
                "classTitle": "1171 - $200 MEDIUM GREEN PONY HUNTER - CONF FP",
                "classUrl": "https://www.usef.org/search/competitions/class/kTgZj7sFOg8",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "6",
                "placing": "5",
                "natlPoints": "5.00",
                "zonePoints": "5.00",
                "backNumber": "679",
                "dressagePercentage": null
              },
              {
                "classCode": "1172",
                "classTitle": "1172 - $200 MEDIUM GREEN PONY HUNTER",
                "classUrl": "https://www.usef.org/search/competitions/class/MNKYUXP1olU",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "6",
                "placing": "2",
                "natlPoints": "10.00",
                "zonePoints": "10.00",
                "backNumber": "679",
                "dressagePercentage": null
              },
              {
                "classCode": "1173",
                "classTitle": "1173 - $200 MEDIUM GREEN PONY HUNTER",
                "classUrl": "https://www.usef.org/search/competitions/class/GfFnOHh7x0o",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "6",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "679",
                "dressagePercentage": null
              },
              {
                "classCode": "1174",
                "classTitle": "1174 - $200 MEDIUM GREEN PONY HUNTER",
                "classUrl": "https://www.usef.org/search/competitions/class/rhhlZzEQ_aI",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "6",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "679",
                "dressagePercentage": null
              },
              {
                "classCode": "1175",
                "classTitle": "1175 - MEDIUM GREEN PONY HUNTER U/S",
                "classUrl": "https://www.usef.org/search/competitions/class/v1U832AXp38",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "6",
                "placing": "5",
                "natlPoints": "5.00",
                "zonePoints": "5.00",
                "backNumber": "679",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3100",
            "sectionName": "MISC. HUNTER (No points earned)",
            "classes": [
              {
                "classCode": "555",
                "classTitle": "555 - SAUGERTIES CHILD HUNTER O/F",
                "classUrl": "https://www.usef.org/search/competitions/class/Q-NsZ3ED2eE",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "18",
                "placing": "6",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "679",
                "dressagePercentage": null
              },
              {
                "classCode": "556",
                "classTitle": "556 - SAUGERTIES CHILD HUNTER O/F",
                "classUrl": "https://www.usef.org/search/competitions/class/_y3BwFD5dbw",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "17",
                "placing": "2",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "679",
                "dressagePercentage": null
              },
              {
                "classCode": "557",
                "classTitle": "557 - SAUGERTIES CHILD HUNTER O/F",
                "classUrl": "https://www.usef.org/search/competitions/class/K3-yPDaMIPE",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "17",
                "placing": "1",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "679",
                "dressagePercentage": null
              },
              {
                "classCode": "558",
                "classTitle": "558 - SAUGERTIES CHILD HUNTER U/S",
                "classUrl": "https://www.usef.org/search/competitions/class/Rc05j_2_jh4",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "17",
                "placing": "5",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "679",
                "dressagePercentage": null
              },
              {
                "classCode": "5580",
                "classTitle": "5580 - SAUGERTIES CHILD HUNTER CHAMPIONSHIP",
                "classUrl": "https://www.usef.org/search/competitions/class/0mRKGyUsfhY",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "18",
                "placing": "2",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "679",
                "dressagePercentage": null
              },
              {
                "classCode": "597",
                "classTitle": "597 - GREEN PONY SCHOOLING O/F",
                "classUrl": "https://www.usef.org/search/competitions/class/ZM1rjgZA9Co",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "10",
                "placing": "5",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "679",
                "dressagePercentage": null,
                "clipmyhorse_url": "https://www.clipmyhorse.tv/en_EU/ondemand/event/11689/competition/211838?start_at=8866475"
              },
              {
                "classCode": "598",
                "classTitle": "598 - GREEN PONY SCHOOLING O/F",
                "classUrl": "https://www.usef.org/search/competitions/class/_c3H44fmoCo",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "5",
                "placing": "3",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "679",
                "dressagePercentage": null,
                "clipmyhorse_url": "https://www.clipmyhorse.tv/en_EU/ondemand/event/11689/competition/211839?start_at=8881151"
              }
            ]
          },
          {
            "sectionId": "6200",
            "sectionName": "U.S. PONY MEDAL",
            "classes": [
              {
                "classCode": "376",
                "classTitle": "376 - USEF PONY MEDAL",
                "classUrl": "https://www.usef.org/search/competitions/class/1mJEMGubCRA",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "20",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "679",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "6845",
        "competitionName": "SARATOGA CLASSIC I (6845)",
        "id": "6845",
        "name": "SARATOGA CLASSIC I (6845)",
        "startDate": "6/14/2023",
        "endDate": "6/18/2023",
        "start": "2023-06-14T04:00:00.000Z",
        "end": "2023-06-18T04:00:00.000Z",
        "year": 2023,
        "state": "NY",
        "zone": "2",
        "viewUrl": "https://www.usef.org/search/competitions/display/XjVLZ1y0wyE",
        "sections": [
          {
            "sectionId": "2502",
            "sectionName": "PONY HUNTER-MEDIUM",
            "classes": [
              {
                "classCode": "113",
                "classTitle": "113 - $225 MEDIUM PONY HUNTER FP",
                "classUrl": "https://www.usef.org/search/competitions/class/9Vw1jLSmPpQ",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "14",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "812",
                "dressagePercentage": null
              },
              {
                "classCode": "114",
                "classTitle": "114 - $225 MEDIUM PONY HUNTER HANDY",
                "classUrl": "https://www.usef.org/search/competitions/class/VA9i5vK-S4k",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "14",
                "placing": "6",
                "natlPoints": "7.00",
                "zonePoints": "7.00",
                "backNumber": "812",
                "dressagePercentage": null
              },
              {
                "classCode": "115",
                "classTitle": "115 - $225 MEDIUM PONY HUNTER CONF",
                "classUrl": "https://www.usef.org/search/competitions/class/8jpT-Dmp2SM",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "14",
                "placing": "3",
                "natlPoints": "12.00",
                "zonePoints": "12.00",
                "backNumber": "812",
                "dressagePercentage": null
              },
              {
                "classCode": "116",
                "classTitle": "116 - $225 MEDIUM PONY HUNTER *",
                "classUrl": "https://www.usef.org/search/competitions/class/Ok-XbGoVE_g",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "14",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "812",
                "dressagePercentage": null
              },
              {
                "classCode": "117",
                "classTitle": "117 - $100 MEDIUM PONY HUNTER U/S",
                "classUrl": "https://www.usef.org/search/competitions/class/6rYsotfF-ho",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "14",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "812",
                "dressagePercentage": null
              },
              {
                "classCode": "636",
                "classTitle": "636 - MEDIUM PONY MODEL",
                "classUrl": "https://www.usef.org/search/competitions/class/wimJdBYVEjg",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "13",
                "placing": "3",
                "natlPoints": "6.00",
                "zonePoints": "6.00",
                "backNumber": "812",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "2600",
            "sectionName": "GREEN PONY HUNTER",
            "classes": [
              {
                "classCode": "123",
                "classTitle": "123 - $100 GREEN PONY HUNTER FP",
                "classUrl": "https://www.usef.org/search/competitions/class/bE-wwJGHyDg",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "6",
                "placing": "2",
                "natlPoints": "10.00",
                "zonePoints": "10.00",
                "backNumber": "812",
                "dressagePercentage": null
              },
              {
                "classCode": "124",
                "classTitle": "124 - $100 GREEN PONY HUNTER",
                "classUrl": "https://www.usef.org/search/competitions/class/B_BbTLf2N_k",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "6",
                "placing": "1",
                "natlPoints": "15.00",
                "zonePoints": "15.00",
                "backNumber": "812",
                "dressagePercentage": null
              },
              {
                "classCode": "125",
                "classTitle": "125 - $100 GREEN PONY HUNTER",
                "classUrl": "https://www.usef.org/search/competitions/class/1DQaAKYYs_o",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "3",
                "placing": "3",
                "natlPoints": "8.00",
                "zonePoints": "8.00",
                "backNumber": "812",
                "dressagePercentage": null
              },
              {
                "classCode": "126",
                "classTitle": "126 - $100 GREEN PONY HUNTER CONF",
                "classUrl": "https://www.usef.org/search/competitions/class/WygZT2q1Ky0",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "3",
                "placing": "2",
                "natlPoints": "10.00",
                "zonePoints": "10.00",
                "backNumber": "812",
                "dressagePercentage": null
              },
              {
                "classCode": "127",
                "classTitle": "127 - $100 GREEN PONY HUNTER U/S",
                "classUrl": "https://www.usef.org/search/competitions/class/ZM-Sp6gJgg8",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "6",
                "placing": "2",
                "natlPoints": "10.00",
                "zonePoints": "10.00",
                "backNumber": "812",
                "dressagePercentage": null
              },
              {
                "classCode": null,
                "classTitle": "CHGP - GREEN PONY HUNTER CHAMPIONSHIP",
                "classUrl": "https://www.usef.org/search/competitions/class/GE6aM0Nqe5U",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "6",
                "placing": "2",
                "natlPoints": "18.00",
                "zonePoints": "18.00",
                "backNumber": "812",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "748",
        "competitionName": "LONG ISLAND PROFESSIONAL HORSEMEN'S ASSOCIATION HORSE SHOW (748)",
        "id": "748",
        "name": "LONG ISLAND PROFESSIONAL HORSEMEN'S ASSOCIATION HORSE SHOW (748)",
        "startDate": "5/13/2023",
        "endDate": "5/14/2023",
        "start": "2023-05-13T04:00:00.000Z",
        "end": "2023-05-14T04:00:00.000Z",
        "year": 2023,
        "state": "NY",
        "zone": "2",
        "viewUrl": "https://www.usef.org/search/competitions/display/Nj1U6czDLwk",
        "sections": [
          {
            "sectionId": "2600",
            "sectionName": "GREEN PONY HUNTER",
            "classes": [
              {
                "classCode": "16",
                "classTitle": "16 - GREEN PONY HUNTER - MODEL",
                "classUrl": "https://www.usef.org/search/competitions/class/gWtzM2mBtN0",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "3",
                "placing": "1",
                "natlPoints": "7.50",
                "zonePoints": "7.50",
                "backNumber": "128",
                "dressagePercentage": null
              },
              {
                "classCode": "17",
                "classTitle": "17 - GREEN PONY HUNTER - U/S",
                "classUrl": "https://www.usef.org/search/competitions/class/yJdV5iLue88",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "3",
                "placing": "3",
                "natlPoints": "8.00",
                "zonePoints": "8.00",
                "backNumber": "128",
                "dressagePercentage": null
              },
              {
                "classCode": "18",
                "classTitle": "18 - GREEN PONY HUNTER FP",
                "classUrl": "https://www.usef.org/search/competitions/class/GLW_sDI1jbg",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "3",
                "placing": "1",
                "natlPoints": "15.00",
                "zonePoints": "15.00",
                "backNumber": "128",
                "dressagePercentage": null
              },
              {
                "classCode": "19",
                "classTitle": "19 - GREEN PONY HUNTER",
                "classUrl": "https://www.usef.org/search/competitions/class/EXZWvgKyKKk",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "3",
                "placing": "1",
                "natlPoints": "15.00",
                "zonePoints": "15.00",
                "backNumber": "128",
                "dressagePercentage": null
              },
              {
                "classCode": "20",
                "classTitle": "20 - GREEN PONY HUNTER - CONFORMATION",
                "classUrl": "https://www.usef.org/search/competitions/class/J4uB6e1iQxI",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "3",
                "placing": "1",
                "natlPoints": "15.00",
                "zonePoints": "15.00",
                "backNumber": "128",
                "dressagePercentage": null
              },
              {
                "classCode": null,
                "classTitle": "GPHCH - GREEN PONY HUNTERS CHAMPIONSHIP",
                "classUrl": "https://www.usef.org/search/competitions/class/zsxDbyVP3Vc",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "3",
                "placing": "1",
                "natlPoints": "30.00",
                "zonePoints": "30.00",
                "backNumber": "128",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "1762",
        "competitionName": "EQUESTRIAN SPORT PRODUCTIONS, LLC. SPRING 1 (1762)",
        "id": "1762",
        "name": "EQUESTRIAN SPORT PRODUCTIONS, LLC. SPRING 1 (1762)",
        "startDate": "4/4/2023",
        "endDate": "4/8/2023",
        "start": "2023-04-04T04:00:00.000Z",
        "end": "2023-04-08T04:00:00.000Z",
        "year": 2023,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/TpQgxPODb84",
        "sections": [
          {
            "sectionId": "2701",
            "sectionName": "CHILDRENS HUNTER-PONY",
            "classes": [
              {
                "classCode": "405",
                "classTitle": "405 - Children's Pony Hunter U/S",
                "classUrl": "https://www.usef.org/search/competitions/class/EA2o5TPOcV4",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "8",
                "placing": "8",
                "natlPoints": "2.00",
                "zonePoints": "2.00",
                "backNumber": "968",
                "dressagePercentage": null
              },
              {
                "classCode": "406",
                "classTitle": "406 - Children's Pony Hunter FP",
                "classUrl": "https://www.usef.org/search/competitions/class/7Fu8Yb_m4uA",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "8",
                "placing": "8",
                "natlPoints": "2.00",
                "zonePoints": "2.00",
                "backNumber": "968",
                "dressagePercentage": null
              },
              {
                "classCode": "407",
                "classTitle": "407 - Children's Pony Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/A3WqxGTMTF8",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "8",
                "placing": "5",
                "natlPoints": "5.00",
                "zonePoints": "5.00",
                "backNumber": "968",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3100",
            "sectionName": "MISC. HUNTER (No points earned)",
            "classes": [
              {
                "classCode": "658",
                "classTitle": "658 - Warm Up Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/Ip-phzhNHMo",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "4",
                "placing": "1",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "968",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "6542",
        "competitionName": "WEF 12 EQUESTRIAN SPORT PRODUCTIONS, LLC (6542)",
        "id": "6542",
        "name": "WEF 12 EQUESTRIAN SPORT PRODUCTIONS, LLC (6542)",
        "startDate": "3/28/2023",
        "endDate": "4/2/2023",
        "start": "2023-03-28T04:00:00.000Z",
        "end": "2023-04-02T04:00:00.000Z",
        "year": 2023,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/-GGsjV1rO9o",
        "sections": [
          {
            "sectionId": "2052",
            "sectionName": "USHJA HUNTER 2'3\\"",
            "classes": [
              {
                "classCode": "3127",
                "classTitle": "3127 - USHJA Hunter 2'3  (First Year Shown)",
                "classUrl": "https://www.usef.org/search/competitions/class/3kyFjmn0kGE",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "5",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "4544",
                "dressagePercentage": null
              },
              {
                "classCode": "3128",
                "classTitle": "3128 - USHJA Hunter 2'3  (First Year Shown)",
                "classUrl": "https://www.usef.org/search/competitions/class/AlA1jtdaKbE",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "5",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "4544",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "6488",
        "competitionName": "WEF 11 (6488)",
        "id": "6488",
        "name": "WEF 11 (6488)",
        "startDate": "3/21/2023",
        "endDate": "3/26/2023",
        "start": "2023-03-21T04:00:00.000Z",
        "end": "2023-03-26T04:00:00.000Z",
        "year": 2023,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/jUtREyWC0rM",
        "sections": [
          {
            "sectionId": "2051",
            "sectionName": "USHJA HUNTER 2'0\\"",
            "classes": [
              {
                "classCode": "2121",
                "classTitle": "2121 - USHJA Hunter 2' U/S",
                "classUrl": "https://www.usef.org/search/competitions/class/BB-wWx2pjRA",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "17",
                "placing": "7",
                "natlPoints": "9.00",
                "zonePoints": "9.00",
                "backNumber": "4544",
                "dressagePercentage": null
              },
              {
                "classCode": "2124",
                "classTitle": "2124 - USHJA Hunter 2'",
                "classUrl": "https://www.usef.org/search/competitions/class/8CLyGa3XMLg",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "23",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "4544",
                "dressagePercentage": null
              },
              {
                "classCode": "2125",
                "classTitle": "2125 - USHJA Hunter 2'",
                "classUrl": "https://www.usef.org/search/competitions/class/AaGDCrJWlWs",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "23",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "4544",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "2701",
            "sectionName": "CHILDRENS HUNTER-PONY",
            "classes": [
              {
                "classCode": "2881",
                "classTitle": "2881 - Small/Medium Children's Pony Hunter U/S CALI @ 30+",
                "classUrl": "https://www.usef.org/search/competitions/class/whN2CF4SVSI",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "20",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "4544",
                "dressagePercentage": null
              },
              {
                "classCode": "2882.1",
                "classTitle": "2882.1 - Small/Medium Children's Pony Hunter CALI @ 30+",
                "classUrl": "https://www.usef.org/search/competitions/class/zn7lmF3VhOw",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "20",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "4544",
                "dressagePercentage": null
              },
              {
                "classCode": "2883.1",
                "classTitle": "2883.1 - Small/Medium Children's Pony Hunter CALI @ 30+",
                "classUrl": "https://www.usef.org/search/competitions/class/N99tflxUoxQ",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "20",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "4544",
                "dressagePercentage": null
              },
              {
                "classCode": "2884.1",
                "classTitle": "2884.1 - Small/Medium Children's Pony Hunter CALI @ 30+",
                "classUrl": "https://www.usef.org/search/competitions/class/cCgQB6vbZ54",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "20",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "4544",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "139",
        "competitionName": "WEF 9 (139)",
        "id": "139",
        "name": "WEF 9 (139)",
        "startDate": "3/7/2023",
        "endDate": "3/12/2023",
        "start": "2023-03-07T05:00:00.000Z",
        "end": "2023-03-12T05:00:00.000Z",
        "year": 2023,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/b1bKY-9WpU4",
        "sections": [
          {
            "sectionId": "2701",
            "sectionName": "CHILDRENS HUNTER-PONY",
            "classes": [
              {
                "classCode": "2881.1",
                "classTitle": "2881.1 - Small/Medium Children's Pony Hunter U/S CALI @ 30+",
                "classUrl": "https://www.usef.org/search/competitions/class/SbsTIANpYyg",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "16",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "4544",
                "dressagePercentage": null
              },
              {
                "classCode": "2882.1",
                "classTitle": "2882.1 - Small/Medium Children's Pony Hunter CALI @ 30+",
                "classUrl": "https://www.usef.org/search/competitions/class/LfhrAFNk9vA",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "17",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "4544",
                "dressagePercentage": null
              },
              {
                "classCode": "2883.1",
                "classTitle": "2883.1 - Small/Medium Children's Pony Hunter CALI @ 30+",
                "classUrl": "https://www.usef.org/search/competitions/class/feGoaQtYxYM",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "17",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "4544",
                "dressagePercentage": null
              },
              {
                "classCode": "2884.1",
                "classTitle": "2884.1 - Small/Medium Children's Pony Hunter CALI @ 30+",
                "classUrl": "https://www.usef.org/search/competitions/class/K6lXV7CJdDE",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "17",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "4544",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "233832",
        "competitionName": "WEF PREMIER (233832)",
        "id": "233832",
        "name": "WEF PREMIER (233832)",
        "startDate": "1/3/2024",
        "endDate": "1/7/2024",
        "start": "2024-01-03T05:00:00.000Z",
        "end": "2024-01-07T05:00:00.000Z",
        "year": 2024,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/-TGjYvACqpQ",
        "sections": [
          {
            "sectionId": "2701",
            "sectionName": "CHILDRENS HUNTER-PONY",
            "classes": [
              {
                "classCode": "2881",
                "classTitle": "2881 - Small/Medium Children's Pony Hunter U/S",
                "classUrl": "https://www.usef.org/search/competitions/class/i3cX6K2ZN0g",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2024"
                },
                "entries": "26",
                "placing": "6",
                "natlPoints": "15.00",
                "zonePoints": "15.00",
                "backNumber": "1798",
                "dressagePercentage": null
              },
              {
                "classCode": "2882",
                "classTitle": "2882 - Small/Medium Children's Pony Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/_gItX77I40o",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2024"
                },
                "entries": "26",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1798",
                "dressagePercentage": null
              },
              {
                "classCode": "2883",
                "classTitle": "2883 - Small/Medium Children's Pony Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/Pa_ILSsfAY4",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2024"
                },
                "entries": "26",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1798",
                "dressagePercentage": null
              },
              {
                "classCode": "2884",
                "classTitle": "2884 - Small/Medium Children's Pony Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/FPalQq2LQsM",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2024"
                },
                "entries": "26",
                "placing": "3",
                "natlPoints": "23.00",
                "zonePoints": "23.00",
                "backNumber": "1798",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "340201",
        "competitionName": "ESP HOLIDAY FINALE (340201)",
        "id": "340201",
        "name": "ESP HOLIDAY FINALE (340201)",
        "startDate": "12/28/2023",
        "endDate": "12/31/2023",
        "start": "2023-12-28T05:00:00.000Z",
        "end": "2023-12-31T05:00:00.000Z",
        "year": 2023,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/2xOq3-HSL_s",
        "sections": [
          {
            "sectionId": "2716",
            "sectionName": "LOW CHILDREN'S HUNTER",
            "classes": [
              {
                "classCode": "316",
                "classTitle": "316 - Low Children's Hunter U/S",
                "classUrl": "https://www.usef.org/search/competitions/class/9yllUA-2TeA",
                "horse": {
                  "name": "CREME DE LA CREME",
                  "usefHorseId": "5532026",
                  "link": "https://www.usef.org/search/horses/display/eI_G7Pi-Krw?year=2024"
                },
                "entries": "7",
                "placing": "2",
                "natlPoints": "10.00",
                "zonePoints": "10.00",
                "backNumber": "1683",
                "dressagePercentage": null
              },
              {
                "classCode": "317",
                "classTitle": "317 - Low Children's Hunter - FP",
                "classUrl": "https://www.usef.org/search/competitions/class/qiZVjJfF-Lg",
                "horse": {
                  "name": "CREME DE LA CREME",
                  "usefHorseId": "5532026",
                  "link": "https://www.usef.org/search/horses/display/eI_G7Pi-Krw?year=2024"
                },
                "entries": "7",
                "placing": "7",
                "natlPoints": "3.00",
                "zonePoints": "3.00",
                "backNumber": "1683",
                "dressagePercentage": null
              },
              {
                "classCode": "318",
                "classTitle": "318 - Low Children's Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/r5qRknAAukU",
                "horse": {
                  "name": "CREME DE LA CREME",
                  "usefHorseId": "5532026",
                  "link": "https://www.usef.org/search/horses/display/eI_G7Pi-Krw?year=2024"
                },
                "entries": "7",
                "placing": "4",
                "natlPoints": "6.00",
                "zonePoints": "6.00",
                "backNumber": "1683",
                "dressagePercentage": null
              },
              {
                "classCode": "319",
                "classTitle": "319 - Low Children's Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/GedbG8tnU2c",
                "horse": {
                  "name": "CREME DE LA CREME",
                  "usefHorseId": "5532026",
                  "link": "https://www.usef.org/search/horses/display/eI_G7Pi-Krw?year=2024"
                },
                "entries": "7",
                "placing": "3",
                "natlPoints": "8.00",
                "zonePoints": "8.00",
                "backNumber": "1683",
                "dressagePercentage": null
              },
              {
                "classCode": "320",
                "classTitle": "320 - Low Children's Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/V-lvLuNG2uI",
                "horse": {
                  "name": "CREME DE LA CREME",
                  "usefHorseId": "5532026",
                  "link": "https://www.usef.org/search/horses/display/eI_G7Pi-Krw?year=2024"
                },
                "entries": "7",
                "placing": "4",
                "natlPoints": "6.00",
                "zonePoints": "6.00",
                "backNumber": "1683",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3100",
            "sectionName": "MISC. HUNTER (No points earned)",
            "classes": [
              {
                "classCode": "655",
                "classTitle": "655 - Warm Up Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/aH84iXFRctE",
                "horse": {
                  "name": "CREME DE LA CREME",
                  "usefHorseId": "5532026",
                  "link": "https://www.usef.org/search/horses/display/eI_G7Pi-Krw?year=2024"
                },
                "entries": "19",
                "placing": "2",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1683",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "322723",
        "competitionName": "HOLIDAY FESTIVAL III (322723)",
        "id": "322723",
        "name": "HOLIDAY FESTIVAL III (322723)",
        "startDate": "12/20/2023",
        "endDate": "12/23/2023",
        "start": "2023-12-20T05:00:00.000Z",
        "end": "2023-12-23T05:00:00.000Z",
        "year": 2023,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/s_Mg-pI0KwY",
        "sections": [
          {
            "sectionId": "2701",
            "sectionName": "CHILDRENS HUNTER-PONY",
            "classes": [
              {
                "classCode": "405",
                "classTitle": "405 - Small/Medium Children's Pony Hunter U/S",
                "classUrl": "https://www.usef.org/search/competitions/class/mOss8HqbxxY",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2024"
                },
                "entries": "4",
                "placing": "4",
                "natlPoints": "6.00",
                "zonePoints": "6.00",
                "backNumber": "2859",
                "dressagePercentage": null
              },
              {
                "classCode": "406",
                "classTitle": "406 - Small/Medium Children's Pony Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/jCT7jMntW3g",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2024"
                },
                "entries": "6",
                "placing": "2",
                "natlPoints": "10.00",
                "zonePoints": "10.00",
                "backNumber": "2859",
                "dressagePercentage": null
              },
              {
                "classCode": "407",
                "classTitle": "407 - Small/Medium Children's Pony Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/B-4IrNcyti8",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2024"
                },
                "entries": "6",
                "placing": "4",
                "natlPoints": "6.00",
                "zonePoints": "6.00",
                "backNumber": "2859",
                "dressagePercentage": null
              },
              {
                "classCode": "408",
                "classTitle": "408 - Small/Medium Children's Pony Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/Uye_vPT86tk",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2024"
                },
                "entries": "6",
                "placing": "5",
                "natlPoints": "5.00",
                "zonePoints": "5.00",
                "backNumber": "2859",
                "dressagePercentage": null
              },
              {
                "classCode": "409",
                "classTitle": "409 - Small/Medium Children's Pony Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/mLdhrS2MIB0",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2024"
                },
                "entries": "6",
                "placing": "1",
                "natlPoints": "15.00",
                "zonePoints": "15.00",
                "backNumber": "2859",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3100",
            "sectionName": "MISC. HUNTER (No points earned)",
            "classes": [
              {
                "classCode": "403",
                "classTitle": "403 - Schooling Pony",
                "classUrl": "https://www.usef.org/search/competitions/class/VOofdsSybNE",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2024"
                },
                "entries": "9",
                "placing": "5",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "2859",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "2043",
        "competitionName": "HAMPTON CLASSIC (2043)",
        "id": "2043",
        "name": "HAMPTON CLASSIC (2043)",
        "startDate": "8/27/2023",
        "endDate": "9/3/2023",
        "start": "2023-08-27T04:00:00.000Z",
        "end": "2023-09-03T04:00:00.000Z",
        "year": 2023,
        "state": "NY",
        "zone": "2",
        "viewUrl": "https://www.usef.org/search/competitions/display/UZFR26MVqVE",
        "sections": [
          {
            "sectionId": "2502",
            "sectionName": "PONY HUNTER-MEDIUM",
            "classes": [
              {
                "classCode": "77",
                "classTitle": "77 - $200 MEDIUM  PONY HUNTER 2'6''  U/S",
                "classUrl": "https://www.usef.org/search/competitions/class/oef3iHmiXlE",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "19",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "679",
                "dressagePercentage": null
              },
              {
                "classCode": "78",
                "classTitle": "78 - $500 MEDIUM PONY HUNTER 2'6'' O/F - CONFORMATION - FP",
                "classUrl": "https://www.usef.org/search/competitions/class/dG8O-_uDRjI",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "19",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "679",
                "dressagePercentage": null
              },
              {
                "classCode": "79",
                "classTitle": "79 - $500 MEDIUM PONY HUNTER 2'6\\" O/F -  HANDY",
                "classUrl": "https://www.usef.org/search/competitions/class/S9U8h-0sKrI",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "19",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "679",
                "dressagePercentage": null
              },
              {
                "classCode": "80",
                "classTitle": "80 - $500 MEDIUM PONY HUNTER 2'6'' O/F",
                "classUrl": "https://www.usef.org/search/competitions/class/0GgiAl6YVg8",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "19",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "679",
                "dressagePercentage": null,
                "clipmyhorse_url": "https://www.clipmyhorse.tv/en_EU/ondemand/event/11571/competition/220871?start_at=9264016"
              },
              {
                "classCode": "81",
                "classTitle": "81 - $500 MEDIUM PONY HUNTER 2'6'' O/F",
                "classUrl": "https://www.usef.org/search/competitions/class/A9McgnTaLGQ",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "19",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "679",
                "dressagePercentage": null,
                "clipmyhorse_url": "https://www.clipmyhorse.tv/en_EU/ondemand/event/11571/competition/220871?start_at=9264016"
              }
            ]
          },
          {
            "sectionId": "3010",
            "sectionName": "HUNTER PONY CLASSIC",
            "classes": [
              {
                "classCode": "416",
                "classTitle": "416 - $2,500 PONY HUNTER CLASSIC",
                "classUrl": "https://www.usef.org/search/competitions/class/SBZ5Df89gDc",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "44",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "679",
                "dressagePercentage": null,
                "clipmyhorse_url": "https://www.clipmyhorse.tv/en_EU/ondemand/event/11571/competition/220911?start_at=9277837"
              }
            ]
          },
          {
            "sectionId": "3199",
            "sectionName": "Misc Equitation",
            "classes": [
              {
                "classCode": "770",
                "classTitle": "770 - SERVPRO CHILD'S EQ LOW/FLAT SEC C",
                "classUrl": "https://www.usef.org/search/competitions/class/uF9KpkWzxec",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "10",
                "placing": "8",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "679",
                "dressagePercentage": null
              },
              {
                "classCode": "771",
                "classTitle": "771 - SERVPRO CHILD'S EQ LOW/FENCES SEC C",
                "classUrl": "https://www.usef.org/search/competitions/class/7tjSYqyT7vk",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "18",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "679",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "6200",
            "sectionName": "U.S. PONY MEDAL",
            "classes": [
              {
                "classCode": "339",
                "classTitle": "339 - MARSHALL & STERLING / USEF PONY MEDAL",
                "classUrl": "https://www.usef.org/search/competitions/class/rNsGAnSq66c",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "23",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "679",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "322139",
        "competitionName": "USEF PONY FINALS (322139)",
        "id": "322139",
        "name": "USEF PONY FINALS (322139)",
        "startDate": "8/8/2023",
        "endDate": "8/13/2023",
        "start": "2023-08-08T04:00:00.000Z",
        "end": "2023-08-13T04:00:00.000Z",
        "year": 2023,
        "state": "KY",
        "zone": "5",
        "viewUrl": "https://www.usef.org/search/competitions/display/8CH5PKdDYtc",
        "sections": [
          {
            "sectionId": "2603",
            "sectionName": "GREEN PONY HUNTER-MEDIUM",
            "classes": [
              {
                "classCode": "10",
                "classTitle": "10 - MEDIUM GREEN PONY OVERALL RESULTS",
                "classUrl": "https://www.usef.org/search/competitions/class/aNCEvmbpo8E",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "84",
                "placing": "71",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "991",
                "dressagePercentage": null
              },
              {
                "classCode": "6",
                "classTitle": "6 - MEDIUM GREEN PONY MODEL",
                "classUrl": "https://www.usef.org/search/competitions/class/kNZDnzcQGjI",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "85",
                "placing": "44",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "991",
                "dressagePercentage": null
              },
              {
                "classCode": "7",
                "classTitle": "7 - MEDIUM GREEN PONY U/S",
                "classUrl": "https://www.usef.org/search/competitions/class/7qPnCDpn2M0",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "85",
                "placing": "55",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "991",
                "dressagePercentage": null
              },
              {
                "classCode": "8",
                "classTitle": "8 - MEDIUM GREEN PONY O/F",
                "classUrl": "https://www.usef.org/search/competitions/class/lWtr4aaPxmw",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2023"
                },
                "entries": "82",
                "placing": "73",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "991",
                "dressagePercentage": null,
                "clipmyhorse_url": "https://www.clipmyhorse.tv/en_EU/ondemand/event/10405/competition/217837?start_at=9061425"
              }
            ]
          }
        ]
      },
      {
        "competitionId": "327488",
        "competitionName": "SFHJA MAY II SHOW (327488)",
        "id": "327488",
        "name": "SFHJA MAY II SHOW (327488)",
        "startDate": "5/18/2024",
        "endDate": "5/19/2024",
        "start": "2024-05-18T04:00:00.000Z",
        "end": "2024-05-19T04:00:00.000Z",
        "year": 2024,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/CTJxr_8Eyq4",
        "sections": [
          {
            "sectionId": "2500",
            "sectionName": "PONY HUNTER",
            "classes": [
              {
                "classCode": "411",
                "classTitle": "411 - Small/Medium Pony Hunter U/S",
                "classUrl": "https://www.usef.org/search/competitions/class/-HdMnIVmUeM",
                "horse": {
                  "name": "BELIEVE IN BLUE",
                  "usefHorseId": "5010509",
                  "link": "https://www.usef.org/search/horses/display/qd0-mZmCg4o?year=2024"
                },
                "entries": "5",
                "placing": "3",
                "natlPoints": "8.00",
                "zonePoints": "8.00",
                "backNumber": "1172",
                "dressagePercentage": null
              },
              {
                "classCode": "412",
                "classTitle": "412 - Small/Medium Pony Hunter - FP",
                "classUrl": "https://www.usef.org/search/competitions/class/qdoPuRZ-C-s",
                "horse": {
                  "name": "BELIEVE IN BLUE",
                  "usefHorseId": "5010509",
                  "link": "https://www.usef.org/search/horses/display/qd0-mZmCg4o?year=2024"
                },
                "entries": "7",
                "placing": "1",
                "natlPoints": "15.00",
                "zonePoints": "15.00",
                "backNumber": "1172",
                "dressagePercentage": null
              },
              {
                "classCode": "413",
                "classTitle": "413 - Small/Medium Pony Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/eQ2ic-UK76Q",
                "horse": {
                  "name": "BELIEVE IN BLUE",
                  "usefHorseId": "5010509",
                  "link": "https://www.usef.org/search/horses/display/qd0-mZmCg4o?year=2024"
                },
                "entries": "6",
                "placing": "1",
                "natlPoints": "15.00",
                "zonePoints": "15.00",
                "backNumber": "1172",
                "dressagePercentage": null
              },
              {
                "classCode": "414",
                "classTitle": "414 - Small/Medium Pony Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/5kRbaAi8p-E",
                "horse": {
                  "name": "BELIEVE IN BLUE",
                  "usefHorseId": "5010509",
                  "link": "https://www.usef.org/search/horses/display/qd0-mZmCg4o?year=2024"
                },
                "entries": "5",
                "placing": "1",
                "natlPoints": "15.00",
                "zonePoints": "15.00",
                "backNumber": "1172",
                "dressagePercentage": null
              },
              {
                "classCode": "415",
                "classTitle": "415 - Small/Medium Pony Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/bhchjTXFAQI",
                "horse": {
                  "name": "BELIEVE IN BLUE",
                  "usefHorseId": "5010509",
                  "link": "https://www.usef.org/search/horses/display/qd0-mZmCg4o?year=2024"
                },
                "entries": "5",
                "placing": "2",
                "natlPoints": "10.00",
                "zonePoints": "10.00",
                "backNumber": "1172",
                "dressagePercentage": null
              },
              {
                "classCode": null,
                "classTitle": "PHSMC - Pony Hunter - Small/Medium - CHAMPIONSHIP",
                "classUrl": "https://www.usef.org/search/competitions/class/aQ5oMiAiAOo",
                "horse": {
                  "name": "BELIEVE IN BLUE",
                  "usefHorseId": "5010509",
                  "link": "https://www.usef.org/search/horses/display/qd0-mZmCg4o?year=2024"
                },
                "entries": "7",
                "placing": "1",
                "natlPoints": "30.00",
                "zonePoints": "30.00",
                "backNumber": "1172",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "2701",
            "sectionName": "CHILDRENS HUNTER-PONY",
            "classes": [
              {
                "classCode": "405",
                "classTitle": "405 - Children's Pony Hunter U/S",
                "classUrl": "https://www.usef.org/search/competitions/class/nt7cbyQU-c8",
                "horse": {
                  "name": "JUSTAMERE'S LA-DI-DA",
                  "usefHorseId": "4981647",
                  "link": "https://www.usef.org/search/horses/display/YtpYUQuL1Uk?year=2024"
                },
                "entries": "7",
                "placing": "1",
                "natlPoints": "15.00",
                "zonePoints": "15.00",
                "backNumber": "1171",
                "dressagePercentage": null
              },
              {
                "classCode": "406",
                "classTitle": "406 - Children's Pony Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/RknaIMqsygE",
                "horse": {
                  "name": "JUSTAMERE'S LA-DI-DA",
                  "usefHorseId": "4981647",
                  "link": "https://www.usef.org/search/horses/display/YtpYUQuL1Uk?year=2024"
                },
                "entries": "7",
                "placing": "1",
                "natlPoints": "15.00",
                "zonePoints": "15.00",
                "backNumber": "1171",
                "dressagePercentage": null
              },
              {
                "classCode": "407",
                "classTitle": "407 - Children's Pony Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/e0bRqI0F8Is",
                "horse": {
                  "name": "JUSTAMERE'S LA-DI-DA",
                  "usefHorseId": "4981647",
                  "link": "https://www.usef.org/search/horses/display/YtpYUQuL1Uk?year=2024"
                },
                "entries": "7",
                "placing": "3",
                "natlPoints": "8.00",
                "zonePoints": "8.00",
                "backNumber": "1171",
                "dressagePercentage": null
              },
              {
                "classCode": "408",
                "classTitle": "408 - Children's Pony Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/_IODfxUw9ro",
                "horse": {
                  "name": "JUSTAMERE'S LA-DI-DA",
                  "usefHorseId": "4981647",
                  "link": "https://www.usef.org/search/horses/display/YtpYUQuL1Uk?year=2024"
                },
                "entries": "7",
                "placing": "4",
                "natlPoints": "6.00",
                "zonePoints": "6.00",
                "backNumber": "1171",
                "dressagePercentage": null
              },
              {
                "classCode": "409",
                "classTitle": "409 - Children's Pony Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/Nl9h_ZYoxBQ",
                "horse": {
                  "name": "JUSTAMERE'S LA-DI-DA",
                  "usefHorseId": "4981647",
                  "link": "https://www.usef.org/search/horses/display/YtpYUQuL1Uk?year=2024"
                },
                "entries": "7",
                "placing": "1",
                "natlPoints": "15.00",
                "zonePoints": "15.00",
                "backNumber": "1171",
                "dressagePercentage": null
              },
              {
                "classCode": "960",
                "classTitle": "960 - $500 USHJA Zone 4 Children's Pony Handy Hunter Challenge",
                "classUrl": "https://www.usef.org/search/competitions/class/qicfTARJO7o",
                "horse": {
                  "name": "JUSTAMERE'S LA-DI-DA",
                  "usefHorseId": "4981647",
                  "link": "https://www.usef.org/search/horses/display/YtpYUQuL1Uk?year=2024"
                },
                "entries": "5",
                "placing": "1",
                "natlPoints": "15.00",
                "zonePoints": "15.00",
                "backNumber": "1171",
                "dressagePercentage": null
              },
              {
                "classCode": null,
                "classTitle": "CPHC - Children's Pony Hunter - CHAMPIONSHIP",
                "classUrl": "https://www.usef.org/search/competitions/class/AB6du2cenUs",
                "horse": {
                  "name": "JUSTAMERE'S LA-DI-DA",
                  "usefHorseId": "4981647",
                  "link": "https://www.usef.org/search/horses/display/YtpYUQuL1Uk?year=2024"
                },
                "entries": "7",
                "placing": "1",
                "natlPoints": "30.00",
                "zonePoints": "30.00",
                "backNumber": "1171",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3100",
            "sectionName": "MISC. HUNTER (No points earned)",
            "classes": [
              {
                "classCode": "654",
                "classTitle": "654 - Warm Up",
                "classUrl": "https://www.usef.org/search/competitions/class/gP2NlDZB4C4",
                "horse": {
                  "name": "JUSTAMERE'S LA-DI-DA",
                  "usefHorseId": "4981647",
                  "link": "https://www.usef.org/search/horses/display/YtpYUQuL1Uk?year=2024"
                },
                "entries": "4",
                "placing": "1",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1171",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3117",
            "sectionName": "HUNTER EQUITATION 12-14",
            "classes": [
              {
                "classCode": "512",
                "classTitle": "512 - 12-14 Equitation Flat",
                "classUrl": "https://www.usef.org/search/competitions/class/UkKvXqR5DAw",
                "horse": {
                  "name": "BON BROWN",
                  "usefHorseId": "5497224",
                  "link": "https://www.usef.org/search/horses/display/9mze4f0kbgo?year=2024"
                },
                "entries": "4",
                "placing": "3",
                "natlPoints": "10.00",
                "zonePoints": "10.00",
                "backNumber": "1219",
                "dressagePercentage": null
              },
              {
                "classCode": "513",
                "classTitle": "513 - 12-14 Equitation (2'9 )",
                "classUrl": "https://www.usef.org/search/competitions/class/Wo9QqFumVpc",
                "horse": {
                  "name": "BON BROWN",
                  "usefHorseId": "5497224",
                  "link": "https://www.usef.org/search/horses/display/9mze4f0kbgo?year=2024"
                },
                "entries": "4",
                "placing": "2",
                "natlPoints": "15.00",
                "zonePoints": "15.00",
                "backNumber": "1219",
                "dressagePercentage": null
              },
              {
                "classCode": "514",
                "classTitle": "514 - 12-14 Equitation (2'9 )",
                "classUrl": "https://www.usef.org/search/competitions/class/_OU7c9bstJs",
                "horse": {
                  "name": "BON BROWN",
                  "usefHorseId": "5497224",
                  "link": "https://www.usef.org/search/horses/display/9mze4f0kbgo?year=2024"
                },
                "entries": "4",
                "placing": "1",
                "natlPoints": "20.00",
                "zonePoints": "20.00",
                "backNumber": "1219",
                "dressagePercentage": null
              },
              {
                "classCode": null,
                "classTitle": "EQAA - Equitation 12-14 - CHAMPIONSHIP",
                "classUrl": "https://www.usef.org/search/competitions/class/23bGoEnZUq4",
                "horse": {
                  "name": "BON BROWN",
                  "usefHorseId": "5497224",
                  "link": "https://www.usef.org/search/horses/display/9mze4f0kbgo?year=2024"
                },
                "entries": "4",
                "placing": "2",
                "natlPoints": "24.00",
                "zonePoints": "24.00",
                "backNumber": "1219",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "233850",
        "competitionName": "EQUESTRIAN SPORT PRODUCTIONS, LLC. SPRING 2 (233850)",
        "id": "233850",
        "name": "EQUESTRIAN SPORT PRODUCTIONS, LLC. SPRING 2 (233850)",
        "startDate": "4/10/2024",
        "endDate": "4/14/2024",
        "start": "2024-04-10T04:00:00.000Z",
        "end": "2024-04-14T04:00:00.000Z",
        "year": 2024,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/5FBC07Rq53U",
        "sections": [
          {
            "sectionId": "2502",
            "sectionName": "PONY HUNTER-MEDIUM",
            "classes": [
              {
                "classCode": "421",
                "classTitle": "421 - Medium Pony Hunter U/S",
                "classUrl": "https://www.usef.org/search/competitions/class/3wajmj3dFRk",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2024"
                },
                "entries": "14",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "2664",
                "dressagePercentage": null
              },
              {
                "classCode": "422",
                "classTitle": "422 - Medium Pony Hunter FP",
                "classUrl": "https://www.usef.org/search/competitions/class/1xVlOKnjBng",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2024"
                },
                "entries": "14",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "2664",
                "dressagePercentage": null
              },
              {
                "classCode": "423",
                "classTitle": "423 - Medium Pony Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/yW_F1lT9_BA",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2024"
                },
                "entries": "14",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "2664",
                "dressagePercentage": null
              },
              {
                "classCode": "424",
                "classTitle": "424 - Medium Pony Conformation Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/vXejNdGP_mI",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2024"
                },
                "entries": "14",
                "placing": "8",
                "natlPoints": "5.00",
                "zonePoints": "5.00",
                "backNumber": "2664",
                "dressagePercentage": null
              },
              {
                "classCode": "425",
                "classTitle": "425 - Medium Pony Hunter Handy",
                "classUrl": "https://www.usef.org/search/competitions/class/05LI3FhrssM",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2024"
                },
                "entries": "14",
                "placing": "7",
                "natlPoints": "6.00",
                "zonePoints": "6.00",
                "backNumber": "2664",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3070",
            "sectionName": "USHJA PONY HUNTER DERBY",
            "classes": [
              {
                "classCode": "912",
                "classTitle": "912 - $1500 USHJA Pony Hunter Derby L/M/S",
                "classUrl": "https://www.usef.org/search/competitions/class/N6f2KEbuGSI",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2024"
                },
                "entries": "16",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "2664",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3100",
            "sectionName": "MISC. HUNTER (No points earned)",
            "classes": [
              {
                "classCode": "401",
                "classTitle": "401 - Schooling Pony (Reg Pony Height)",
                "classUrl": "https://www.usef.org/search/competitions/class/6hkehQM0LsQ",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2024"
                },
                "entries": "23",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "2664",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "200",
        "competitionName": "WEF 6 EQUESTRIAN SPORT PRODUCTIONS, LLC (200)",
        "id": "200",
        "name": "WEF 6 EQUESTRIAN SPORT PRODUCTIONS, LLC (200)",
        "startDate": "2/13/2024",
        "endDate": "2/18/2024",
        "start": "2024-02-13T05:00:00.000Z",
        "end": "2024-02-18T05:00:00.000Z",
        "year": 2024,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/SEgOw1LgaNA",
        "sections": [
          {
            "sectionId": "2701",
            "sectionName": "CHILDRENS HUNTER-PONY",
            "classes": [
              {
                "classCode": "2881",
                "classTitle": "2881 - Small/Medium Children's Pony Hunter U/S",
                "classUrl": "https://www.usef.org/search/competitions/class/GRubCZhj9Qs",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2024"
                },
                "entries": "28",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1798",
                "dressagePercentage": null
              },
              {
                "classCode": "2882",
                "classTitle": "2882 - Small/Medium Children's Pony Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/Fd2JuKM1Y1s",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2024"
                },
                "entries": "28",
                "placing": "7",
                "natlPoints": "14.00",
                "zonePoints": "14.00",
                "backNumber": "1798",
                "dressagePercentage": null
              },
              {
                "classCode": "2883",
                "classTitle": "2883 - Small/Medium Children's Pony Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/Z7Ih6aNkgkI",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2024"
                },
                "entries": "28",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1798",
                "dressagePercentage": null
              },
              {
                "classCode": "2884",
                "classTitle": "2884 - Small/Medium Children's Pony Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/H1axuJdMV-E",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2024"
                },
                "entries": "28",
                "placing": "2",
                "natlPoints": "28.00",
                "zonePoints": "28.00",
                "backNumber": "1798",
                "dressagePercentage": null
              },
              {
                "classCode": "605",
                "classTitle": "605 - $2500 WCHR Florida Small/Medium Children's Pony Hunter Classic",
                "classUrl": "https://www.usef.org/search/competitions/class/kiiZHhdRyeA",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2024"
                },
                "entries": "26",
                "placing": "2",
                "natlPoints": "89.25",
                "zonePoints": "63.75",
                "backNumber": "1798",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "619",
        "competitionName": "WEF 5  (619)",
        "id": "619",
        "name": "WEF 5  (619)",
        "startDate": "2/6/2024",
        "endDate": "2/11/2024",
        "start": "2024-02-06T05:00:00.000Z",
        "end": "2024-02-11T05:00:00.000Z",
        "year": 2024,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/H_pjl7cWcq8",
        "sections": [
          {
            "sectionId": "2053",
            "sectionName": "USHJA HUNTER 2'6\\"",
            "classes": [
              {
                "classCode": "4019",
                "classTitle": "4019 - USHJA Hunter 2'6",
                "classUrl": "https://www.usef.org/search/competitions/class/uV7y7-athm8",
                "horse": {
                  "name": "CENTO FOREVER",
                  "usefHorseId": "5531258",
                  "link": "https://www.usef.org/search/horses/display/5xBmmKo-p5U?year=2024"
                },
                "entries": "28",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1030",
                "dressagePercentage": null
              },
              {
                "classCode": "4020",
                "classTitle": "4020 - USHJA Hunter 2'6",
                "classUrl": "https://www.usef.org/search/competitions/class/fivc0pNg0tc",
                "horse": {
                  "name": "CENTO FOREVER",
                  "usefHorseId": "5531258",
                  "link": "https://www.usef.org/search/horses/display/5xBmmKo-p5U?year=2024"
                },
                "entries": "28",
                "placing": "8",
                "natlPoints": "13.00",
                "zonePoints": "13.00",
                "backNumber": "1030",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3199",
            "sectionName": "Misc Equitation",
            "classes": [
              {
                "classCode": "3075",
                "classTitle": "3075 - SFHJA Junior Hunt Seat Medal 14 & Under (Flat Phase)",
                "classUrl": "https://www.usef.org/search/competitions/class/aYh1F0MZz8c",
                "horse": {
                  "name": "CENTO FOREVER",
                  "usefHorseId": "5531258",
                  "link": "https://www.usef.org/search/horses/display/5xBmmKo-p5U?year=2024"
                },
                "entries": "10",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1030",
                "dressagePercentage": null
              },
              {
                "classCode": "3080",
                "classTitle": "3080 - THIS Children's Medal 14 & Under",
                "classUrl": "https://www.usef.org/search/competitions/class/A3douuv99fo",
                "horse": {
                  "name": "CENTO FOREVER",
                  "usefHorseId": "5531258",
                  "link": "https://www.usef.org/search/horses/display/5xBmmKo-p5U?year=2024"
                },
                "entries": "27",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1030",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "1893",
        "competitionName": "WEF 1 (1893)",
        "id": "1893",
        "name": "WEF 1 (1893)",
        "startDate": "1/10/2024",
        "endDate": "1/14/2024",
        "start": "2024-01-10T05:00:00.000Z",
        "end": "2024-01-14T05:00:00.000Z",
        "year": 2024,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/7PHnAI9xnJY",
        "sections": [
          {
            "sectionId": "2701",
            "sectionName": "CHILDRENS HUNTER-PONY",
            "classes": [
              {
                "classCode": "2881",
                "classTitle": "2881 - Small/Medium Children's Pony Hunter U/S",
                "classUrl": "https://www.usef.org/search/competitions/class/QWzvaHX22mY",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2024"
                },
                "entries": "25",
                "placing": "3",
                "natlPoints": "19.00",
                "zonePoints": "19.00",
                "backNumber": "1798",
                "dressagePercentage": null
              },
              {
                "classCode": "2882",
                "classTitle": "2882 - Small/Medium Children's Pony Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/Irxsqr2I0WI",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2024"
                },
                "entries": "25",
                "placing": "4",
                "natlPoints": "14.00",
                "zonePoints": "14.00",
                "backNumber": "1798",
                "dressagePercentage": null
              },
              {
                "classCode": "2883",
                "classTitle": "2883 - Small/Medium Children's Pony Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/q9DTKyglIyU",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2024"
                },
                "entries": "25",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1798",
                "dressagePercentage": null
              },
              {
                "classCode": "2884",
                "classTitle": "2884 - Small/Medium Children's Pony Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/VcMBpE5qLxQ",
                "horse": {
                  "name": "SUMMERWOOD'S BLUE STEEL",
                  "usefHorseId": "5348808",
                  "link": "https://www.usef.org/search/horses/display/cL6c44_riuA?year=2024"
                },
                "entries": "25",
                "placing": "5",
                "natlPoints": "13.00",
                "zonePoints": "13.00",
                "backNumber": "1798",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "2807",
        "competitionName": "EQUESTRIAN SPORT PRODUCTIONS, LLC. FLORIDA STATE FALL (2807)",
        "id": "2807",
        "name": "EQUESTRIAN SPORT PRODUCTIONS, LLC. FLORIDA STATE FALL (2807)",
        "startDate": "9/19/2024",
        "endDate": "9/22/2024",
        "start": "2024-09-19T04:00:00.000Z",
        "end": "2024-09-22T04:00:00.000Z",
        "year": 2024,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/XyCuaA5fx50",
        "sections": [
          {
            "sectionId": "3117",
            "sectionName": "HUNTER EQUITATION 12-14",
            "classes": [
              {
                "classCode": "512",
                "classTitle": "512 - 12-14 Equitation Flat",
                "classUrl": "https://www.usef.org/search/competitions/class/jJJ6nUq9_BI",
                "horse": {
                  "name": "KOBERLIN FH",
                  "usefHorseId": "5802679",
                  "link": "https://www.usef.org/search/horses/display/yGH-B_EsY6E?year=2024"
                },
                "entries": "6",
                "placing": "3",
                "natlPoints": "10.00",
                "zonePoints": "10.00",
                "backNumber": "1061",
                "dressagePercentage": null
              },
              {
                "classCode": "513",
                "classTitle": "513 - 12-14 Equitation (3')",
                "classUrl": "https://www.usef.org/search/competitions/class/M3_i_3ERJo8",
                "horse": {
                  "name": "KOBERLIN FH",
                  "usefHorseId": "5802679",
                  "link": "https://www.usef.org/search/horses/display/yGH-B_EsY6E?year=2024"
                },
                "entries": "5",
                "placing": "3",
                "natlPoints": "10.00",
                "zonePoints": "10.00",
                "backNumber": "1061",
                "dressagePercentage": null
              },
              {
                "classCode": "514",
                "classTitle": "514 - 12-14 Equitation (3')",
                "classUrl": "https://www.usef.org/search/competitions/class/kZE51Dw2pyg",
                "horse": {
                  "name": "KOBERLIN FH",
                  "usefHorseId": "5802679",
                  "link": "https://www.usef.org/search/horses/display/yGH-B_EsY6E?year=2024"
                },
                "entries": "5",
                "placing": "3",
                "natlPoints": "10.00",
                "zonePoints": "10.00",
                "backNumber": "1061",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3199",
            "sectionName": "Misc Equitation",
            "classes": [
              {
                "classCode": "530",
                "classTitle": "530 - Hamel Foundation/NHS 3'3  Medal",
                "classUrl": "https://www.usef.org/search/competitions/class/rt2h22TArgo",
                "horse": {
                  "name": "KOBERLIN FH",
                  "usefHorseId": "5802679",
                  "link": "https://www.usef.org/search/horses/display/yGH-B_EsY6E?year=2024"
                },
                "entries": "11",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1061",
                "dressagePercentage": null
              },
              {
                "classCode": "850",
                "classTitle": "850 - Hamel Foundation/NHS 3'3  Area Championship",
                "classUrl": "https://www.usef.org/search/competitions/class/gEhahb9mg50",
                "horse": {
                  "name": "KOBERLIN FH",
                  "usefHorseId": "5802679",
                  "link": "https://www.usef.org/search/horses/display/yGH-B_EsY6E?year=2024"
                },
                "entries": "17",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1061",
                "dressagePercentage": null
              },
              {
                "classCode": "870",
                "classTitle": "870 - 3'3  Equitation Warm Up",
                "classUrl": "https://www.usef.org/search/competitions/class/2SBfelrzLZg",
                "horse": {
                  "name": "KOBERLIN FH",
                  "usefHorseId": "5802679",
                  "link": "https://www.usef.org/search/horses/display/yGH-B_EsY6E?year=2024"
                },
                "entries": "18",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1061",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "4049",
        "competitionName": "EQUESTRIAN SPORT PRODUCTIONS, LLC. SEPTEMBER (4049)",
        "id": "4049",
        "name": "EQUESTRIAN SPORT PRODUCTIONS, LLC. SEPTEMBER (4049)",
        "startDate": "9/12/2024",
        "endDate": "9/15/2024",
        "start": "2024-09-12T04:00:00.000Z",
        "end": "2024-09-15T04:00:00.000Z",
        "year": 2024,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/UxsZGQW-aj4",
        "sections": [
          {
            "sectionId": "3000",
            "sectionName": "HUNTER CLASSIC",
            "classes": [
              {
                "classCode": "909",
                "classTitle": "909 - $1000 Amateur Owner/Junior Hunter 3'3 /3'6  Classic",
                "classUrl": "https://www.usef.org/search/competitions/class/XIKxfbYxvKw",
                "horse": {
                  "name": "KOBERLIN FH",
                  "usefHorseId": "5802679",
                  "link": "https://www.usef.org/search/horses/display/yGH-B_EsY6E?year=2024"
                },
                "entries": "7",
                "placing": "3",
                "natlPoints": "26.25",
                "zonePoints": "18.75",
                "backNumber": "1061",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3100",
            "sectionName": "MISC. HUNTER (No points earned)",
            "classes": [
              {
                "classCode": "209",
                "classTitle": "209 - Add Back Hunter (Coded)",
                "classUrl": "https://www.usef.org/search/competitions/class/etJAakUp1sY",
                "horse": {
                  "name": "KOBERLIN FH",
                  "usefHorseId": "5802679",
                  "link": "https://www.usef.org/search/horses/display/yGH-B_EsY6E?year=2024"
                },
                "entries": "7",
                "placing": "7",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1061",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3199",
            "sectionName": "Misc Equitation",
            "classes": [
              {
                "classCode": "525",
                "classTitle": "525 - SFHJA Junior/Adult Amateur Medal (Flat Phase)",
                "classUrl": "https://www.usef.org/search/competitions/class/ip9K4cPfp6Y",
                "horse": {
                  "name": "KOBERLIN FH",
                  "usefHorseId": "5802679",
                  "link": "https://www.usef.org/search/horses/display/yGH-B_EsY6E?year=2024"
                },
                "entries": "10",
                "placing": "6",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1061",
                "dressagePercentage": null
              },
              {
                "classCode": "555",
                "classTitle": "555 - THIS Children's Medal",
                "classUrl": "https://www.usef.org/search/competitions/class/qABVUzj56rQ",
                "horse": {
                  "name": "KOBERLIN FH",
                  "usefHorseId": "5802679",
                  "link": "https://www.usef.org/search/horses/display/yGH-B_EsY6E?year=2024"
                },
                "entries": "6",
                "placing": "5",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1061",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3800",
            "sectionName": "MISC JUMPER",
            "classes": [
              {
                "classCode": "751",
                "classTitle": "751 - Training Jumper (.95m) II2d",
                "classUrl": "https://www.usef.org/search/competitions/class/GPdgodjq1aI",
                "horse": {
                  "name": "KOBERLIN FH",
                  "usefHorseId": "5802679",
                  "link": "https://www.usef.org/search/horses/display/yGH-B_EsY6E?year=2024"
                },
                "entries": "12",
                "placing": "8",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1061",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "9303",
            "sectionName": "JUNIOR/AMATEUR OWNER HUNTER 3'3\\"",
            "classes": [
              {
                "classCode": "336",
                "classTitle": "336 - Amateur Owner/Junior Hunter 3'6 /3'3  U/S",
                "classUrl": "https://www.usef.org/search/competitions/class/3RZPOMdxHqs",
                "horse": {
                  "name": "KOBERLIN FH",
                  "usefHorseId": "5802679",
                  "link": "https://www.usef.org/search/horses/display/yGH-B_EsY6E?year=2024"
                },
                "entries": "9",
                "placing": "6",
                "natlPoints": "7.00",
                "zonePoints": "7.00",
                "backNumber": "1061",
                "dressagePercentage": null
              },
              {
                "classCode": "337",
                "classTitle": "337 - Amateur Owner/Junior Hunter 3'6 /3'3 - FP",
                "classUrl": "https://www.usef.org/search/competitions/class/J10h1u2w0Ec",
                "horse": {
                  "name": "KOBERLIN FH",
                  "usefHorseId": "5802679",
                  "link": "https://www.usef.org/search/horses/display/yGH-B_EsY6E?year=2024"
                },
                "entries": "9",
                "placing": "4",
                "natlPoints": "9.00",
                "zonePoints": "9.00",
                "backNumber": "1061",
                "dressagePercentage": null
              },
              {
                "classCode": "338",
                "classTitle": "338 - Amateur Owner/Junior Hunter 3'6 /3'3",
                "classUrl": "https://www.usef.org/search/competitions/class/QlqtQep4Nsc",
                "horse": {
                  "name": "KOBERLIN FH",
                  "usefHorseId": "5802679",
                  "link": "https://www.usef.org/search/horses/display/yGH-B_EsY6E?year=2024"
                },
                "entries": "9",
                "placing": "4",
                "natlPoints": "9.00",
                "zonePoints": "9.00",
                "backNumber": "1061",
                "dressagePercentage": null
              },
              {
                "classCode": "339",
                "classTitle": "339 - Amateur Owner/Junior Hunter 3'6 /3'3",
                "classUrl": "https://www.usef.org/search/competitions/class/ILfizAMCrr4",
                "horse": {
                  "name": "KOBERLIN FH",
                  "usefHorseId": "5802679",
                  "link": "https://www.usef.org/search/horses/display/yGH-B_EsY6E?year=2024"
                },
                "entries": "9",
                "placing": "4",
                "natlPoints": "9.00",
                "zonePoints": "9.00",
                "backNumber": "1061",
                "dressagePercentage": null
              },
              {
                "classCode": "340",
                "classTitle": "340 - Amateur Owner/Junior Hunter 3'6 /3'3  Handy",
                "classUrl": "https://www.usef.org/search/competitions/class/J_mOLyFudhQ",
                "horse": {
                  "name": "KOBERLIN FH",
                  "usefHorseId": "5802679",
                  "link": "https://www.usef.org/search/horses/display/yGH-B_EsY6E?year=2024"
                },
                "entries": "8",
                "placing": "5",
                "natlPoints": "8.00",
                "zonePoints": "8.00",
                "backNumber": "1061",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "6371",
        "competitionName": "EQUESTRIAN SPORT PRODUCTIONS, LLC. LABOR DAY A (6371)",
        "id": "6371",
        "name": "EQUESTRIAN SPORT PRODUCTIONS, LLC. LABOR DAY A (6371)",
        "startDate": "8/29/2024",
        "endDate": "9/1/2024",
        "start": "2024-08-29T04:00:00.000Z",
        "end": "2024-09-01T04:00:00.000Z",
        "year": 2024,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/15f0vqqzb_c",
        "sections": [
          {
            "sectionId": "2050",
            "sectionName": "USHJA HUNTER",
            "classes": [
              {
                "classCode": "222",
                "classTitle": "222 - USHJA Hunter 3'/2'9 FP",
                "classUrl": "https://www.usef.org/search/competitions/class/LAfMxQ4UB8k",
                "horse": {
                  "name": "SIR SANTINO",
                  "usefHorseId": "5504287",
                  "link": "https://www.usef.org/search/horses/display/ZCKWvF9vErM?year=2024"
                },
                "entries": "10",
                "placing": "4",
                "natlPoints": "9.00",
                "zonePoints": "9.00",
                "backNumber": "739",
                "dressagePercentage": null
              },
              {
                "classCode": "222",
                "classTitle": "222 - USHJA Hunter 3'/2'9 FP",
                "classUrl": "https://www.usef.org/search/competitions/class/LAfMxQ4UB8k",
                "horse": {
                  "name": "KOBERLIN FH",
                  "usefHorseId": "5802679",
                  "link": "https://www.usef.org/search/horses/display/yGH-B_EsY6E?year=2024"
                },
                "entries": "10",
                "placing": "5",
                "natlPoints": "8.00",
                "zonePoints": "8.00",
                "backNumber": "1061",
                "dressagePercentage": null
              },
              {
                "classCode": "223",
                "classTitle": "223 - USHJA Hunter 3'/2'9",
                "classUrl": "https://www.usef.org/search/competitions/class/i21T5rPVhQ0",
                "horse": {
                  "name": "SIR SANTINO",
                  "usefHorseId": "5504287",
                  "link": "https://www.usef.org/search/horses/display/ZCKWvF9vErM?year=2024"
                },
                "entries": "10",
                "placing": "5",
                "natlPoints": "8.00",
                "zonePoints": "8.00",
                "backNumber": "739",
                "dressagePercentage": null
              },
              {
                "classCode": "223",
                "classTitle": "223 - USHJA Hunter 3'/2'9",
                "classUrl": "https://www.usef.org/search/competitions/class/i21T5rPVhQ0",
                "horse": {
                  "name": "KOBERLIN FH",
                  "usefHorseId": "5802679",
                  "link": "https://www.usef.org/search/horses/display/yGH-B_EsY6E?year=2024"
                },
                "entries": "10",
                "placing": "7",
                "natlPoints": "6.00",
                "zonePoints": "6.00",
                "backNumber": "1061",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3100",
            "sectionName": "MISC. HUNTER (No points earned)",
            "classes": [
              {
                "classCode": "207",
                "classTitle": "207 - Add Back Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/qaBFm0syvDI",
                "horse": {
                  "name": "KOBERLIN FH",
                  "usefHorseId": "5802679",
                  "link": "https://www.usef.org/search/horses/display/yGH-B_EsY6E?year=2024"
                },
                "entries": "8",
                "placing": "2",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1061",
                "dressagePercentage": null
              },
              {
                "classCode": "658",
                "classTitle": "658 - Warm Up Hunter 3'",
                "classUrl": "https://www.usef.org/search/competitions/class/FjZcoSZoX0Q",
                "horse": {
                  "name": "KOBERLIN FH",
                  "usefHorseId": "5802679",
                  "link": "https://www.usef.org/search/horses/display/yGH-B_EsY6E?year=2024"
                },
                "entries": "2",
                "placing": "1",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1061",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3104",
            "sectionName": "COMBINED HUNTER EQUITATION - 17/U",
            "classes": [
              {
                "classCode": "512",
                "classTitle": "512 - 12-17 Equitation Flat",
                "classUrl": "https://www.usef.org/search/competitions/class/tdHnKS109p4",
                "horse": {
                  "name": "SIR SANTINO",
                  "usefHorseId": "5504287",
                  "link": "https://www.usef.org/search/horses/display/ZCKWvF9vErM?year=2024"
                },
                "entries": "3",
                "placing": "1",
                "natlPoints": "0.00",
                "zonePoints": "20.00",
                "backNumber": "739",
                "dressagePercentage": null
              },
              {
                "classCode": "513",
                "classTitle": "513 - 12-17 Equitation (12-14 2'9 /15-17 3')",
                "classUrl": "https://www.usef.org/search/competitions/class/Pg1N9O1cZRk",
                "horse": {
                  "name": "SIR SANTINO",
                  "usefHorseId": "5504287",
                  "link": "https://www.usef.org/search/horses/display/ZCKWvF9vErM?year=2024"
                },
                "entries": "3",
                "placing": "RF",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "739",
                "dressagePercentage": null
              },
              {
                "classCode": "514",
                "classTitle": "514 - 12-17 Equitation (12-14 2'9 /15-17 3')",
                "classUrl": "https://www.usef.org/search/competitions/class/Z6YjY5efcDY",
                "horse": {
                  "name": "SIR SANTINO",
                  "usefHorseId": "5504287",
                  "link": "https://www.usef.org/search/horses/display/ZCKWvF9vErM?year=2024"
                },
                "entries": "3",
                "placing": "2",
                "natlPoints": "0.00",
                "zonePoints": "15.00",
                "backNumber": "739",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3199",
            "sectionName": "Misc Equitation",
            "classes": [
              {
                "classCode": "10513",
                "classTitle": "10513 - Equitation 12-17 Championship (N/A Due to Section Requirements)",
                "classUrl": "https://www.usef.org/search/competitions/class/MeBFlG_2S3w",
                "horse": {
                  "name": "SIR SANTINO",
                  "usefHorseId": "5504287",
                  "link": "https://www.usef.org/search/horses/display/ZCKWvF9vErM?year=2024"
                },
                "entries": "3",
                "placing": "2",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "739",
                "dressagePercentage": null
              },
              {
                "classCode": "525",
                "classTitle": "525 - SFHJA Junior/Adult Amateur Medal (Flat Phase)",
                "classUrl": "https://www.usef.org/search/competitions/class/7rX2f6gmXPc",
                "horse": {
                  "name": "KOBERLIN FH",
                  "usefHorseId": "5802679",
                  "link": "https://www.usef.org/search/horses/display/yGH-B_EsY6E?year=2024"
                },
                "entries": "7",
                "placing": "4",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1061",
                "dressagePercentage": null
              },
              {
                "classCode": "529",
                "classTitle": "529 - M&S Child/Adult Amateur Medal",
                "classUrl": "https://www.usef.org/search/competitions/class/ucRiGtArHR0",
                "horse": {
                  "name": "KOBERLIN FH",
                  "usefHorseId": "5802679",
                  "link": "https://www.usef.org/search/horses/display/yGH-B_EsY6E?year=2024"
                },
                "entries": "4",
                "placing": "4",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1061",
                "dressagePercentage": null
              },
              {
                "classCode": "555",
                "classTitle": "555 - THIS Children's Medal",
                "classUrl": "https://www.usef.org/search/competitions/class/61YYM-yUiko",
                "horse": {
                  "name": "KOBERLIN FH",
                  "usefHorseId": "5802679",
                  "link": "https://www.usef.org/search/horses/display/yGH-B_EsY6E?year=2024"
                },
                "entries": "4",
                "placing": "3",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1061",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "6050",
            "sectionName": "USEF/NCEA Junior Hunter Seat Medal",
            "classes": [
              {
                "classCode": "585",
                "classTitle": "585 - USEF/NCEA Junior Hunter Seat Medal",
                "classUrl": "https://www.usef.org/search/competitions/class/E8JOgoCN_eI",
                "horse": {
                  "name": "SIR SANTINO",
                  "usefHorseId": "5504287",
                  "link": "https://www.usef.org/search/horses/display/ZCKWvF9vErM?year=2024"
                },
                "entries": "1",
                "placing": "1",
                "natlPoints": "10.00",
                "zonePoints": "0.00",
                "backNumber": "739",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "230675",
        "competitionName": "EQUESTRIAN SPORT PRODUCTIONS, LLC. SUMMER III (230675)",
        "id": "230675",
        "name": "EQUESTRIAN SPORT PRODUCTIONS, LLC. SUMMER III (230675)",
        "startDate": "8/22/2024",
        "endDate": "8/25/2024",
        "start": "2024-08-22T04:00:00.000Z",
        "end": "2024-08-25T04:00:00.000Z",
        "year": 2024,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/EdfW1FFoOSc",
        "sections": [
          {
            "sectionId": "2055",
            "sectionName": "USHJA HUNTER 3'0\\"",
            "classes": [
              {
                "classCode": "222",
                "classTitle": "222 - USHJA Hunter 3' FP",
                "classUrl": "https://www.usef.org/search/competitions/class/G6Ix9fRdto4",
                "horse": {
                  "name": "SIR SANTINO",
                  "usefHorseId": "5504287",
                  "link": "https://www.usef.org/search/horses/display/ZCKWvF9vErM?year=2024"
                },
                "entries": "7",
                "placing": "7",
                "natlPoints": "3.00",
                "zonePoints": "3.00",
                "backNumber": "739",
                "dressagePercentage": null
              },
              {
                "classCode": "223",
                "classTitle": "223 - USHJA Hunter 3'",
                "classUrl": "https://www.usef.org/search/competitions/class/9ZpYhY43zVI",
                "horse": {
                  "name": "SIR SANTINO",
                  "usefHorseId": "5504287",
                  "link": "https://www.usef.org/search/horses/display/ZCKWvF9vErM?year=2024"
                },
                "entries": "6",
                "placing": "3",
                "natlPoints": "8.00",
                "zonePoints": "8.00",
                "backNumber": "739",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3100",
            "sectionName": "MISC. HUNTER (No points earned)",
            "classes": [
              {
                "classCode": "207",
                "classTitle": "207 - Add Back Hunter (Coded)",
                "classUrl": "https://www.usef.org/search/competitions/class/mrNTg8x8jUo",
                "horse": {
                  "name": "SIR SANTINO",
                  "usefHorseId": "5504287",
                  "link": "https://www.usef.org/search/horses/display/ZCKWvF9vErM?year=2024"
                },
                "entries": "6",
                "placing": "3",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "739",
                "dressagePercentage": null
              },
              {
                "classCode": "651",
                "classTitle": "651 - Warm Up Hunter (Coded)",
                "classUrl": "https://www.usef.org/search/competitions/class/C1SqtfQ_vLE",
                "horse": {
                  "name": "SIR SANTINO",
                  "usefHorseId": "5504287",
                  "link": "https://www.usef.org/search/horses/display/ZCKWvF9vErM?year=2024"
                },
                "entries": "4",
                "placing": "1",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "739",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "9301",
            "sectionName": "CHILDREN/ADULT AMATEUR HUNTER",
            "classes": [
              {
                "classCode": "281",
                "classTitle": "281 - Child/Adult Amateur Hunter U/S",
                "classUrl": "https://www.usef.org/search/competitions/class/b4C886wqLmU",
                "horse": {
                  "name": "SIR SANTINO",
                  "usefHorseId": "5504287",
                  "link": "https://www.usef.org/search/horses/display/ZCKWvF9vErM?year=2024"
                },
                "entries": "4",
                "placing": "3",
                "natlPoints": "8.00",
                "zonePoints": "8.00",
                "backNumber": "739",
                "dressagePercentage": null
              },
              {
                "classCode": "282",
                "classTitle": "282 - Child/Adult Amateur Hunter FP",
                "classUrl": "https://www.usef.org/search/competitions/class/A2LumOJgAZA",
                "horse": {
                  "name": "SIR SANTINO",
                  "usefHorseId": "5504287",
                  "link": "https://www.usef.org/search/horses/display/ZCKWvF9vErM?year=2024"
                },
                "entries": "6",
                "placing": "4",
                "natlPoints": "6.00",
                "zonePoints": "6.00",
                "backNumber": "739",
                "dressagePercentage": null
              },
              {
                "classCode": "283",
                "classTitle": "283 - Child/Adult Amateur Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/X67TsCh36PI",
                "horse": {
                  "name": "SIR SANTINO",
                  "usefHorseId": "5504287",
                  "link": "https://www.usef.org/search/horses/display/ZCKWvF9vErM?year=2024"
                },
                "entries": "5",
                "placing": "5",
                "natlPoints": "5.00",
                "zonePoints": "5.00",
                "backNumber": "739",
                "dressagePercentage": null
              },
              {
                "classCode": "284",
                "classTitle": "284 - Child/Adult Amateur Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/A6EU4R0zgDQ",
                "horse": {
                  "name": "SIR SANTINO",
                  "usefHorseId": "5504287",
                  "link": "https://www.usef.org/search/horses/display/ZCKWvF9vErM?year=2024"
                },
                "entries": "3",
                "placing": "3",
                "natlPoints": "8.00",
                "zonePoints": "8.00",
                "backNumber": "739",
                "dressagePercentage": null
              },
              {
                "classCode": "285",
                "classTitle": "285 - Child/Adult Amateur Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/k3IXm36ke5o",
                "horse": {
                  "name": "SIR SANTINO",
                  "usefHorseId": "5504287",
                  "link": "https://www.usef.org/search/horses/display/ZCKWvF9vErM?year=2024"
                },
                "entries": "3",
                "placing": "1",
                "natlPoints": "15.00",
                "zonePoints": "15.00",
                "backNumber": "739",
                "dressagePercentage": null
              },
              {
                "classCode": "904",
                "classTitle": "904 - $500 M&S/NAL/WIHS Child/Adult Amateur Hunter Classic",
                "classUrl": "https://www.usef.org/search/competitions/class/RMa6buZ7LKI",
                "horse": {
                  "name": "SIR SANTINO",
                  "usefHorseId": "5504287",
                  "link": "https://www.usef.org/search/horses/display/ZCKWvF9vErM?year=2024"
                },
                "entries": "4",
                "placing": "4",
                "natlPoints": "17.50",
                "zonePoints": "12.50",
                "backNumber": "739",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "307815",
        "competitionName": "EQUESTRIAN SPORT PRODUCTIONS, LLC. SUMMER II (307815)",
        "id": "307815",
        "name": "EQUESTRIAN SPORT PRODUCTIONS, LLC. SUMMER II (307815)",
        "startDate": "8/15/2024",
        "endDate": "8/18/2024",
        "start": "2024-08-15T04:00:00.000Z",
        "end": "2024-08-18T04:00:00.000Z",
        "year": 2024,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/RfOOLu-gT7U",
        "sections": [
          {
            "sectionId": "2050",
            "sectionName": "USHJA HUNTER",
            "classes": [
              {
                "classCode": "222",
                "classTitle": "222 - USHJA Hunter 2'9  & 3'",
                "classUrl": "https://www.usef.org/search/competitions/class/c2dXf2f3bNA",
                "horse": {
                  "name": "CENTO FOREVER",
                  "usefHorseId": "5531258",
                  "link": "https://www.usef.org/search/horses/display/5xBmmKo-p5U?year=2024"
                },
                "entries": "8",
                "placing": "1",
                "natlPoints": "15.00",
                "zonePoints": "15.00",
                "backNumber": "694",
                "dressagePercentage": null
              },
              {
                "classCode": "223",
                "classTitle": "223 - USHJA Hunter 2'9  & 3'",
                "classUrl": "https://www.usef.org/search/competitions/class/FO0qQiHPhV0",
                "horse": {
                  "name": "CENTO FOREVER",
                  "usefHorseId": "5531258",
                  "link": "https://www.usef.org/search/horses/display/5xBmmKo-p5U?year=2024"
                },
                "entries": "6",
                "placing": "2",
                "natlPoints": "10.00",
                "zonePoints": "10.00",
                "backNumber": "694",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3100",
            "sectionName": "MISC. HUNTER (No points earned)",
            "classes": [
              {
                "classCode": "207",
                "classTitle": "207 - Add Back Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/mSycm-iMsaI",
                "horse": {
                  "name": "CENTO FOREVER",
                  "usefHorseId": "5531258",
                  "link": "https://www.usef.org/search/horses/display/5xBmmKo-p5U?year=2024"
                },
                "entries": "8",
                "placing": "6",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "694",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3199",
            "sectionName": "Misc Equitation",
            "classes": [
              {
                "classCode": "530",
                "classTitle": "530 - Hamel Foundation/NHS 3'3  Medal",
                "classUrl": "https://www.usef.org/search/competitions/class/vlcsRJsAsmo",
                "horse": {
                  "name": "CENTO FOREVER",
                  "usefHorseId": "5531258",
                  "link": "https://www.usef.org/search/horses/display/5xBmmKo-p5U?year=2024"
                },
                "entries": "8",
                "placing": "4",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "694",
                "dressagePercentage": null
              },
              {
                "classCode": "531",
                "classTitle": "531 - M&S Child/Adult Amateur Medal",
                "classUrl": "https://www.usef.org/search/competitions/class/4PH-Bwcz7zs",
                "horse": {
                  "name": "CENTO FOREVER",
                  "usefHorseId": "5531258",
                  "link": "https://www.usef.org/search/horses/display/5xBmmKo-p5U?year=2024"
                },
                "entries": "5",
                "placing": "2",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "694",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "6360",
            "sectionName": "USHJA 3'3\\" HUNTER SEAT MEDAL",
            "classes": [
              {
                "classCode": "535",
                "classTitle": "535 - USHJA 3'3  Hunter Seat Medal",
                "classUrl": "https://www.usef.org/search/competitions/class/BKAOQiSfLWo",
                "horse": {
                  "name": "CENTO FOREVER",
                  "usefHorseId": "5531258",
                  "link": "https://www.usef.org/search/horses/display/5xBmmKo-p5U?year=2024"
                },
                "entries": "6",
                "placing": "4",
                "natlPoints": "3.00",
                "zonePoints": "0.00",
                "backNumber": "694",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "340305",
        "competitionName": "WEC OCALA SUMMER #4 (340305)",
        "id": "340305",
        "name": "WEC OCALA SUMMER #4 (340305)",
        "startDate": "7/2/2024",
        "endDate": "7/7/2024",
        "start": "2024-07-02T04:00:00.000Z",
        "end": "2024-07-07T04:00:00.000Z",
        "year": 2024,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/zg-zIyDpSMA",
        "sections": [
          {
            "sectionId": "2055",
            "sectionName": "USHJA HUNTER 3'0\\"",
            "classes": [
              {
                "classCode": "275",
                "classTitle": "275 - USHJA Hunter 3' FP",
                "classUrl": "https://www.usef.org/search/competitions/class/7z0em3fLnr8",
                "horse": {
                  "name": "MAHALO",
                  "usefHorseId": "5814560",
                  "link": "https://www.usef.org/search/horses/display/Y7hFHkVwDaI?year=2024"
                },
                "entries": "10",
                "placing": "3",
                "natlPoints": "15.00",
                "zonePoints": "15.00",
                "backNumber": "2956",
                "dressagePercentage": null
              },
              {
                "classCode": "276",
                "classTitle": "276 - USHJA Hunter 3'",
                "classUrl": "https://www.usef.org/search/competitions/class/Npu96zLOd5k",
                "horse": {
                  "name": "MAHALO",
                  "usefHorseId": "5814560",
                  "link": "https://www.usef.org/search/horses/display/Y7hFHkVwDaI?year=2024"
                },
                "entries": "9",
                "placing": "5",
                "natlPoints": "10.00",
                "zonePoints": "10.00",
                "backNumber": "2956",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3104",
            "sectionName": "COMBINED HUNTER EQUITATION - 17/U",
            "classes": [
              {
                "classCode": "503",
                "classTitle": "503 - Equitation 12-14 2'9'/15-17 3'3",
                "classUrl": "https://www.usef.org/search/competitions/class/UZNYre47CnM",
                "horse": {
                  "name": "MAHALO",
                  "usefHorseId": "5814560",
                  "link": "https://www.usef.org/search/horses/display/Y7hFHkVwDaI?year=2024"
                },
                "entries": "5",
                "placing": "4",
                "natlPoints": "0.00",
                "zonePoints": "6.00",
                "backNumber": "2956",
                "dressagePercentage": null
              },
              {
                "classCode": "504",
                "classTitle": "504 - Equitation 12-14 2'9'/15-17 3'3",
                "classUrl": "https://www.usef.org/search/competitions/class/lmvM4m1YAJw",
                "horse": {
                  "name": "MAHALO",
                  "usefHorseId": "5814560",
                  "link": "https://www.usef.org/search/horses/display/Y7hFHkVwDaI?year=2024"
                },
                "entries": "5",
                "placing": "3",
                "natlPoints": "0.00",
                "zonePoints": "10.00",
                "backNumber": "2956",
                "dressagePercentage": null
              },
              {
                "classCode": "505",
                "classTitle": "505 - Equitation 12-14 2'9'/15-17 3'3 Flat",
                "classUrl": "https://www.usef.org/search/competitions/class/U7Sz-m7XfPk",
                "horse": {
                  "name": "MAHALO",
                  "usefHorseId": "5814560",
                  "link": "https://www.usef.org/search/horses/display/Y7hFHkVwDaI?year=2024"
                },
                "entries": "5",
                "placing": "1",
                "natlPoints": "0.00",
                "zonePoints": "20.00",
                "backNumber": "2956",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "3372",
        "competitionName": "WEF 10 (3372)",
        "id": "3372",
        "name": "WEF 10 (3372)",
        "startDate": "3/11/2025",
        "endDate": "3/16/2025",
        "start": "2025-03-11T04:00:00.000Z",
        "end": "2025-03-16T04:00:00.000Z",
        "year": 2025,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/l_nMUTKBjPc",
        "sections": [
          {
            "sectionId": "3338",
            "sectionName": "1.00/1.05M AND BELOW JUNIOR JUMPER",
            "classes": [
              {
                "classCode": "1738A",
                "classTitle": "1738A - 1.00m Junior Jumper II2d (Cali Split)",
                "classUrl": "https://www.usef.org/search/competitions/class/UjIsKegOp7Y",
                "horse": {
                  "name": "DODICCI",
                  "usefHorseId": "5800091",
                  "link": "https://www.usef.org/search/horses/display/h70h29S45Ns?year=2025"
                },
                "entries": "33",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1033",
                "dressagePercentage": null
              },
              {
                "classCode": "1739A",
                "classTitle": "1739A - $1540 1.05m Junior Jumper Classic II2b (Cali Split)",
                "classUrl": "https://www.usef.org/search/competitions/class/1AY60Cbo_40",
                "horse": {
                  "name": "DODICCI",
                  "usefHorseId": "5800091",
                  "link": "https://www.usef.org/search/horses/display/h70h29S45Ns?year=2025"
                },
                "entries": "32",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1033",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "139",
        "competitionName": "WEF 9 (139)",
        "id": "139",
        "name": "WEF 9 (139)",
        "startDate": "3/4/2025",
        "endDate": "3/9/2025",
        "start": "2025-03-04T05:00:00.000Z",
        "end": "2025-03-09T05:00:00.000Z",
        "year": 2025,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/k5YLeptBF90",
        "sections": [
          {
            "sectionId": "3338",
            "sectionName": "1.00/1.05M AND BELOW JUNIOR JUMPER",
            "classes": [
              {
                "classCode": "1737B",
                "classTitle": "1737B - 1.00m Junior Jumper II2b (Cali Split)",
                "classUrl": "https://www.usef.org/search/competitions/class/8wK95j7V2OE",
                "horse": {
                  "name": "DODICCI",
                  "usefHorseId": "5800091",
                  "link": "https://www.usef.org/search/horses/display/h70h29S45Ns?year=2025"
                },
                "entries": "25",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1033",
                "dressagePercentage": null
              },
              {
                "classCode": "1739A",
                "classTitle": "1739A - $1540 1.05m Junior Jumper Classic II2b (Cali Split)",
                "classUrl": "https://www.usef.org/search/competitions/class/XTcrDDJirQM",
                "horse": {
                  "name": "DODICCI",
                  "usefHorseId": "5800091",
                  "link": "https://www.usef.org/search/horses/display/h70h29S45Ns?year=2025"
                },
                "entries": "31",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1033",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3800",
            "sectionName": "MISC JUMPER",
            "classes": [
              {
                "classCode": "1109",
                "classTitle": "1109 - .90m Training Jumper (Table II)",
                "classUrl": "https://www.usef.org/search/competitions/class/wyhOqYMROw8",
                "horse": {
                  "name": "DODICCI",
                  "usefHorseId": "5800091",
                  "link": "https://www.usef.org/search/horses/display/h70h29S45Ns?year=2025"
                },
                "entries": "42",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1033",
                "dressagePercentage": null
              },
              {
                "classCode": "1112",
                "classTitle": "1112 - Low Child/Adult 39 & Under Training Jumper .90m II2b",
                "classUrl": "https://www.usef.org/search/competitions/class/nqE5--j5pDA",
                "horse": {
                  "name": "DODICCI",
                  "usefHorseId": "5800091",
                  "link": "https://www.usef.org/search/horses/display/h70h29S45Ns?year=2025"
                },
                "entries": "43",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1033",
                "dressagePercentage": null
              },
              {
                "classCode": "1117",
                "classTitle": "1117 - Low Child/Adult Training Jumper .80m II2d",
                "classUrl": "https://www.usef.org/search/competitions/class/c6YbKAZmC-k",
                "horse": {
                  "name": "DODICCI",
                  "usefHorseId": "5800091",
                  "link": "https://www.usef.org/search/horses/display/h70h29S45Ns?year=2025"
                },
                "entries": "29",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1033",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "3122",
        "competitionName": "WEF 8  (3122)",
        "id": "3122",
        "name": "WEF 8  (3122)",
        "startDate": "2/25/2025",
        "endDate": "3/2/2025",
        "start": "2025-02-25T05:00:00.000Z",
        "end": "2025-03-02T05:00:00.000Z",
        "year": 2025,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/XB6NaeE4IRM",
        "sections": [
          {
            "sectionId": "3117",
            "sectionName": "HUNTER EQUITATION 12-14",
            "classes": [
              {
                "classCode": "3012",
                "classTitle": "3012 - 12-14 Equitation Flat",
                "classUrl": "https://www.usef.org/search/competitions/class/TiRQtbJOTnI",
                "horse": {
                  "name": "A LA MINUTE Z",
                  "usefHorseId": "5968963",
                  "link": "https://www.usef.org/search/horses/display/chuJXup9_d0?year=2025"
                },
                "entries": "8",
                "placing": "7",
                "natlPoints": "3.00",
                "zonePoints": "3.00",
                "backNumber": "1061",
                "dressagePercentage": null
              },
              {
                "classCode": "3013",
                "classTitle": "3013 - 12-14 Equitation (2'9 )",
                "classUrl": "https://www.usef.org/search/competitions/class/fBxGRyd5SAY",
                "horse": {
                  "name": "A LA MINUTE Z",
                  "usefHorseId": "5968963",
                  "link": "https://www.usef.org/search/horses/display/chuJXup9_d0?year=2025"
                },
                "entries": "19",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1061",
                "dressagePercentage": null
              },
              {
                "classCode": "3014",
                "classTitle": "3014 - 12-14 Equitation (2'9 )",
                "classUrl": "https://www.usef.org/search/competitions/class/9vUOv8Szzu4",
                "horse": {
                  "name": "A LA MINUTE Z",
                  "usefHorseId": "5968963",
                  "link": "https://www.usef.org/search/horses/display/chuJXup9_d0?year=2025"
                },
                "entries": "19",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1061",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3199",
            "sectionName": "Misc Equitation",
            "classes": [
              {
                "classCode": "3075",
                "classTitle": "3075 - SFHJA Junior Hunt Seat Medal 14 & Under (Flat Phase)",
                "classUrl": "https://www.usef.org/search/competitions/class/UXPRcCcK3Tw",
                "horse": {
                  "name": "BALOUNA",
                  "usefHorseId": "6009188",
                  "link": "https://www.usef.org/search/horses/display/lnjxdWdygGA?year=2025"
                },
                "entries": "21",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1052",
                "dressagePercentage": null
              },
              {
                "classCode": "3080",
                "classTitle": "3080 - THIS Children's Medal 14 & Under",
                "classUrl": "https://www.usef.org/search/competitions/class/cd2i_bKBw2w",
                "horse": {
                  "name": "BALOUNA",
                  "usefHorseId": "6009188",
                  "link": "https://www.usef.org/search/horses/display/lnjxdWdygGA?year=2025"
                },
                "entries": "33",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1052",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3800",
            "sectionName": "MISC JUMPER",
            "classes": [
              {
                "classCode": "1111",
                "classTitle": "1111 - Low Child/Adult 39 & Under Training Jumper .90m II2d",
                "classUrl": "https://www.usef.org/search/competitions/class/t6vcbot2ujk",
                "horse": {
                  "name": "BALOUNA",
                  "usefHorseId": "6009188",
                  "link": "https://www.usef.org/search/horses/display/lnjxdWdygGA?year=2025"
                },
                "entries": "26",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1052",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "962",
        "competitionName": "WEF 3 (962)",
        "id": "962",
        "name": "WEF 3 (962)",
        "startDate": "1/21/2025",
        "endDate": "1/26/2025",
        "start": "2025-01-21T05:00:00.000Z",
        "end": "2025-01-26T05:00:00.000Z",
        "year": 2025,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/S2cIqckUIBc",
        "sections": [
          {
            "sectionId": "2420",
            "sectionName": "JUNIOR HUNTER 3'3\\"",
            "classes": [
              {
                "classCode": "2806",
                "classTitle": "2806 - $100 Junior Hunter 3'3 15 & Under U/S",
                "classUrl": "https://www.usef.org/search/competitions/class/DWEVYdDvuoU",
                "horse": {
                  "name": "A LA MINUTE Z",
                  "usefHorseId": "5968963",
                  "link": "https://www.usef.org/search/horses/display/chuJXup9_d0?year=2025"
                },
                "entries": "27",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1061",
                "dressagePercentage": null
              },
              {
                "classCode": "2807",
                "classTitle": "2807 - $500 Junior Hunter 3'3 15 & Under",
                "classUrl": "https://www.usef.org/search/competitions/class/9aDgp5wNldU",
                "horse": {
                  "name": "A LA MINUTE Z",
                  "usefHorseId": "5968963",
                  "link": "https://www.usef.org/search/horses/display/chuJXup9_d0?year=2025"
                },
                "entries": "27",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1061",
                "dressagePercentage": null
              },
              {
                "classCode": "2808",
                "classTitle": "2808 - $735 Junior Hunter 3'3 15 & Under Handy",
                "classUrl": "https://www.usef.org/search/competitions/class/XW2bbttMR8k",
                "horse": {
                  "name": "A LA MINUTE Z",
                  "usefHorseId": "5968963",
                  "link": "https://www.usef.org/search/horses/display/chuJXup9_d0?year=2025"
                },
                "entries": "27",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1061",
                "dressagePercentage": null
              },
              {
                "classCode": "2809",
                "classTitle": "2809 - $500 Junior Hunter 3'3 15 & Under",
                "classUrl": "https://www.usef.org/search/competitions/class/ucW7MB_LOlE",
                "horse": {
                  "name": "A LA MINUTE Z",
                  "usefHorseId": "5968963",
                  "link": "https://www.usef.org/search/horses/display/chuJXup9_d0?year=2025"
                },
                "entries": "27",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1061",
                "dressagePercentage": null
              },
              {
                "classCode": "2810",
                "classTitle": "2810 - $800 Junior Hunter 3'3 15 & Under Stake",
                "classUrl": "https://www.usef.org/search/competitions/class/-rFrvEzxVzQ",
                "horse": {
                  "name": "A LA MINUTE Z",
                  "usefHorseId": "5968963",
                  "link": "https://www.usef.org/search/horses/display/chuJXup9_d0?year=2025"
                },
                "entries": "27",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1061",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3199",
            "sectionName": "Misc Equitation",
            "classes": [
              {
                "classCode": "3075",
                "classTitle": "3075 - SFHJA Junior Hunt Seat Medal 14 & Under (Flat Phase)",
                "classUrl": "https://www.usef.org/search/competitions/class/sKB9zs8Tr1E",
                "horse": {
                  "name": "A LA MINUTE Z",
                  "usefHorseId": "5968963",
                  "link": "https://www.usef.org/search/horses/display/chuJXup9_d0?year=2025"
                },
                "entries": "15",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1061",
                "dressagePercentage": null
              },
              {
                "classCode": "3080",
                "classTitle": "3080 - THIS Children's Medal 14 & Under",
                "classUrl": "https://www.usef.org/search/competitions/class/5OP3jcCsMK8",
                "horse": {
                  "name": "A LA MINUTE Z",
                  "usefHorseId": "5968963",
                  "link": "https://www.usef.org/search/horses/display/chuJXup9_d0?year=2025"
                },
                "entries": "30",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1061",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "5027",
        "competitionName": "WEF 2 (5027)",
        "id": "5027",
        "name": "WEF 2 (5027)",
        "startDate": "1/14/2025",
        "endDate": "1/19/2025",
        "start": "2025-01-14T05:00:00.000Z",
        "end": "2025-01-19T05:00:00.000Z",
        "year": 2025,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/K1N6pKKnzRg",
        "sections": [
          {
            "sectionId": "2703",
            "sectionName": "CHILDRENS HUNTER-HORSE 14 & UNDER",
            "classes": [
              {
                "classCode": "2851A",
                "classTitle": "2851A - Children's Hunter 14 & Under U/S (Cali Split)",
                "classUrl": "https://www.usef.org/search/competitions/class/CgTiFFFGCa4",
                "horse": {
                  "name": "A LA MINUTE Z",
                  "usefHorseId": "5968963",
                  "link": "https://www.usef.org/search/horses/display/chuJXup9_d0?year=2025"
                },
                "entries": "11",
                "placing": "4",
                "natlPoints": "11.00",
                "zonePoints": "11.00",
                "backNumber": "1061",
                "dressagePercentage": null
              },
              {
                "classCode": "2852A",
                "classTitle": "2852A - Children's Hunter 14 & Under (Cali Split) - FP",
                "classUrl": "https://www.usef.org/search/competitions/class/J3GD1TbGxXY",
                "horse": {
                  "name": "A LA MINUTE Z",
                  "usefHorseId": "5968963",
                  "link": "https://www.usef.org/search/horses/display/chuJXup9_d0?year=2025"
                },
                "entries": "15",
                "placing": "2",
                "natlPoints": "18.00",
                "zonePoints": "18.00",
                "backNumber": "1061",
                "dressagePercentage": null
              },
              {
                "classCode": "2853B",
                "classTitle": "2853B - Children's Hunter 14 & Under (Cali Split)",
                "classUrl": "https://www.usef.org/search/competitions/class/ZCWn3CyErq8",
                "horse": {
                  "name": "A LA MINUTE Z",
                  "usefHorseId": "5968963",
                  "link": "https://www.usef.org/search/horses/display/chuJXup9_d0?year=2025"
                },
                "entries": "15",
                "placing": "3",
                "natlPoints": "15.00",
                "zonePoints": "15.00",
                "backNumber": "1061",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "2716",
            "sectionName": "LOW CHILDREN'S HUNTER",
            "classes": [
              {
                "classCode": "4077B",
                "classTitle": "4077B - Low Children's Hunter (Cali Split) - FP",
                "classUrl": "https://www.usef.org/search/competitions/class/KKCkvQ8J2ms",
                "horse": {
                  "name": "CHARMING BOY O",
                  "usefHorseId": "5615354",
                  "link": "https://www.usef.org/search/horses/display/_LpmjJWklsg?year=2025"
                },
                "entries": "16",
                "placing": "5",
                "natlPoints": "13.00",
                "zonePoints": "13.00",
                "backNumber": "1063",
                "dressagePercentage": null
              },
              {
                "classCode": "4078B",
                "classTitle": "4078B - Low Children's Hunter (Cali Split)",
                "classUrl": "https://www.usef.org/search/competitions/class/DRgx7YsGX9o",
                "horse": {
                  "name": "CHARMING BOY O",
                  "usefHorseId": "5615354",
                  "link": "https://www.usef.org/search/horses/display/_LpmjJWklsg?year=2025"
                },
                "entries": "16",
                "placing": "8",
                "natlPoints": "10.00",
                "zonePoints": "10.00",
                "backNumber": "1063",
                "dressagePercentage": null
              },
              {
                "classCode": "4079A",
                "classTitle": "4079A - Low Children's Hunter (Cali Split)",
                "classUrl": "https://www.usef.org/search/competitions/class/GnL8t6GPsCE",
                "horse": {
                  "name": "CHARMING BOY O",
                  "usefHorseId": "5615354",
                  "link": "https://www.usef.org/search/horses/display/_LpmjJWklsg?year=2025"
                },
                "entries": "15",
                "placing": "5",
                "natlPoints": "13.00",
                "zonePoints": "13.00",
                "backNumber": "1063",
                "dressagePercentage": null
              },
              {
                "classCode": "4080B",
                "classTitle": "4080B - Low Children's Hunter (Cali Split)",
                "classUrl": "https://www.usef.org/search/competitions/class/jHFlceXprIc",
                "horse": {
                  "name": "CHARMING BOY O",
                  "usefHorseId": "5615354",
                  "link": "https://www.usef.org/search/horses/display/_LpmjJWklsg?year=2025"
                },
                "entries": "15",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1063",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3199",
            "sectionName": "Misc Equitation",
            "classes": [
              {
                "classCode": "3075",
                "classTitle": "3075 - SFHJA Junior Hunt Seat Medal 14 & Under (Flat Phase)",
                "classUrl": "https://www.usef.org/search/competitions/class/Jt5rd3RYkiM",
                "horse": {
                  "name": "A LA MINUTE Z",
                  "usefHorseId": "5968963",
                  "link": "https://www.usef.org/search/horses/display/chuJXup9_d0?year=2025"
                },
                "entries": "13",
                "placing": "3",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1061",
                "dressagePercentage": null
              },
              {
                "classCode": "3080",
                "classTitle": "3080 - THIS Children's Medal 14 & Under",
                "classUrl": "https://www.usef.org/search/competitions/class/_ipXGRzp8ag",
                "horse": {
                  "name": "A LA MINUTE Z",
                  "usefHorseId": "5968963",
                  "link": "https://www.usef.org/search/horses/display/chuJXup9_d0?year=2025"
                },
                "entries": "25",
                "placing": "6",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1061",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "233832",
        "competitionName": "WEF PREMIER (233832)",
        "id": "233832",
        "name": "WEF PREMIER (233832)",
        "startDate": "1/1/2025",
        "endDate": "1/5/2025",
        "start": "2025-01-01T05:00:00.000Z",
        "end": "2025-01-05T05:00:00.000Z",
        "year": 2025,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/Qi3xDi-h8GM",
        "sections": [
          {
            "sectionId": "3199",
            "sectionName": "Misc Equitation",
            "classes": [
              {
                "classCode": "3075",
                "classTitle": "3075 - SFHJA Junior Hunt Seat Medal 14 & Under (Flat Phase)",
                "classUrl": "https://www.usef.org/search/competitions/class/x3Pn0vSx6cE",
                "horse": {
                  "name": "BALOUNA",
                  "usefHorseId": "6009188",
                  "link": "https://www.usef.org/search/horses/display/lnjxdWdygGA?year=2025"
                },
                "entries": "13",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1052",
                "dressagePercentage": null
              },
              {
                "classCode": "3080",
                "classTitle": "3080 - THIS Children's Medal 14 & Under",
                "classUrl": "https://www.usef.org/search/competitions/class/Q2fkwA8xcV0",
                "horse": {
                  "name": "BALOUNA",
                  "usefHorseId": "6009188",
                  "link": "https://www.usef.org/search/horses/display/lnjxdWdygGA?year=2025"
                },
                "entries": "30",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1052",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3800",
            "sectionName": "MISC JUMPER",
            "classes": [
              {
                "classCode": "1108",
                "classTitle": "1108 - .90m Training Jumper (Table II)",
                "classUrl": "https://www.usef.org/search/competitions/class/djGmHAh_A24",
                "horse": {
                  "name": "BALOUNA",
                  "usefHorseId": "6009188",
                  "link": "https://www.usef.org/search/horses/display/lnjxdWdygGA?year=2025"
                },
                "entries": "19",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1052",
                "dressagePercentage": null
              },
              {
                "classCode": "1111",
                "classTitle": "1111 - Low Child/Adult 39 & Under Training Jumper .90m II2d",
                "classUrl": "https://www.usef.org/search/competitions/class/li0FRGj-cVk",
                "horse": {
                  "name": "BALOUNA",
                  "usefHorseId": "6009188",
                  "link": "https://www.usef.org/search/horses/display/lnjxdWdygGA?year=2025"
                },
                "entries": "23",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1052",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "316542",
        "competitionName": "HOLIDAY FESTIVAL II (316542)",
        "id": "316542",
        "name": "HOLIDAY FESTIVAL II (316542)",
        "startDate": "12/12/2024",
        "endDate": "12/15/2024",
        "start": "2024-12-12T05:00:00.000Z",
        "end": "2024-12-15T05:00:00.000Z",
        "year": 2024,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/d72ZkVTMjcY",
        "sections": [
          {
            "sectionId": "3117",
            "sectionName": "HUNTER EQUITATION 12-14",
            "classes": [
              {
                "classCode": "512",
                "classTitle": "512 - 12-14 Equitation Flat",
                "classUrl": "https://www.usef.org/search/competitions/class/MApeBoO3daQ",
                "horse": {
                  "name": "BALOUNA",
                  "usefHorseId": "6009188",
                  "link": "https://www.usef.org/search/horses/display/lnjxdWdygGA?year=2025"
                },
                "entries": "8",
                "placing": "1",
                "natlPoints": "20.00",
                "zonePoints": "20.00",
                "backNumber": "2420",
                "dressagePercentage": null
              },
              {
                "classCode": "513",
                "classTitle": "513 - 12-14 Equitation (2'9 )",
                "classUrl": "https://www.usef.org/search/competitions/class/r7A7k3r3EtI",
                "horse": {
                  "name": "BALOUNA",
                  "usefHorseId": "6009188",
                  "link": "https://www.usef.org/search/horses/display/lnjxdWdygGA?year=2025"
                },
                "entries": "8",
                "placing": "5",
                "natlPoints": "5.00",
                "zonePoints": "5.00",
                "backNumber": "2420",
                "dressagePercentage": null
              },
              {
                "classCode": "514",
                "classTitle": "514 - 12-14 Equitation (2'9 )",
                "classUrl": "https://www.usef.org/search/competitions/class/sKKPp1JwaRg",
                "horse": {
                  "name": "BALOUNA",
                  "usefHorseId": "6009188",
                  "link": "https://www.usef.org/search/horses/display/lnjxdWdygGA?year=2025"
                },
                "entries": "8",
                "placing": "5",
                "natlPoints": "5.00",
                "zonePoints": "5.00",
                "backNumber": "2420",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3199",
            "sectionName": "Misc Equitation",
            "classes": [
              {
                "classCode": "525",
                "classTitle": "525 - SFHJA Junior Hunter Seat Medal (Flat Phase)",
                "classUrl": "https://www.usef.org/search/competitions/class/Df4N0bUgfDQ",
                "horse": {
                  "name": "BALOUNA",
                  "usefHorseId": "6009188",
                  "link": "https://www.usef.org/search/horses/display/lnjxdWdygGA?year=2025"
                },
                "entries": "7",
                "placing": "5",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "2420",
                "dressagePercentage": null
              },
              {
                "classCode": "555",
                "classTitle": "555 - THIS Children's Medal",
                "classUrl": "https://www.usef.org/search/competitions/class/Npm-Hri-pyk",
                "horse": {
                  "name": "BALOUNA",
                  "usefHorseId": "6009188",
                  "link": "https://www.usef.org/search/horses/display/lnjxdWdygGA?year=2025"
                },
                "entries": "12",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "2420",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "247834",
        "competitionName": "HOLIDAY FESTIVAL I (247834)",
        "id": "247834",
        "name": "HOLIDAY FESTIVAL I (247834)",
        "startDate": "12/11/2024",
        "endDate": "12/11/2024",
        "start": "2024-12-11T05:00:00.000Z",
        "end": "2024-12-11T05:00:00.000Z",
        "year": 2024,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/Yq4uUTCiTcY",
        "sections": [
          {
            "sectionId": "3199",
            "sectionName": "Misc Equitation",
            "classes": [
              {
                "classCode": "530",
                "classTitle": "530 - Hamel Foundation/NHS 3'3  Medal",
                "classUrl": "https://www.usef.org/search/competitions/class/wPVMy06ymxQ",
                "horse": {
                  "name": "BALOUNA",
                  "usefHorseId": "6009188",
                  "link": "https://www.usef.org/search/horses/display/lnjxdWdygGA?year=2025"
                },
                "entries": "6",
                "placing": "RF",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "2420",
                "dressagePercentage": null
              },
              {
                "classCode": "555",
                "classTitle": "555 - THIS Children's Medal",
                "classUrl": "https://www.usef.org/search/competitions/class/V_PAfv9FuOY",
                "horse": {
                  "name": "BALOUNA",
                  "usefHorseId": "6009188",
                  "link": "https://www.usef.org/search/horses/display/lnjxdWdygGA?year=2025"
                },
                "entries": "3",
                "placing": "3",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "2420",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "900",
        "competitionName": "SFHJA 74TH ANNUAL CHARITY (900)",
        "id": "900",
        "name": "SFHJA 74TH ANNUAL CHARITY (900)",
        "startDate": "11/20/2024",
        "endDate": "11/24/2024",
        "start": "2024-11-20T05:00:00.000Z",
        "end": "2024-11-24T05:00:00.000Z",
        "year": 2024,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/-7Dred7--OE",
        "sections": [
          {
            "sectionId": "3102",
            "sectionName": "HUNTER EQUITATION 14&U",
            "classes": [
              {
                "classCode": "512",
                "classTitle": "512 - 14 & Under Equitation Flat",
                "classUrl": "https://www.usef.org/search/competitions/class/M1xwrWAYywc",
                "horse": {
                  "name": "BALOUNA",
                  "usefHorseId": "6009188",
                  "link": "https://www.usef.org/search/horses/display/lnjxdWdygGA?year=2024"
                },
                "entries": "12",
                "placing": "4",
                "natlPoints": "0.00",
                "zonePoints": "6.00",
                "backNumber": "878",
                "dressagePercentage": null
              },
              {
                "classCode": "513",
                "classTitle": "513 - 14 & Under Equitation",
                "classUrl": "https://www.usef.org/search/competitions/class/-A48ekPK-Vg",
                "horse": {
                  "name": "BALOUNA",
                  "usefHorseId": "6009188",
                  "link": "https://www.usef.org/search/horses/display/lnjxdWdygGA?year=2024"
                },
                "entries": "11",
                "placing": "3",
                "natlPoints": "0.00",
                "zonePoints": "10.00",
                "backNumber": "878",
                "dressagePercentage": null
              },
              {
                "classCode": "514",
                "classTitle": "514 - 14 & Under Equitation",
                "classUrl": "https://www.usef.org/search/competitions/class/_7gDbm-ffxM",
                "horse": {
                  "name": "BALOUNA",
                  "usefHorseId": "6009188",
                  "link": "https://www.usef.org/search/horses/display/lnjxdWdygGA?year=2024"
                },
                "entries": "11",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "878",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3199",
            "sectionName": "Misc Equitation",
            "classes": [
              {
                "classCode": "555",
                "classTitle": "555 - THIS Children's Medal",
                "classUrl": "https://www.usef.org/search/competitions/class/vqTtf7XOxMY",
                "horse": {
                  "name": "BALOUNA",
                  "usefHorseId": "6009188",
                  "link": "https://www.usef.org/search/horses/display/lnjxdWdygGA?year=2024"
                },
                "entries": "15",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "878",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "343747",
        "competitionName": "ESP PRE CHARITY HUNTER & EQUITATION (343747)",
        "id": "343747",
        "name": "ESP PRE CHARITY HUNTER & EQUITATION (343747)",
        "startDate": "11/15/2024",
        "endDate": "11/17/2024",
        "start": "2024-11-15T05:00:00.000Z",
        "end": "2024-11-17T05:00:00.000Z",
        "year": 2024,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/Jn7NB3f1Dd0",
        "sections": [
          {
            "sectionId": "6350",
            "sectionName": "USHJA 3'3\\" JUNIOR JUMPING SEAT MEDAL",
            "classes": [
              {
                "classCode": "545",
                "classTitle": "545 - USHJA 3'3  Jumper Seat Junior Medal",
                "classUrl": "https://www.usef.org/search/competitions/class/dJ763JD3C4Y",
                "horse": {
                  "name": "KOBERLIN FH",
                  "usefHorseId": "5802679",
                  "link": "https://www.usef.org/search/horses/display/yGH-B_EsY6E?year=2024"
                },
                "entries": "9",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "174",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "7129",
        "competitionName": "EQUESTRIAN SPORT PRODUCTIONS, LLC. NOVEMBER I (7129)",
        "id": "7129",
        "name": "EQUESTRIAN SPORT PRODUCTIONS, LLC. NOVEMBER I (7129)",
        "startDate": "11/8/2024",
        "endDate": "11/10/2024",
        "start": "2024-11-08T05:00:00.000Z",
        "end": "2024-11-10T05:00:00.000Z",
        "year": 2024,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/SW9CTX0YE4I",
        "sections": [
          {
            "sectionId": "3100",
            "sectionName": "MISC. HUNTER (No points earned)",
            "classes": [
              {
                "classCode": "208",
                "classTitle": "208 - Add Back Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/P0Bt1qZ8ehY",
                "horse": {
                  "name": "KOBERLIN FH",
                  "usefHorseId": "5802679",
                  "link": "https://www.usef.org/search/horses/display/yGH-B_EsY6E?year=2024"
                },
                "entries": "7",
                "placing": "5",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "174",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3199",
            "sectionName": "Misc Equitation",
            "classes": [
              {
                "classCode": "525",
                "classTitle": "525 - SFHJA Junior/Adult Amateur Medal (Flat Phase)",
                "classUrl": "https://www.usef.org/search/competitions/class/hp9JRKpirU4",
                "horse": {
                  "name": "KOBERLIN FH",
                  "usefHorseId": "5802679",
                  "link": "https://www.usef.org/search/horses/display/yGH-B_EsY6E?year=2024"
                },
                "entries": "14",
                "placing": "4",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "174",
                "dressagePercentage": null
              },
              {
                "classCode": "555",
                "classTitle": "555 - THIS Children's Medal",
                "classUrl": "https://www.usef.org/search/competitions/class/D-iBsVHijLw",
                "horse": {
                  "name": "KOBERLIN FH",
                  "usefHorseId": "5802679",
                  "link": "https://www.usef.org/search/horses/display/yGH-B_EsY6E?year=2024"
                },
                "entries": "11",
                "placing": "3",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "174",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "9303",
            "sectionName": "JUNIOR/AMATEUR OWNER HUNTER 3'3\\"",
            "classes": [
              {
                "classCode": "336",
                "classTitle": "336 - Junior/Amateur Owner Hunter 3'3  U/S",
                "classUrl": "https://www.usef.org/search/competitions/class/8n8i0iN0oYQ",
                "horse": {
                  "name": "KOBERLIN FH",
                  "usefHorseId": "5802679",
                  "link": "https://www.usef.org/search/horses/display/yGH-B_EsY6E?year=2024"
                },
                "entries": "8",
                "placing": "6",
                "natlPoints": "4.00",
                "zonePoints": "4.00",
                "backNumber": "174",
                "dressagePercentage": null
              },
              {
                "classCode": "337",
                "classTitle": "337 - Junior/Amateur Owner Hunter 3'3 - FP",
                "classUrl": "https://www.usef.org/search/competitions/class/xdLA-vm1X20",
                "horse": {
                  "name": "KOBERLIN FH",
                  "usefHorseId": "5802679",
                  "link": "https://www.usef.org/search/horses/display/yGH-B_EsY6E?year=2024"
                },
                "entries": "8",
                "placing": "4",
                "natlPoints": "6.00",
                "zonePoints": "6.00",
                "backNumber": "174",
                "dressagePercentage": null
              },
              {
                "classCode": "338",
                "classTitle": "338 - Junior/Amateur Owner Hunter 3'3",
                "classUrl": "https://www.usef.org/search/competitions/class/edZ-oP2HWEQ",
                "horse": {
                  "name": "KOBERLIN FH",
                  "usefHorseId": "5802679",
                  "link": "https://www.usef.org/search/horses/display/yGH-B_EsY6E?year=2024"
                },
                "entries": "8",
                "placing": "6",
                "natlPoints": "4.00",
                "zonePoints": "4.00",
                "backNumber": "174",
                "dressagePercentage": null
              },
              {
                "classCode": "339",
                "classTitle": "339 - Junior/Amateur Owner Hunter 3'3",
                "classUrl": "https://www.usef.org/search/competitions/class/9c6vz3Z8hVg",
                "horse": {
                  "name": "KOBERLIN FH",
                  "usefHorseId": "5802679",
                  "link": "https://www.usef.org/search/horses/display/yGH-B_EsY6E?year=2024"
                },
                "entries": "9",
                "placing": "7",
                "natlPoints": "3.00",
                "zonePoints": "3.00",
                "backNumber": "174",
                "dressagePercentage": null
              },
              {
                "classCode": "340",
                "classTitle": "340 - Junior/Amateur Owner Hunter 3'3",
                "classUrl": "https://www.usef.org/search/competitions/class/D4MsQLwMnq4",
                "horse": {
                  "name": "KOBERLIN FH",
                  "usefHorseId": "5802679",
                  "link": "https://www.usef.org/search/horses/display/yGH-B_EsY6E?year=2024"
                },
                "entries": "8",
                "placing": "2",
                "natlPoints": "10.00",
                "zonePoints": "10.00",
                "backNumber": "174",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "4049",
        "competitionName": "EQUESTRIAN SPORT PRODUCTIONS, LLC. SEPTEMBER (4049)",
        "id": "4049",
        "name": "EQUESTRIAN SPORT PRODUCTIONS, LLC. SEPTEMBER (4049)",
        "startDate": "9/11/2025",
        "endDate": "9/14/2025",
        "start": "2025-09-11T04:00:00.000Z",
        "end": "2025-09-14T04:00:00.000Z",
        "year": 2025,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/0OLw7sE5-0Y",
        "sections": [
          {
            "sectionId": "3199",
            "sectionName": "Misc Equitation",
            "classes": [
              {
                "classCode": "580",
                "classTitle": "580 - WIHS Hunter Phase",
                "classUrl": "https://www.usef.org/search/competitions/class/FuHpCQ1qPF4",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "5",
                "placing": "5",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "133",
                "dressagePercentage": null
              },
              {
                "classCode": "581",
                "classTitle": "581 - WIHS Jumper Phase",
                "classUrl": "https://www.usef.org/search/competitions/class/bLTWrsHhzqo",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "6",
                "placing": "4",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "133",
                "dressagePercentage": null
              },
              {
                "classCode": "582",
                "classTitle": "582 - WIHS Overall",
                "classUrl": "https://www.usef.org/search/competitions/class/EuN7tbCOzZw",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "5",
                "placing": "3",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "133",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "6110",
            "sectionName": "PLATINUM PERFORMANCE/USEF SHOW JUMPING TALENT SEARCH",
            "classes": [
              {
                "classCode": "590",
                "classTitle": "590 - Platinum Performance/USEF Show Jumping Talent Search 1*",
                "classUrl": "https://www.usef.org/search/competitions/class/_z4YIzNLrMU",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "5",
                "placing": "3",
                "natlPoints": "5.00",
                "zonePoints": "0.00",
                "backNumber": "133",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "6371",
        "competitionName": "EQUESTRIAN SPORT PRODUCTIONS, LLC. LABOR DAY A (6371)",
        "id": "6371",
        "name": "EQUESTRIAN SPORT PRODUCTIONS, LLC. LABOR DAY A (6371)",
        "startDate": "8/28/2025",
        "endDate": "8/31/2025",
        "start": "2025-08-28T04:00:00.000Z",
        "end": "2025-08-31T04:00:00.000Z",
        "year": 2025,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/Fr_giG9vIvQ",
        "sections": [
          {
            "sectionId": "3199",
            "sectionName": "Misc Equitation",
            "classes": [
              {
                "classCode": "525",
                "classTitle": "525 - SFHJA Junior Medal (Flat Phase)",
                "classUrl": "https://www.usef.org/search/competitions/class/Siuk5IvMkUY",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "8",
                "placing": "1",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "133",
                "dressagePercentage": null
              },
              {
                "classCode": "570",
                "classTitle": "570 - ASPCA Maclay",
                "classUrl": "https://www.usef.org/search/competitions/class/QYhGy-k1T4g",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "6",
                "placing": "1",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "133",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3800",
            "sectionName": "MISC JUMPER",
            "classes": [
              {
                "classCode": "715",
                "classTitle": "715 - 1.10m Open Jumper II2d",
                "classUrl": "https://www.usef.org/search/competitions/class/DELJhsYfdxQ",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "14",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "133",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "6111",
            "sectionName": "1* USEF SHOW JUMPING TALENT SEARCH",
            "classes": [
              {
                "classCode": "590",
                "classTitle": "590 - Platinum Performance/USEF Show Jumping Talent Search 1*",
                "classUrl": "https://www.usef.org/search/competitions/class/HwQS-n-wzYs",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "3",
                "placing": "2",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "133",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "307815",
        "competitionName": "EQUESTRIAN SPORT PRODUCTIONS, LLC. SUMMER II (307815)",
        "id": "307815",
        "name": "EQUESTRIAN SPORT PRODUCTIONS, LLC. SUMMER II (307815)",
        "startDate": "8/14/2025",
        "endDate": "8/17/2025",
        "start": "2025-08-14T04:00:00.000Z",
        "end": "2025-08-17T04:00:00.000Z",
        "year": 2025,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/CQVrTlJOvAk",
        "sections": [
          {
            "sectionId": "2500",
            "sectionName": "PONY HUNTER",
            "classes": [
              {
                "classCode": "411",
                "classTitle": "411 - Pony Hunter U/S",
                "classUrl": "https://www.usef.org/search/competitions/class/TzCWYg9A-mE",
                "horse": {
                  "name": "BRIGHTON",
                  "usefHorseId": "5356986",
                  "link": "https://www.usef.org/search/horses/display/7BY-ibGLTQE?year=2025"
                },
                "entries": "3",
                "placing": "3",
                "natlPoints": "8.00",
                "zonePoints": "8.00",
                "backNumber": "852",
                "dressagePercentage": null
              },
              {
                "classCode": "412",
                "classTitle": "412 - Pony Hunter Large/Medium/Small",
                "classUrl": "https://www.usef.org/search/competitions/class/KuAWvQRnfes",
                "horse": {
                  "name": "BRIGHTON",
                  "usefHorseId": "5356986",
                  "link": "https://www.usef.org/search/horses/display/7BY-ibGLTQE?year=2025"
                },
                "entries": "3",
                "placing": "2",
                "natlPoints": "10.00",
                "zonePoints": "10.00",
                "backNumber": "852",
                "dressagePercentage": null
              },
              {
                "classCode": "413",
                "classTitle": "413 - Pony Hunter Large/Medium/Small",
                "classUrl": "https://www.usef.org/search/competitions/class/u9c1giRMb9Q",
                "horse": {
                  "name": "BRIGHTON",
                  "usefHorseId": "5356986",
                  "link": "https://www.usef.org/search/horses/display/7BY-ibGLTQE?year=2025"
                },
                "entries": "3",
                "placing": "2",
                "natlPoints": "10.00",
                "zonePoints": "10.00",
                "backNumber": "852",
                "dressagePercentage": null
              },
              {
                "classCode": "414",
                "classTitle": "414 - Pony Conformation Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/DMs4pf731rY",
                "horse": {
                  "name": "BRIGHTON",
                  "usefHorseId": "5356986",
                  "link": "https://www.usef.org/search/horses/display/7BY-ibGLTQE?year=2025"
                },
                "entries": "2",
                "placing": "2",
                "natlPoints": "10.00",
                "zonePoints": "10.00",
                "backNumber": "852",
                "dressagePercentage": null
              },
              {
                "classCode": "415",
                "classTitle": "415 - Pony Hunter Handy",
                "classUrl": "https://www.usef.org/search/competitions/class/Spe54iRyVtA",
                "horse": {
                  "name": "BRIGHTON",
                  "usefHorseId": "5356986",
                  "link": "https://www.usef.org/search/horses/display/7BY-ibGLTQE?year=2025"
                },
                "entries": "2",
                "placing": "1",
                "natlPoints": "15.00",
                "zonePoints": "15.00",
                "backNumber": "852",
                "dressagePercentage": null
              },
              {
                "classCode": null,
                "classTitle": "PHCH - Pony Hunter - CHAMPIONSHIP",
                "classUrl": "https://www.usef.org/search/competitions/class/dePrZ4S2B8s",
                "horse": {
                  "name": "BRIGHTON",
                  "usefHorseId": "5356986",
                  "link": "https://www.usef.org/search/horses/display/7BY-ibGLTQE?year=2025"
                },
                "entries": "3",
                "placing": "2",
                "natlPoints": "18.00",
                "zonePoints": "18.00",
                "backNumber": "852",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3199",
            "sectionName": "Misc Equitation",
            "classes": [
              {
                "classCode": "530",
                "classTitle": "530 - Hamel Foundation/NHS 3'3  Medal",
                "classUrl": "https://www.usef.org/search/competitions/class/DDVZvANOqL0",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "7",
                "placing": "1",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "133",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "6360",
            "sectionName": "USHJA 3'3\\" HUNTER SEAT MEDAL",
            "classes": [
              {
                "classCode": "535",
                "classTitle": "535 - USHJA 3'3  Hunter Seat Medal",
                "classUrl": "https://www.usef.org/search/competitions/class/UviVD61cn-I",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "5",
                "placing": "1",
                "natlPoints": "5.00",
                "zonePoints": "0.00",
                "backNumber": "133",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "340305",
        "competitionName": "WEC OCALA SUMMER #4 (340305)",
        "id": "340305",
        "name": "WEC OCALA SUMMER #4 (340305)",
        "startDate": "7/1/2025",
        "endDate": "7/6/2025",
        "start": "2025-07-01T04:00:00.000Z",
        "end": "2025-07-06T04:00:00.000Z",
        "year": 2025,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/kiC6aImjz9k",
        "sections": [
          {
            "sectionId": "2400",
            "sectionName": "JUNIOR HUNTER",
            "classes": [
              {
                "classCode": "100",
                "classTitle": "100 - $400 Junior Hunter 3'6 FP",
                "classUrl": "https://www.usef.org/search/competitions/class/-FmWJx58pnQ",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "3",
                "placing": "1",
                "natlPoints": "15.00",
                "zonePoints": "15.00",
                "backNumber": "5748",
                "dressagePercentage": null
              },
              {
                "classCode": "101",
                "classTitle": "101 - $400 Junior Hunter 3'6 (1st rnd Classic)",
                "classUrl": "https://www.usef.org/search/competitions/class/cbPnRCmJZU4",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "3",
                "placing": "3",
                "natlPoints": "8.00",
                "zonePoints": "8.00",
                "backNumber": "5748",
                "dressagePercentage": null
              },
              {
                "classCode": "102",
                "classTitle": "102 - $400 Junior Hunter 3'6",
                "classUrl": "https://www.usef.org/search/competitions/class/GxBz0cB3Vs0",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "3",
                "placing": "3",
                "natlPoints": "8.00",
                "zonePoints": "8.00",
                "backNumber": "5748",
                "dressagePercentage": null
              },
              {
                "classCode": "103",
                "classTitle": "103 - $400 Junior Hunter 3'6 -Handy",
                "classUrl": "https://www.usef.org/search/competitions/class/7474GPBr-nw",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "3",
                "placing": "2",
                "natlPoints": "10.00",
                "zonePoints": "10.00",
                "backNumber": "5748",
                "dressagePercentage": null,
                "clipmyhorse_url": "https://www.clipmyhorse.tv/en_EU/ondemand/event/17126/competition/371668?start_at=14342867"
              },
              {
                "classCode": "104",
                "classTitle": "104 - $175 Junior Hunter 3'6 U/S",
                "classUrl": "https://www.usef.org/search/competitions/class/ESxTW2AN4G0",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "3",
                "placing": "3",
                "natlPoints": "8.00",
                "zonePoints": "8.00",
                "backNumber": "5748",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3000",
            "sectionName": "HUNTER CLASSIC",
            "classes": [
              {
                "classCode": "412",
                "classTitle": "412 - $1500 Junior Hunter Classic 3'3/3'6",
                "classUrl": "https://www.usef.org/search/competitions/class/PCn6yyG-a0Y",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "9",
                "placing": "6",
                "natlPoints": "28.00",
                "zonePoints": "20.00",
                "backNumber": "5748",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3100",
            "sectionName": "MISC. HUNTER (No points earned)",
            "classes": [
              {
                "classCode": "247",
                "classTitle": "247 - USHJA Hunter 3'3",
                "classUrl": "https://www.usef.org/search/competitions/class/X2KdtJsRMSo",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "12",
                "placing": "1",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "5748",
                "dressagePercentage": null
              },
              {
                "classCode": "248",
                "classTitle": "248 - USHJA Hunter 3'3",
                "classUrl": "https://www.usef.org/search/competitions/class/ypCSHe_y8-Q",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "12",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "5748",
                "dressagePercentage": null,
                "clipmyhorse_url": "https://www.clipmyhorse.tv/en_EU/ondemand/event/17126/competition/370725?start_at=14291977"
              },
              {
                "classCode": "406",
                "classTitle": "406 - $7500 WEC 3'6 - 3'9 Derby",
                "classUrl": "https://www.usef.org/search/competitions/class/bCIKKfYYuaU",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "12",
                "placing": "9",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "5748",
                "dressagePercentage": null,
                "clipmyhorse_url": "https://www.clipmyhorse.tv/en_EU/ondemand/event/17126/competition/371004?start_at=14312395"
              }
            ]
          },
          {
            "sectionId": "3199",
            "sectionName": "Misc Equitation",
            "classes": [
              {
                "classCode": "548",
                "classTitle": "548 - World Equestrian Center Premier Cup 3'6",
                "classUrl": "https://www.usef.org/search/competitions/class/JREUKQdWKF0",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "5",
                "placing": "1",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "5748",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "340304",
        "competitionName": "WEC OCALA SUMMER #3 (340304)",
        "id": "340304",
        "name": "WEC OCALA SUMMER #3 (340304)",
        "startDate": "6/24/2025",
        "endDate": "6/29/2025",
        "start": "2025-06-24T04:00:00.000Z",
        "end": "2025-06-29T04:00:00.000Z",
        "year": 2025,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/2-cleNhnnEY",
        "sections": [
          {
            "sectionId": "2052",
            "sectionName": "USHJA HUNTER 2'3\\"",
            "classes": [
              {
                "classCode": "262",
                "classTitle": "262 - USHJA Hunter 2'3",
                "classUrl": "https://www.usef.org/search/competitions/class/d9klLjh7kfg",
                "horse": {
                  "name": "PUPPY LOVE",
                  "usefHorseId": "5839111",
                  "link": "https://www.usef.org/search/horses/display/tlZz1vKqfNI?year=2025"
                },
                "entries": "19",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "4252",
                "dressagePercentage": null,
                "clipmyhorse_url": "https://www.clipmyhorse.tv/en_EU/ondemand/event/17125/competition/368389?start_at=14215221"
              },
              {
                "classCode": "263",
                "classTitle": "263 - USHJA Hunter 2'3",
                "classUrl": "https://www.usef.org/search/competitions/class/BOfCrMuDGD8",
                "horse": {
                  "name": "PUPPY LOVE",
                  "usefHorseId": "5839111",
                  "link": "https://www.usef.org/search/horses/display/tlZz1vKqfNI?year=2025"
                },
                "entries": "20",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "4252",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "2055",
            "sectionName": "USHJA HUNTER 3'0\\"",
            "classes": [
              {
                "classCode": "277",
                "classTitle": "277 - USHJA Hunter 3'",
                "classUrl": "https://www.usef.org/search/competitions/class/3EQSvS62sRc",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "20",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "5748",
                "dressagePercentage": null,
                "clipmyhorse_url": "https://www.clipmyhorse.tv/en_EU/ondemand/event/17125/competition/368384?start_at=14210697"
              },
              {
                "classCode": "278",
                "classTitle": "278 - USHJA Hunter 3'",
                "classUrl": "https://www.usef.org/search/competitions/class/LyMjMTDdlb0",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "17",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "5748",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3100",
            "sectionName": "MISC. HUNTER (No points earned)",
            "classes": [
              {
                "classCode": "406",
                "classTitle": "406 - $12500 WEC 3'6 - 3'9 Derby",
                "classUrl": "https://www.usef.org/search/competitions/class/ddu84mVn-5o",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "12",
                "placing": "6",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "5748",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3199",
            "sectionName": "Misc Equitation",
            "classes": [
              {
                "classCode": "548",
                "classTitle": "548 - World Equestrian Center Premier Cup 3'6",
                "classUrl": "https://www.usef.org/search/competitions/class/igPkRwQzsoE",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "9",
                "placing": "8",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "5748",
                "dressagePercentage": null,
                "clipmyhorse_url": "https://www.clipmyhorse.tv/en_EU/ondemand/event/17125/competition/369486?start_at=14274432"
              }
            ]
          },
          {
            "sectionId": "6100",
            "sectionName": "DOVER SADDLERY/USEF HUNTER SEAT MEDAL",
            "classes": [
              {
                "classCode": "528",
                "classTitle": "528 - USEF Hunter Seat Medal 3'6",
                "classUrl": "https://www.usef.org/search/competitions/class/f9G8JS-yFrg",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "3",
                "placing": "3",
                "natlPoints": "3.00",
                "zonePoints": "0.00",
                "backNumber": "5748",
                "dressagePercentage": null,
                "clipmyhorse_url": "https://www.clipmyhorse.tv/en_EU/ondemand/event/17125/competition/369488?start_at=14274906"
              }
            ]
          }
        ]
      },
      {
        "competitionId": "7126",
        "competitionName": "EQUESTRIAN SPORT PRODUCTIONS, LLC. JUNE II (7126)",
        "id": "7126",
        "name": "EQUESTRIAN SPORT PRODUCTIONS, LLC. JUNE II (7126)",
        "startDate": "6/6/2025",
        "endDate": "6/8/2025",
        "start": "2025-06-06T04:00:00.000Z",
        "end": "2025-06-08T04:00:00.000Z",
        "year": 2025,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/fBYCghfBmnA",
        "sections": [
          {
            "sectionId": "2400",
            "sectionName": "JUNIOR HUNTER",
            "classes": [
              {
                "classCode": "306",
                "classTitle": "306 - Junior Hunter 3'6 U/S",
                "classUrl": "https://www.usef.org/search/competitions/class/-eWgdNY66lw",
                "horse": {
                  "name": "QUIDAM'S REVEAL",
                  "usefHorseId": "5403182",
                  "link": "https://www.usef.org/search/horses/display/soV8Wb7xWw4?year=2025"
                },
                "entries": "4",
                "placing": "3",
                "natlPoints": "8.00",
                "zonePoints": "8.00",
                "backNumber": "4",
                "dressagePercentage": null
              },
              {
                "classCode": "307",
                "classTitle": "307 - Junior Hunter 3'6 FP",
                "classUrl": "https://www.usef.org/search/competitions/class/_1VDLLaLW8g",
                "horse": {
                  "name": "QUIDAM'S REVEAL",
                  "usefHorseId": "5403182",
                  "link": "https://www.usef.org/search/horses/display/soV8Wb7xWw4?year=2025"
                },
                "entries": "4",
                "placing": "2",
                "natlPoints": "10.00",
                "zonePoints": "10.00",
                "backNumber": "4",
                "dressagePercentage": null
              },
              {
                "classCode": "308",
                "classTitle": "308 - Junior Hunter 3'6",
                "classUrl": "https://www.usef.org/search/competitions/class/FF0oE_Lwk8o",
                "horse": {
                  "name": "QUIDAM'S REVEAL",
                  "usefHorseId": "5403182",
                  "link": "https://www.usef.org/search/horses/display/soV8Wb7xWw4?year=2025"
                },
                "entries": "4",
                "placing": "3",
                "natlPoints": "8.00",
                "zonePoints": "8.00",
                "backNumber": "4",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3199",
            "sectionName": "Misc Equitation",
            "classes": [
              {
                "classCode": "530",
                "classTitle": "530 - Hamel Foundation/NHS 3'3  Medal",
                "classUrl": "https://www.usef.org/search/competitions/class/QO28qzY8GS4",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "10",
                "placing": "6",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "133",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "6100",
            "sectionName": "DOVER SADDLERY/USEF HUNTER SEAT MEDAL",
            "classes": [
              {
                "classCode": "550",
                "classTitle": "550 - Dover Saddlery/USEF Hunter Seat Medal",
                "classUrl": "https://www.usef.org/search/competitions/class/1x7pa9UK13U",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "6",
                "placing": "3",
                "natlPoints": "6.00",
                "zonePoints": "0.00",
                "backNumber": "133",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "5029",
        "competitionName": "EQUESTRIAN SPORT PRODUCTIONS, LLC. JUNE I (5029)",
        "id": "5029",
        "name": "EQUESTRIAN SPORT PRODUCTIONS, LLC. JUNE I (5029)",
        "startDate": "5/30/2025",
        "endDate": "6/1/2025",
        "start": "2025-05-30T04:00:00.000Z",
        "end": "2025-06-01T04:00:00.000Z",
        "year": 2025,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/xcSoRv1meVE",
        "sections": [
          {
            "sectionId": "3199",
            "sectionName": "Misc Equitation",
            "classes": [
              {
                "classCode": "530",
                "classTitle": "530 - Hamel Foundation/NHS 3'3  Medal",
                "classUrl": "https://www.usef.org/search/competitions/class/I6g5FsO8Pak",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "14",
                "placing": "1",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "133",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "6100",
            "sectionName": "DOVER SADDLERY/USEF HUNTER SEAT MEDAL",
            "classes": [
              {
                "classCode": "550",
                "classTitle": "550 - Dover Saddlery/USEF Hunter Seat Medal",
                "classUrl": "https://www.usef.org/search/competitions/class/IVznsJgpD_E",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "3",
                "placing": "1",
                "natlPoints": "5.00",
                "zonePoints": "0.00",
                "backNumber": "133",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "340245",
        "competitionName": "ESP JUNE EQUITATION DAY #1 (340245)",
        "id": "340245",
        "name": "ESP JUNE EQUITATION DAY #1 (340245)",
        "startDate": "5/29/2025",
        "endDate": "5/29/2025",
        "start": "2025-05-29T04:00:00.000Z",
        "end": "2025-05-29T04:00:00.000Z",
        "year": 2025,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/B6B2bNcpdUg",
        "sections": [
          {
            "sectionId": "3199",
            "sectionName": "Misc Equitation",
            "classes": [
              {
                "classCode": "530",
                "classTitle": "530 - Hamel Foundation NHS 3'3' Medal",
                "classUrl": "https://www.usef.org/search/competitions/class/lfAnUKk0aQ8",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "11",
                "placing": "1",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "133",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "6100",
            "sectionName": "DOVER SADDLERY/USEF HUNTER SEAT MEDAL",
            "classes": [
              {
                "classCode": "550",
                "classTitle": "550 - Dover Saddlery USEF Hunter Seat Medal",
                "classUrl": "https://www.usef.org/search/competitions/class/N0ac1z45TeM",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "3",
                "placing": "1",
                "natlPoints": "5.00",
                "zonePoints": "0.00",
                "backNumber": "133",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "6349",
            "sectionName": "USHJA 3'3 JUMPING SEAT MEDAL",
            "classes": [
              {
                "classCode": "545",
                "classTitle": "545 - USHJA Jumping Seat Medal 3'3",
                "classUrl": "https://www.usef.org/search/competitions/class/y-CE_1S2i7M",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "6",
                "placing": "1",
                "natlPoints": "6.00",
                "zonePoints": "0.00",
                "backNumber": "133",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "327488",
        "competitionName": "SFHJA MAY II SHOW (327488)",
        "id": "327488",
        "name": "SFHJA MAY II SHOW (327488)",
        "startDate": "5/17/2025",
        "endDate": "5/18/2025",
        "start": "2025-05-17T04:00:00.000Z",
        "end": "2025-05-18T04:00:00.000Z",
        "year": 2025,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/mKKrYbxb1T8",
        "sections": [
          {
            "sectionId": "3199",
            "sectionName": "Misc Equitation",
            "classes": [
              {
                "classCode": "535",
                "classTitle": "535 - Hamel Foundation/NHS 3'3  Medal",
                "classUrl": "https://www.usef.org/search/competitions/class/gN3vaesbZ-o",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "8",
                "placing": "4",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1356",
                "dressagePercentage": null
              },
              {
                "classCode": "570",
                "classTitle": "570 - ASPCA Maclay",
                "classUrl": "https://www.usef.org/search/competitions/class/cFnO2pV315g",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "5",
                "placing": "2",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1356",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "6100",
            "sectionName": "DOVER SADDLERY/USEF HUNTER SEAT MEDAL",
            "classes": [
              {
                "classCode": "550",
                "classTitle": "550 - Dover/USEF Hunter Seat Medal",
                "classUrl": "https://www.usef.org/search/competitions/class/NGXtJjT7k5s",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "3",
                "placing": "1",
                "natlPoints": "5.00",
                "zonePoints": "0.00",
                "backNumber": "1356",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "330610",
        "competitionName": "SFHJA MAY I (330610)",
        "id": "330610",
        "name": "SFHJA MAY I (330610)",
        "startDate": "5/16/2025",
        "endDate": "5/16/2025",
        "start": "2025-05-16T04:00:00.000Z",
        "end": "2025-05-16T04:00:00.000Z",
        "year": 2025,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/l4SNuhQN5ig",
        "sections": [
          {
            "sectionId": "3199",
            "sectionName": "Misc Equitation",
            "classes": [
              {
                "classCode": "535",
                "classTitle": "535 - Hamel Foundation/NHS 3'3  Junior Medal",
                "classUrl": "https://www.usef.org/search/competitions/class/gnFh-ADRUgk",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "5",
                "placing": "2",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1356",
                "dressagePercentage": null
              },
              {
                "classCode": "570",
                "classTitle": "570 - ASPCA Maclay",
                "classUrl": "https://www.usef.org/search/competitions/class/yZWXd2Iavi0",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "6",
                "placing": "2",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1356",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "6100",
            "sectionName": "DOVER SADDLERY/USEF HUNTER SEAT MEDAL",
            "classes": [
              {
                "classCode": "550",
                "classTitle": "550 - Dover Saddlery/USEF Hunter Seat Medal",
                "classUrl": "https://www.usef.org/search/competitions/class/fqlKp8hNFg4",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "6",
                "placing": "3",
                "natlPoints": "6.00",
                "zonePoints": "0.00",
                "backNumber": "1356",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "6350",
            "sectionName": "USHJA 3'3\\" JUNIOR JUMPING SEAT MEDAL",
            "classes": [
              {
                "classCode": "545",
                "classTitle": "545 - USHJA 3'3 Junior Jumping Seat Medal",
                "classUrl": "https://www.usef.org/search/competitions/class/fHm7JTnx8eM",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "3",
                "placing": "1",
                "natlPoints": "3.00",
                "zonePoints": "0.00",
                "backNumber": "1356",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "4397",
        "competitionName": "EQUESTRIAN SPORT PRODUCTIONS, LLC. SPRING 5 (4397)",
        "id": "4397",
        "name": "EQUESTRIAN SPORT PRODUCTIONS, LLC. SPRING 5 (4397)",
        "startDate": "5/8/2025",
        "endDate": "5/11/2025",
        "start": "2025-05-08T04:00:00.000Z",
        "end": "2025-05-11T04:00:00.000Z",
        "year": 2025,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/WR5_ywlWER4",
        "sections": [
          {
            "sectionId": "3199",
            "sectionName": "Misc Equitation",
            "classes": [
              {
                "classCode": "530",
                "classTitle": "530 - Hamel Foundation/NHS 3'3  Medal",
                "classUrl": "https://www.usef.org/search/competitions/class/eP1TBT6W-vo",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "15",
                "placing": "3",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "3076",
                "dressagePercentage": null
              },
              {
                "classCode": "570",
                "classTitle": "570 - ASPCA Maclay",
                "classUrl": "https://www.usef.org/search/competitions/class/nTEbmCkgDNU",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "10",
                "placing": "1",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "3076",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3800",
            "sectionName": "MISC JUMPER",
            "classes": [
              {
                "classCode": "780",
                "classTitle": "780 - Training Jumper (1.0m) II2d",
                "classUrl": "https://www.usef.org/search/competitions/class/vFhCYWMm3f4",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "24",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "3076",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "6100",
            "sectionName": "DOVER SADDLERY/USEF HUNTER SEAT MEDAL",
            "classes": [
              {
                "classCode": "550",
                "classTitle": "550 - Dover Saddlery/USEF Hunter Seat Medal",
                "classUrl": "https://www.usef.org/search/competitions/class/0YOSrO3ZaDE",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "10",
                "placing": "1",
                "natlPoints": "10.00",
                "zonePoints": "0.00",
                "backNumber": "3076",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "6349",
            "sectionName": "USHJA 3'3 JUMPING SEAT MEDAL",
            "classes": [
              {
                "classCode": "545",
                "classTitle": "545 - USHJA 3'3 Junior/Amateur Jumper Seat Medal",
                "classUrl": "https://www.usef.org/search/competitions/class/56w81cfgw8Y",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "6",
                "placing": "4",
                "natlPoints": "3.00",
                "zonePoints": "0.00",
                "backNumber": "3076",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "7179",
        "competitionName": "EQUESTRIAN SPORT PRODUCTIONS, LLC. SPRING 4 (7179)",
        "id": "7179",
        "name": "EQUESTRIAN SPORT PRODUCTIONS, LLC. SPRING 4 (7179)",
        "startDate": "5/1/2025",
        "endDate": "5/4/2025",
        "start": "2025-05-01T04:00:00.000Z",
        "end": "2025-05-04T04:00:00.000Z",
        "year": 2025,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/UIml-3lWi7M",
        "sections": [
          {
            "sectionId": "3199",
            "sectionName": "Misc Equitation",
            "classes": [
              {
                "classCode": "530",
                "classTitle": "530 - Hamel Foundation/NHS 3'3  Medal",
                "classUrl": "https://www.usef.org/search/competitions/class/cWvzSAEdma8",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "13",
                "placing": "5",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "3076",
                "dressagePercentage": null
              },
              {
                "classCode": "570",
                "classTitle": "570 - ASPCA Maclay",
                "classUrl": "https://www.usef.org/search/competitions/class/cIx_V-XO3uE",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "8",
                "placing": "8",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "3076",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3800",
            "sectionName": "MISC JUMPER",
            "classes": [
              {
                "classCode": "750",
                "classTitle": "750 - Training Jumper (.95m) II2d",
                "classUrl": "https://www.usef.org/search/competitions/class/-kz8RABzwh8",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "11",
                "placing": "7",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "3076",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "6100",
            "sectionName": "DOVER SADDLERY/USEF HUNTER SEAT MEDAL",
            "classes": [
              {
                "classCode": "550",
                "classTitle": "550 - Dover Saddlery/USEF Hunter Seat Medal",
                "classUrl": "https://www.usef.org/search/competitions/class/ofajqdK3Qp8",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "9",
                "placing": "3",
                "natlPoints": "6.00",
                "zonePoints": "0.00",
                "backNumber": "3076",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "6349",
            "sectionName": "USHJA 3'3 JUMPING SEAT MEDAL",
            "classes": [
              {
                "classCode": "545",
                "classTitle": "545 - USHJA 3'3  Jumper Seat Medal",
                "classUrl": "https://www.usef.org/search/competitions/class/SbKl2-b3SHk",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "6",
                "placing": "3",
                "natlPoints": "4.00",
                "zonePoints": "0.00",
                "backNumber": "3076",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "5028",
        "competitionName": "EQUESTRIAN SPORT PRODUCTIONS, LLC. SPRING 3 (5028)",
        "id": "5028",
        "name": "EQUESTRIAN SPORT PRODUCTIONS, LLC. SPRING 3 (5028)",
        "startDate": "4/15/2025",
        "endDate": "4/19/2025",
        "start": "2025-04-15T04:00:00.000Z",
        "end": "2025-04-19T04:00:00.000Z",
        "year": 2025,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/UDuZc53VBwc",
        "sections": [
          {
            "sectionId": "3199",
            "sectionName": "Misc Equitation",
            "classes": [
              {
                "classCode": "525",
                "classTitle": "525 - SFHJA Junior/Adult Amateur Medal (Flat Phase)",
                "classUrl": "https://www.usef.org/search/competitions/class/l66YUtqaJwM",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "11",
                "placing": "1",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "3076",
                "dressagePercentage": null
              },
              {
                "classCode": "529",
                "classTitle": "529 - M&S Children's/Adult Medal",
                "classUrl": "https://www.usef.org/search/competitions/class/YgIr-h50bLw",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "8",
                "placing": "2",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "3076",
                "dressagePercentage": null
              },
              {
                "classCode": "530",
                "classTitle": "530 - Hamel Foundation/NHS 3'3  Medal",
                "classUrl": "https://www.usef.org/search/competitions/class/m3vyKeInDZE",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "21",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "3076",
                "dressagePercentage": null
              },
              {
                "classCode": "555",
                "classTitle": "555 - THIS Children's Medal",
                "classUrl": "https://www.usef.org/search/competitions/class/Bui8YEKB2n0",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "27",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "3076",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3800",
            "sectionName": "MISC JUMPER",
            "classes": [
              {
                "classCode": "783",
                "classTitle": "783 - Puddle Jumper Open (.70-.80m) II2b",
                "classUrl": "https://www.usef.org/search/competitions/class/s6gEPoTR-ek",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "18",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "3076",
                "dressagePercentage": null
              },
              {
                "classCode": "795",
                "classTitle": "795 - Puddle Jumper Junior/Amateur (.70-.80m) II2b",
                "classUrl": "https://www.usef.org/search/competitions/class/feam8ILpLoE",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "13",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "3076",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "6050",
            "sectionName": "USEF/NCEA Junior Hunter Seat Medal",
            "classes": [
              {
                "classCode": "585",
                "classTitle": "585 - USEF/NCEA Junior Hunter Seat Medal",
                "classUrl": "https://www.usef.org/search/competitions/class/K9xHEDLrCPA",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "6",
                "placing": "3",
                "natlPoints": "24.00",
                "zonePoints": "0.00",
                "backNumber": "3076",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "200",
        "competitionName": "WEF 6 EQUESTRIAN SPORT PRODUCTIONS, LLC (200)",
        "id": "200",
        "name": "WEF 6 EQUESTRIAN SPORT PRODUCTIONS, LLC (200)",
        "startDate": "2/11/2026",
        "endDate": "2/15/2026",
        "start": "2026-02-11T05:00:00.000Z",
        "end": "2026-02-15T05:00:00.000Z",
        "year": 2026,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/Nkg0dZCOyWo",
        "sections": [
          {
            "sectionId": "2052",
            "sectionName": "USHJA HUNTER 2'3\\"",
            "classes": [
              {
                "classCode": "2129",
                "classTitle": "2129 - USHJA Hunter 2'3",
                "classUrl": "https://www.usef.org/search/competitions/class/riJ15N4jZao",
                "horse": {
                  "name": "CHARMING BOY O",
                  "usefHorseId": "5615354",
                  "link": "https://www.usef.org/search/horses/display/_LpmjJWklsg?year=2026"
                },
                "entries": "20",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1063",
                "dressagePercentage": null
              },
              {
                "classCode": "2129",
                "classTitle": "2129 - USHJA Hunter 2'3",
                "classUrl": "https://www.usef.org/search/competitions/class/riJ15N4jZao",
                "horse": {
                  "name": "PUPPY LOVE",
                  "usefHorseId": "5839111",
                  "link": "https://www.usef.org/search/horses/display/tlZz1vKqfNI?year=2026"
                },
                "entries": "20",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1084",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "962",
        "competitionName": "WEF 3 (962)",
        "id": "962",
        "name": "WEF 3 (962)",
        "startDate": "1/20/2026",
        "endDate": "1/25/2026",
        "start": "2026-01-20T05:00:00.000Z",
        "end": "2026-01-25T05:00:00.000Z",
        "year": 2026,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/CXFzSL7yUTw",
        "sections": [
          {
            "sectionId": "2053",
            "sectionName": "USHJA HUNTER 2'6\\"",
            "classes": [
              {
                "classCode": "4019B",
                "classTitle": "4019B - USHJA Hunter 2'6 (Cali Split)",
                "classUrl": "https://www.usef.org/search/competitions/class/aETx2PZor7s",
                "horse": {
                  "name": "CHARMING BOY O",
                  "usefHorseId": "5615354",
                  "link": "https://www.usef.org/search/horses/display/_LpmjJWklsg?year=2026"
                },
                "entries": "19",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1063",
                "dressagePercentage": null
              },
              {
                "classCode": "4019B",
                "classTitle": "4019B - USHJA Hunter 2'6 (Cali Split)",
                "classUrl": "https://www.usef.org/search/competitions/class/aETx2PZor7s",
                "horse": {
                  "name": "PUPPY LOVE",
                  "usefHorseId": "5839111",
                  "link": "https://www.usef.org/search/horses/display/tlZz1vKqfNI?year=2026"
                },
                "entries": "19",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1084",
                "dressagePercentage": null
              },
              {
                "classCode": "4020",
                "classTitle": "4020 - USHJA Hunter 2'6",
                "classUrl": "https://www.usef.org/search/competitions/class/gmdKXgY-zNg",
                "horse": {
                  "name": "PUPPY LOVE",
                  "usefHorseId": "5839111",
                  "link": "https://www.usef.org/search/horses/display/tlZz1vKqfNI?year=2026"
                },
                "entries": "29",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1084",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "5027",
        "competitionName": "WEF 2 (5027)",
        "id": "5027",
        "name": "WEF 2 (5027)",
        "startDate": "1/14/2026",
        "endDate": "1/18/2026",
        "start": "2026-01-14T05:00:00.000Z",
        "end": "2026-01-18T05:00:00.000Z",
        "year": 2026,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/SjBWw5p6IBo",
        "sections": [
          {
            "sectionId": "3117",
            "sectionName": "HUNTER EQUITATION 12-14",
            "classes": [
              {
                "classCode": "3012B",
                "classTitle": "3012B - 12-14 Equitation Flat (Cali Split)",
                "classUrl": "https://www.usef.org/search/competitions/class/FSR4D5yeTXw",
                "horse": {
                  "name": "OWIN",
                  "usefHorseId": "6099035",
                  "link": "https://www.usef.org/search/horses/display/_2YoHI9nhPc?year=2026"
                },
                "entries": "14",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "6446",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3199",
            "sectionName": "Misc Equitation",
            "classes": [
              {
                "classCode": "3037",
                "classTitle": "3037 - Hamel Foundation NHS 3'3 Medal Sec. B",
                "classUrl": "https://www.usef.org/search/competitions/class/KmHZVYuDi60",
                "horse": {
                  "name": "OWIN",
                  "usefHorseId": "6099035",
                  "link": "https://www.usef.org/search/horses/display/_2YoHI9nhPc?year=2026"
                },
                "entries": "21",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "6446",
                "dressagePercentage": null
              },
              {
                "classCode": "3075",
                "classTitle": "3075 - SFHJA Junior Hunter Seat Medal 14 & Under (Flat Phase)",
                "classUrl": "https://www.usef.org/search/competitions/class/-e63hGw-n2Y",
                "horse": {
                  "name": "OWIN",
                  "usefHorseId": "6099035",
                  "link": "https://www.usef.org/search/horses/display/_2YoHI9nhPc?year=2026"
                },
                "entries": "17",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "6446",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "1893",
        "competitionName": "WEF 1 (1893)",
        "id": "1893",
        "name": "WEF 1 (1893)",
        "startDate": "1/7/2026",
        "endDate": "1/11/2026",
        "start": "2026-01-07T05:00:00.000Z",
        "end": "2026-01-11T05:00:00.000Z",
        "year": 2026,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/mbJWY_bEbdY",
        "sections": [
          {
            "sectionId": "2053",
            "sectionName": "USHJA HUNTER 2'6\\"",
            "classes": [
              {
                "classCode": "4019B",
                "classTitle": "4019B - USHJA Hunter 2'6 (Cali Split)",
                "classUrl": "https://www.usef.org/search/competitions/class/Q4VoKm-HL_g",
                "horse": {
                  "name": "CHARMING BOY O",
                  "usefHorseId": "5615354",
                  "link": "https://www.usef.org/search/horses/display/_LpmjJWklsg?year=2026"
                },
                "entries": "20",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1063",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "2703",
            "sectionName": "CHILDRENS HUNTER-HORSE 14 & UNDER",
            "classes": [
              {
                "classCode": "2851A",
                "classTitle": "2851A - Children's Hunter 14 & Under U/S (Cali Split)",
                "classUrl": "https://www.usef.org/search/competitions/class/kfuyb3iBk9A",
                "horse": {
                  "name": "QUIDAM'S REVEAL",
                  "usefHorseId": "5403182",
                  "link": "https://www.usef.org/search/horses/display/soV8Wb7xWw4?year=2026"
                },
                "entries": "20",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "25",
                "dressagePercentage": null
              },
              {
                "classCode": "2852B",
                "classTitle": "2852B - Children's Hunter 14 & Under (Cali Split)",
                "classUrl": "https://www.usef.org/search/competitions/class/B9q9HlMgc_k",
                "horse": {
                  "name": "QUIDAM'S REVEAL",
                  "usefHorseId": "5403182",
                  "link": "https://www.usef.org/search/horses/display/soV8Wb7xWw4?year=2026"
                },
                "entries": "21",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "25",
                "dressagePercentage": null
              },
              {
                "classCode": "2853B",
                "classTitle": "2853B - Children's Hunter 14 & Under (Cali Split)",
                "classUrl": "https://www.usef.org/search/competitions/class/wNYz8sfTdx0",
                "horse": {
                  "name": "QUIDAM'S REVEAL",
                  "usefHorseId": "5403182",
                  "link": "https://www.usef.org/search/horses/display/soV8Wb7xWw4?year=2026"
                },
                "entries": "21",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "25",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3117",
            "sectionName": "HUNTER EQUITATION 12-14",
            "classes": [
              {
                "classCode": "3012B",
                "classTitle": "3012B - 12-14 Equitation Flat (Cali Split)",
                "classUrl": "https://www.usef.org/search/competitions/class/eiKYbSk04Hs",
                "horse": {
                  "name": "OWIN",
                  "usefHorseId": "6099035",
                  "link": "https://www.usef.org/search/horses/display/_2YoHI9nhPc?year=2026"
                },
                "entries": "13",
                "placing": "2",
                "natlPoints": "15.00",
                "zonePoints": "15.00",
                "backNumber": "6446",
                "dressagePercentage": null
              },
              {
                "classCode": "3013B",
                "classTitle": "3013B - 12-14 Equitation 2'9 (Cali Split)",
                "classUrl": "https://www.usef.org/search/competitions/class/pzoQkyFKdOc",
                "horse": {
                  "name": "OWIN",
                  "usefHorseId": "6099035",
                  "link": "https://www.usef.org/search/horses/display/_2YoHI9nhPc?year=2026"
                },
                "entries": "13",
                "placing": "6",
                "natlPoints": "4.00",
                "zonePoints": "4.00",
                "backNumber": "6446",
                "dressagePercentage": null
              },
              {
                "classCode": "3014A",
                "classTitle": "3014A - 12-14 Equitation 2'9 (Cali Split)",
                "classUrl": "https://www.usef.org/search/competitions/class/r0Vb9o26Jt0",
                "horse": {
                  "name": "OWIN",
                  "usefHorseId": "6099035",
                  "link": "https://www.usef.org/search/horses/display/_2YoHI9nhPc?year=2026"
                },
                "entries": "13",
                "placing": "2",
                "natlPoints": "15.00",
                "zonePoints": "15.00",
                "backNumber": "6446",
                "dressagePercentage": null
              },
              {
                "classCode": null,
                "classTitle": "EQ12CHB - 12-14 Equitation 2'9 Championship B",
                "classUrl": "https://www.usef.org/search/competitions/class/czoQqVGPBCg",
                "horse": {
                  "name": "OWIN",
                  "usefHorseId": "6099035",
                  "link": "https://www.usef.org/search/horses/display/_2YoHI9nhPc?year=2026"
                },
                "entries": "13",
                "placing": "2",
                "natlPoints": "24.00",
                "zonePoints": "24.00",
                "backNumber": "6446",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3199",
            "sectionName": "Misc Equitation",
            "classes": [
              {
                "classCode": "3037",
                "classTitle": "3037 - Hamel Foundation NHS 3'3 Medal Section B",
                "classUrl": "https://www.usef.org/search/competitions/class/Jwe61S_Ornc",
                "horse": {
                  "name": "OWIN",
                  "usefHorseId": "6099035",
                  "link": "https://www.usef.org/search/horses/display/_2YoHI9nhPc?year=2026"
                },
                "entries": "23",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "6446",
                "dressagePercentage": null
              },
              {
                "classCode": "3075",
                "classTitle": "3075 - SFHJA Junior Hunter Seat Medal 14 & Under (Flat Phase)",
                "classUrl": "https://www.usef.org/search/competitions/class/tbabo25UbMk",
                "horse": {
                  "name": "OWIN",
                  "usefHorseId": "6099035",
                  "link": "https://www.usef.org/search/horses/display/_2YoHI9nhPc?year=2026"
                },
                "entries": "9",
                "placing": "4",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "6446",
                "dressagePercentage": null
              },
              {
                "classCode": "3080",
                "classTitle": "3080 - THIS Children's Medal 14 & Under",
                "classUrl": "https://www.usef.org/search/competitions/class/W685d8gZdGs",
                "horse": {
                  "name": "OWIN",
                  "usefHorseId": "6099035",
                  "link": "https://www.usef.org/search/horses/display/_2YoHI9nhPc?year=2026"
                },
                "entries": "36",
                "placing": "8",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "6446",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3800",
            "sectionName": "MISC JUMPER",
            "classes": [
              {
                "classCode": "1108",
                "classTitle": "1108 - .90m Training Jumper (Table II)",
                "classUrl": "https://www.usef.org/search/competitions/class/vhGppaVOMIc",
                "horse": {
                  "name": "OWIN",
                  "usefHorseId": "6099035",
                  "link": "https://www.usef.org/search/horses/display/_2YoHI9nhPc?year=2026"
                },
                "entries": "24",
                "placing": "1",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "6446",
                "dressagePercentage": null
              },
              {
                "classCode": "1111",
                "classTitle": "1111 - .90m Low Child/Adult Amateur Training Jumper 39 & Under II2d",
                "classUrl": "https://www.usef.org/search/competitions/class/Pjt0UuAyX10",
                "horse": {
                  "name": "OWIN",
                  "usefHorseId": "6099035",
                  "link": "https://www.usef.org/search/horses/display/_2YoHI9nhPc?year=2026"
                },
                "entries": "21",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "6446",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "233832",
        "competitionName": "WEF PREMIER (233832)",
        "id": "233832",
        "name": "WEF PREMIER (233832)",
        "startDate": "12/31/2025",
        "endDate": "1/4/2026",
        "start": "2025-12-31T05:00:00.000Z",
        "end": "2026-01-04T05:00:00.000Z",
        "year": 2025,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/s8iwuZluS4E",
        "sections": [
          {
            "sectionId": "2051",
            "sectionName": "USHJA HUNTER 2'0\\"",
            "classes": [
              {
                "classCode": "2122",
                "classTitle": "2122 - USHJA Hunter 2'",
                "classUrl": "https://www.usef.org/search/competitions/class/6prbbs2C_5Y",
                "horse": {
                  "name": "FORT KNOX",
                  "usefHorseId": "6072529",
                  "link": "https://www.usef.org/search/horses/display/eQOXBC-5Pu4?year=2026"
                },
                "entries": "5",
                "placing": "4",
                "natlPoints": "8.00",
                "zonePoints": "8.00",
                "backNumber": "1067",
                "dressagePercentage": null
              },
              {
                "classCode": "2123",
                "classTitle": "2123 - USHJA Hunter 2'",
                "classUrl": "https://www.usef.org/search/competitions/class/ePz1bQzf5uw",
                "horse": {
                  "name": "FORT KNOX",
                  "usefHorseId": "6072529",
                  "link": "https://www.usef.org/search/horses/display/eQOXBC-5Pu4?year=2026"
                },
                "entries": "5",
                "placing": "3",
                "natlPoints": "11.00",
                "zonePoints": "11.00",
                "backNumber": "1067",
                "dressagePercentage": null
              },
              {
                "classCode": "2123",
                "classTitle": "2123 - USHJA Hunter 2'",
                "classUrl": "https://www.usef.org/search/competitions/class/ePz1bQzf5uw",
                "horse": {
                  "name": "PUPPY LOVE",
                  "usefHorseId": "5839111",
                  "link": "https://www.usef.org/search/horses/display/tlZz1vKqfNI?year=2026"
                },
                "entries": "5",
                "placing": "5",
                "natlPoints": "7.00",
                "zonePoints": "7.00",
                "backNumber": "1084",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "2052",
            "sectionName": "USHJA HUNTER 2'3\\"",
            "classes": [
              {
                "classCode": "2129",
                "classTitle": "2129 - USHJA Hunter 2'3",
                "classUrl": "https://www.usef.org/search/competitions/class/sJnwIGKbBnI",
                "horse": {
                  "name": "PUPPY LOVE",
                  "usefHorseId": "5839111",
                  "link": "https://www.usef.org/search/horses/display/tlZz1vKqfNI?year=2026"
                },
                "entries": "14",
                "placing": "4",
                "natlPoints": "11.00",
                "zonePoints": "11.00",
                "backNumber": "1084",
                "dressagePercentage": null
              },
              {
                "classCode": "2129",
                "classTitle": "2129 - USHJA Hunter 2'3",
                "classUrl": "https://www.usef.org/search/competitions/class/sJnwIGKbBnI",
                "horse": {
                  "name": "FORT KNOX",
                  "usefHorseId": "6072529",
                  "link": "https://www.usef.org/search/horses/display/eQOXBC-5Pu4?year=2026"
                },
                "entries": "14",
                "placing": "5",
                "natlPoints": "10.00",
                "zonePoints": "10.00",
                "backNumber": "1067",
                "dressagePercentage": null
              },
              {
                "classCode": "2130",
                "classTitle": "2130 - USHJA Hunter 2'3",
                "classUrl": "https://www.usef.org/search/competitions/class/vIz6bOv94sg",
                "horse": {
                  "name": "FORT KNOX",
                  "usefHorseId": "6072529",
                  "link": "https://www.usef.org/search/horses/display/eQOXBC-5Pu4?year=2026"
                },
                "entries": "13",
                "placing": "2",
                "natlPoints": "18.00",
                "zonePoints": "18.00",
                "backNumber": "1067",
                "dressagePercentage": null
              },
              {
                "classCode": "2130",
                "classTitle": "2130 - USHJA Hunter 2'3",
                "classUrl": "https://www.usef.org/search/competitions/class/vIz6bOv94sg",
                "horse": {
                  "name": "PUPPY LOVE",
                  "usefHorseId": "5839111",
                  "link": "https://www.usef.org/search/horses/display/tlZz1vKqfNI?year=2026"
                },
                "entries": "13",
                "placing": "5",
                "natlPoints": "10.00",
                "zonePoints": "10.00",
                "backNumber": "1084",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "340201",
        "competitionName": "ESP HOLIDAY FINALE (340201)",
        "id": "340201",
        "name": "ESP HOLIDAY FINALE (340201)",
        "startDate": "12/18/2025",
        "endDate": "12/21/2025",
        "start": "2025-12-18T05:00:00.000Z",
        "end": "2025-12-21T05:00:00.000Z",
        "year": 2025,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/LZJFb9Tncdc",
        "sections": [
          {
            "sectionId": "2052",
            "sectionName": "USHJA HUNTER 2'3\\"",
            "classes": [
              {
                "classCode": "184",
                "classTitle": "184 - USHJA Hunter 2'3",
                "classUrl": "https://www.usef.org/search/competitions/class/OyOKYwDUz9I",
                "horse": {
                  "name": "FORT KNOX",
                  "usefHorseId": "6072529",
                  "link": "https://www.usef.org/search/horses/display/eQOXBC-5Pu4?year=2026"
                },
                "entries": "11",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1828",
                "dressagePercentage": null
              },
              {
                "classCode": "185",
                "classTitle": "185 - USHJA Hunter 2'3",
                "classUrl": "https://www.usef.org/search/competitions/class/4CLDIX9ES9A",
                "horse": {
                  "name": "FORT KNOX",
                  "usefHorseId": "6072529",
                  "link": "https://www.usef.org/search/horses/display/eQOXBC-5Pu4?year=2026"
                },
                "entries": "11",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1828",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "2053",
            "sectionName": "USHJA HUNTER 2'6\\"",
            "classes": [
              {
                "classCode": "234",
                "classTitle": "234 - USHJA Hunter 2'6",
                "classUrl": "https://www.usef.org/search/competitions/class/ntD_VR32kss",
                "horse": {
                  "name": "CHARMING BOY O",
                  "usefHorseId": "5615354",
                  "link": "https://www.usef.org/search/horses/display/_LpmjJWklsg?year=2026"
                },
                "entries": "20",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "2566",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "2054",
            "sectionName": "USHJA HUNTER 2'9\\"",
            "classes": [
              {
                "classCode": "190",
                "classTitle": "190 - USHJA Hunter 2'9",
                "classUrl": "https://www.usef.org/search/competitions/class/oD06fuA5m8Q",
                "horse": {
                  "name": "NAVIGATOR",
                  "usefHorseId": "5805986",
                  "link": "https://www.usef.org/search/horses/display/b6b6Wpbu1MA?year=2026"
                },
                "entries": "20",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "3214",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "2603",
            "sectionName": "GREEN PONY HUNTER-MEDIUM",
            "classes": [
              {
                "classCode": "451",
                "classTitle": "451 - Medium Green Pony Hunter U/S",
                "classUrl": "https://www.usef.org/search/competitions/class/ZHdfrqohhtw",
                "horse": {
                  "name": "QUEEN ELIZABETH",
                  "usefHorseId": "6031861",
                  "link": "https://www.usef.org/search/horses/display/6f8YmHOk-3M?year=2026"
                },
                "entries": "4",
                "placing": "3",
                "natlPoints": "8.00",
                "zonePoints": "8.00",
                "backNumber": "3442",
                "dressagePercentage": null
              },
              {
                "classCode": "452",
                "classTitle": "452 - Medium Green Pony Hunter - FP",
                "classUrl": "https://www.usef.org/search/competitions/class/MI1J6ndhccw",
                "horse": {
                  "name": "QUEEN ELIZABETH",
                  "usefHorseId": "6031861",
                  "link": "https://www.usef.org/search/horses/display/6f8YmHOk-3M?year=2026"
                },
                "entries": "4",
                "placing": "4",
                "natlPoints": "6.00",
                "zonePoints": "6.00",
                "backNumber": "3442",
                "dressagePercentage": null
              },
              {
                "classCode": "453",
                "classTitle": "453 - Medium Green Pony Conformation Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/bfupphAe34U",
                "horse": {
                  "name": "QUEEN ELIZABETH",
                  "usefHorseId": "6031861",
                  "link": "https://www.usef.org/search/horses/display/6f8YmHOk-3M?year=2026"
                },
                "entries": "4",
                "placing": "4",
                "natlPoints": "6.00",
                "zonePoints": "6.00",
                "backNumber": "3442",
                "dressagePercentage": null
              },
              {
                "classCode": "454",
                "classTitle": "454 - Medium Green Pony Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/EzTzNJAL9DE",
                "horse": {
                  "name": "QUEEN ELIZABETH",
                  "usefHorseId": "6031861",
                  "link": "https://www.usef.org/search/horses/display/6f8YmHOk-3M?year=2026"
                },
                "entries": "4",
                "placing": "4",
                "natlPoints": "6.00",
                "zonePoints": "6.00",
                "backNumber": "3442",
                "dressagePercentage": null
              },
              {
                "classCode": "455",
                "classTitle": "455 - Medium Green Pony Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/CQnTgF8GEtg",
                "horse": {
                  "name": "QUEEN ELIZABETH",
                  "usefHorseId": "6031861",
                  "link": "https://www.usef.org/search/horses/display/6f8YmHOk-3M?year=2026"
                },
                "entries": "4",
                "placing": "3",
                "natlPoints": "8.00",
                "zonePoints": "8.00",
                "backNumber": "3442",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3011",
            "sectionName": "GREEN PONY HUNTER CLASSIC",
            "classes": [
              {
                "classCode": "905",
                "classTitle": "905 - $500 Green Pony Hunter Classic",
                "classUrl": "https://www.usef.org/search/competitions/class/yXZXP_H6Q_U",
                "horse": {
                  "name": "QUEEN ELIZABETH",
                  "usefHorseId": "6031861",
                  "link": "https://www.usef.org/search/horses/display/6f8YmHOk-3M?year=2026"
                },
                "entries": "8",
                "placing": "8",
                "natlPoints": "17.50",
                "zonePoints": "12.50",
                "backNumber": "3442",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3100",
            "sectionName": "MISC. HUNTER (No points earned)",
            "classes": [
              {
                "classCode": "401",
                "classTitle": "401 - Schooling Pony",
                "classUrl": "https://www.usef.org/search/competitions/class/kn76jQEZOmg",
                "horse": {
                  "name": "QUEEN ELIZABETH",
                  "usefHorseId": "6031861",
                  "link": "https://www.usef.org/search/horses/display/6f8YmHOk-3M?year=2026"
                },
                "entries": "12",
                "placing": "6",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "3442",
                "dressagePercentage": null
              },
              {
                "classCode": "651",
                "classTitle": "651 - Warm Up Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/JE0sm-Zp6eo",
                "horse": {
                  "name": "NAVIGATOR",
                  "usefHorseId": "5805986",
                  "link": "https://www.usef.org/search/horses/display/b6b6Wpbu1MA?year=2026"
                },
                "entries": "9",
                "placing": "5",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "3214",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "247834",
        "competitionName": "HOLIDAY FESTIVAL I (247834)",
        "id": "247834",
        "name": "HOLIDAY FESTIVAL I (247834)",
        "startDate": "12/10/2025",
        "endDate": "12/10/2025",
        "start": "2025-12-10T05:00:00.000Z",
        "end": "2025-12-10T05:00:00.000Z",
        "year": 2025,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/zbOiZclZPtE",
        "sections": [
          {
            "sectionId": "3199",
            "sectionName": "Misc Equitation",
            "classes": [
              {
                "classCode": "570",
                "classTitle": "570 - ASPCA Maclay",
                "classUrl": "https://www.usef.org/search/competitions/class/OuiGf3odDMg",
                "horse": {
                  "name": "A LA MINUTE Z",
                  "usefHorseId": "5968963",
                  "link": "https://www.usef.org/search/horses/display/chuJXup9_d0?year=2026"
                },
                "entries": "14",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1830",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "6349",
            "sectionName": "USHJA 3'3 JUMPING SEAT MEDAL",
            "classes": [
              {
                "classCode": "545",
                "classTitle": "545 - Marshall + Sterling/USHJA 3'3 Jumper Seat Medal",
                "classUrl": "https://www.usef.org/search/competitions/class/twGBQgwQ7Ik",
                "horse": {
                  "name": "A LA MINUTE Z",
                  "usefHorseId": "5968963",
                  "link": "https://www.usef.org/search/horses/display/chuJXup9_d0?year=2026"
                },
                "entries": "7",
                "placing": "6",
                "natlPoints": "2.00",
                "zonePoints": "0.00",
                "backNumber": "1830",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "343029",
        "competitionName": "ESP YEAR END HUNTER & EQUITATION AWARDS SHOW (343029)",
        "id": "343029",
        "name": "ESP YEAR END HUNTER & EQUITATION AWARDS SHOW (343029)",
        "startDate": "12/5/2025",
        "endDate": "12/7/2025",
        "start": "2025-12-05T05:00:00.000Z",
        "end": "2025-12-07T05:00:00.000Z",
        "year": 2025,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/BexbOKkDQdk",
        "sections": [
          {
            "sectionId": "2003",
            "sectionName": "PERFORMANCE HUNTER - 3'3\\"",
            "classes": [
              {
                "classCode": "387",
                "classTitle": "387 - Performance Hunter 3'3",
                "classUrl": "https://www.usef.org/search/competitions/class/MJTe2fHcjR4",
                "horse": {
                  "name": "A LA MINUTE Z",
                  "usefHorseId": "5968963",
                  "link": "https://www.usef.org/search/horses/display/chuJXup9_d0?year=2026"
                },
                "entries": "14",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1830",
                "dressagePercentage": null
              },
              {
                "classCode": "388",
                "classTitle": "388 - Performance Hunter 3'3",
                "classUrl": "https://www.usef.org/search/competitions/class/iGNozI05CBw",
                "horse": {
                  "name": "A LA MINUTE Z",
                  "usefHorseId": "5968963",
                  "link": "https://www.usef.org/search/horses/display/chuJXup9_d0?year=2026"
                },
                "entries": "13",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1830",
                "dressagePercentage": null
              },
              {
                "classCode": "389",
                "classTitle": "389 - Performance Hunter 3'3",
                "classUrl": "https://www.usef.org/search/competitions/class/hMS8ksnFP54",
                "horse": {
                  "name": "A LA MINUTE Z",
                  "usefHorseId": "5968963",
                  "link": "https://www.usef.org/search/horses/display/chuJXup9_d0?year=2026"
                },
                "entries": "3",
                "placing": "3",
                "natlPoints": "8.00",
                "zonePoints": "8.00",
                "backNumber": "1830",
                "dressagePercentage": null
              },
              {
                "classCode": "390",
                "classTitle": "390 - Performance Hunter 3'3",
                "classUrl": "https://www.usef.org/search/competitions/class/sGtsLpIzWkc",
                "horse": {
                  "name": "A LA MINUTE Z",
                  "usefHorseId": "5968963",
                  "link": "https://www.usef.org/search/horses/display/chuJXup9_d0?year=2026"
                },
                "entries": "3",
                "placing": "2",
                "natlPoints": "10.00",
                "zonePoints": "10.00",
                "backNumber": "1830",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3100",
            "sectionName": "MISC. HUNTER (No points earned)",
            "classes": [
              {
                "classCode": "401",
                "classTitle": "401 - Schooling Pony",
                "classUrl": "https://www.usef.org/search/competitions/class/CogDqge_tkw",
                "horse": {
                  "name": "FORT KNOX",
                  "usefHorseId": "6072529",
                  "link": "https://www.usef.org/search/horses/display/eQOXBC-5Pu4?year=2026"
                },
                "entries": "8",
                "placing": "7",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1828",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3199",
            "sectionName": "Misc Equitation",
            "classes": [
              {
                "classCode": "570",
                "classTitle": "570 - ASPCA Maclay",
                "classUrl": "https://www.usef.org/search/competitions/class/5cPRmopkzbU",
                "horse": {
                  "name": "A LA MINUTE Z",
                  "usefHorseId": "5968963",
                  "link": "https://www.usef.org/search/horses/display/chuJXup9_d0?year=2026"
                },
                "entries": "18",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1830",
                "dressagePercentage": null
              },
              {
                "classCode": "580",
                "classTitle": "580 - WIHS Hunter Phase",
                "classUrl": "https://www.usef.org/search/competitions/class/HxEjjh7iluY",
                "horse": {
                  "name": "A LA MINUTE Z",
                  "usefHorseId": "5968963",
                  "link": "https://www.usef.org/search/horses/display/chuJXup9_d0?year=2026"
                },
                "entries": "15",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1830",
                "dressagePercentage": null
              },
              {
                "classCode": "582",
                "classTitle": "582 - WIHS Overall",
                "classUrl": "https://www.usef.org/search/competitions/class/qX6rQbK1gt8",
                "horse": {
                  "name": "A LA MINUTE Z",
                  "usefHorseId": "5968963",
                  "link": "https://www.usef.org/search/horses/display/chuJXup9_d0?year=2026"
                },
                "entries": "15",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1830",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "6100",
            "sectionName": "DOVER SADDLERY/USEF HUNTER SEAT MEDAL",
            "classes": [
              {
                "classCode": "550",
                "classTitle": "550 - Dover Saddlery/USEF Hunter Seat Medal",
                "classUrl": "https://www.usef.org/search/competitions/class/YDi1llHIyjc",
                "horse": {
                  "name": "A LA MINUTE Z",
                  "usefHorseId": "5968963",
                  "link": "https://www.usef.org/search/horses/display/chuJXup9_d0?year=2026"
                },
                "entries": "16",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1830",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "269388",
        "competitionName": "HOLIDAY AND HORSES (269388)",
        "id": "269388",
        "name": "HOLIDAY AND HORSES (269388)",
        "startDate": "11/26/2025",
        "endDate": "11/30/2025",
        "start": "2025-11-26T05:00:00.000Z",
        "end": "2025-11-30T05:00:00.000Z",
        "year": 2025,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/HKh_-wmVC8o",
        "sections": [
          {
            "sectionId": "3100",
            "sectionName": "MISC. HUNTER (No points earned)",
            "classes": [
              {
                "classCode": "401",
                "classTitle": "401 - Schooling Pony",
                "classUrl": "https://www.usef.org/search/competitions/class/HvmWxFqiYL0",
                "horse": {
                  "name": "TROUBLESHOOT",
                  "usefHorseId": "5859450",
                  "link": "https://www.usef.org/search/horses/display/Q4kCSFHIKFs?year=2025"
                },
                "entries": "13",
                "placing": "8",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1247",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "900",
        "competitionName": "SFHJA 75TH ANNUAL CHARITY (900)",
        "id": "900",
        "name": "SFHJA 75TH ANNUAL CHARITY (900)",
        "startDate": "11/19/2025",
        "endDate": "11/23/2025",
        "start": "2025-11-19T05:00:00.000Z",
        "end": "2025-11-23T05:00:00.000Z",
        "year": 2025,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/i6IHLukSeBk",
        "sections": [
          {
            "sectionId": "3100",
            "sectionName": "MISC. HUNTER (No points earned)",
            "classes": [
              {
                "classCode": "669",
                "classTitle": "669 - Warm Up",
                "classUrl": "https://www.usef.org/search/competitions/class/bg6Lbwfkmnc",
                "horse": {
                  "name": "TROUBLESHOOT",
                  "usefHorseId": "5859450",
                  "link": "https://www.usef.org/search/horses/display/Q4kCSFHIKFs?year=2025"
                },
                "entries": "5",
                "placing": "5",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "956",
                "dressagePercentage": null
              },
              {
                "classCode": "670",
                "classTitle": "670 - Warm Up",
                "classUrl": "https://www.usef.org/search/competitions/class/4rAnqPEBBuM",
                "horse": {
                  "name": "FORT KNOX",
                  "usefHorseId": "6072529",
                  "link": "https://www.usef.org/search/horses/display/eQOXBC-5Pu4?year=2025"
                },
                "entries": "2",
                "placing": "2",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "954",
                "dressagePercentage": null
              },
              {
                "classCode": "678",
                "classTitle": "678 - Warm Up",
                "classUrl": "https://www.usef.org/search/competitions/class/hkhH_npBc_4",
                "horse": {
                  "name": "FORT KNOX",
                  "usefHorseId": "6072529",
                  "link": "https://www.usef.org/search/horses/display/eQOXBC-5Pu4?year=2025"
                },
                "entries": "4",
                "placing": "2",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "954",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3199",
            "sectionName": "Misc Equitation",
            "classes": [
              {
                "classCode": "525",
                "classTitle": "525 - SFHJA Junior Hunter Seat Medal Final",
                "classUrl": "https://www.usef.org/search/competitions/class/m7WFqQySs2w",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "20",
                "placing": "6",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "963",
                "dressagePercentage": null
              },
              {
                "classCode": "580",
                "classTitle": "580 - WIHS Hunter Phase",
                "classUrl": "https://www.usef.org/search/competitions/class/4fpWhoib8eM",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "15",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "963",
                "dressagePercentage": null
              },
              {
                "classCode": "581",
                "classTitle": "581 - WIHS Jumper Phase",
                "classUrl": "https://www.usef.org/search/competitions/class/_Z0QTT3u-iw",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "12",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "963",
                "dressagePercentage": null
              },
              {
                "classCode": "582",
                "classTitle": "582 - WIHS Overall",
                "classUrl": "https://www.usef.org/search/competitions/class/TJ6jHHMTn0Y",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "12",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "963",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3800",
            "sectionName": "MISC JUMPER",
            "classes": [
              {
                "classCode": "777",
                "classTitle": "777 - Training Jumper 1.0m II2d",
                "classUrl": "https://www.usef.org/search/competitions/class/AoFkc-UK2l4",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "68",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "963",
                "dressagePercentage": null
              },
              {
                "classCode": "778",
                "classTitle": "778 - Training Jumper 1.0m II2d CALI",
                "classUrl": "https://www.usef.org/search/competitions/class/MCvS7gcOaG0",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "80",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "963",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "6350",
            "sectionName": "USHJA 3'3\\" JUNIOR JUMPING SEAT MEDAL",
            "classes": [
              {
                "classCode": "545",
                "classTitle": "545 - USHJA 3'3\\" Jumper Seat Junior Medal",
                "classUrl": "https://www.usef.org/search/competitions/class/JptaMp42Y9s",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "21",
                "placing": "7",
                "natlPoints": "2.00",
                "zonePoints": "0.00",
                "backNumber": "963",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "343747",
        "competitionName": "ESP PRE CHARITY HUNTER & EQUITATION (343747)",
        "id": "343747",
        "name": "ESP PRE CHARITY HUNTER & EQUITATION (343747)",
        "startDate": "11/14/2025",
        "endDate": "11/16/2025",
        "start": "2025-11-14T05:00:00.000Z",
        "end": "2025-11-16T05:00:00.000Z",
        "year": 2025,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/4r9F1QLCJZo",
        "sections": [
          {
            "sectionId": "3100",
            "sectionName": "MISC. HUNTER (No points earned)",
            "classes": [
              {
                "classCode": "656",
                "classTitle": "656 - Warm Up Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/Jq4howWE7_g",
                "horse": {
                  "name": "FORT KNOX",
                  "usefHorseId": "6072529",
                  "link": "https://www.usef.org/search/horses/display/eQOXBC-5Pu4?year=2025"
                },
                "entries": "24",
                "placing": "5",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1261",
                "dressagePercentage": null
              },
              {
                "classCode": "658",
                "classTitle": "658 - Warm Up Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/aEQo2NYMP0I",
                "horse": {
                  "name": "CHARMING BOY O",
                  "usefHorseId": "5615354",
                  "link": "https://www.usef.org/search/horses/display/_LpmjJWklsg?year=2025"
                },
                "entries": "10",
                "placing": "3",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1258",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "7129",
        "competitionName": "EQUESTRIAN SPORT PRODUCTIONS, LLC. NOVEMBER I (7129)",
        "id": "7129",
        "name": "EQUESTRIAN SPORT PRODUCTIONS, LLC. NOVEMBER I (7129)",
        "startDate": "11/7/2025",
        "endDate": "11/9/2025",
        "start": "2025-11-07T05:00:00.000Z",
        "end": "2025-11-09T05:00:00.000Z",
        "year": 2025,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/lHuL3pU8gIg",
        "sections": [
          {
            "sectionId": "3100",
            "sectionName": "MISC. HUNTER (No points earned)",
            "classes": [
              {
                "classCode": "656",
                "classTitle": "656 - Warm Up Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/LT7KVlapDYg",
                "horse": {
                  "name": "FORT KNOX",
                  "usefHorseId": "6072529",
                  "link": "https://www.usef.org/search/horses/display/eQOXBC-5Pu4?year=2025"
                },
                "entries": "15",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1261",
                "dressagePercentage": null
              },
              {
                "classCode": "656",
                "classTitle": "656 - Warm Up Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/LT7KVlapDYg",
                "horse": {
                  "name": "NAVIGATOR",
                  "usefHorseId": "5805986",
                  "link": "https://www.usef.org/search/horses/display/b6b6Wpbu1MA?year=2025"
                },
                "entries": "15",
                "placing": "1",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "471",
                "dressagePercentage": null
              },
              {
                "classCode": "656",
                "classTitle": "656 - Warm Up Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/LT7KVlapDYg",
                "horse": {
                  "name": "HALO",
                  "usefHorseId": "5612802",
                  "link": "https://www.usef.org/search/horses/display/gkszPrnxu3M?year=2025"
                },
                "entries": "15",
                "placing": "2",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "472",
                "dressagePercentage": null
              },
              {
                "classCode": "656",
                "classTitle": "656 - Warm Up Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/LT7KVlapDYg",
                "horse": {
                  "name": "CHARMING BOY O",
                  "usefHorseId": "5615354",
                  "link": "https://www.usef.org/search/horses/display/_LpmjJWklsg?year=2025"
                },
                "entries": "15",
                "placing": "7",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1258",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "335839",
        "competitionName": "NATIONAL HORSE SHOW (335839)",
        "id": "335839",
        "name": "NATIONAL HORSE SHOW (335839)",
        "startDate": "10/22/2025",
        "endDate": "10/26/2025",
        "start": "2025-10-22T04:00:00.000Z",
        "end": "2025-10-26T04:00:00.000Z",
        "year": 2025,
        "state": "KY",
        "zone": "5",
        "viewUrl": "https://www.usef.org/search/competitions/display/QcmtYwGApaQ",
        "sections": [
          {
            "sectionId": "3199",
            "sectionName": "Misc Equitation",
            "classes": [
              {
                "classCode": "1",
                "classTitle": "1 - UNDER 14 EQ FLAT",
                "classUrl": "https://www.usef.org/search/competitions/class/lzv4xQtlsY0",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "19",
                "placing": "5",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "813",
                "dressagePercentage": null
              },
              {
                "classCode": "2",
                "classTitle": "2 - UNDER 14 EQ O/F",
                "classUrl": "https://www.usef.org/search/competitions/class/Ew_ZwHtj0QE",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "19",
                "placing": "4",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "813",
                "dressagePercentage": null,
                "clipmyhorse_url": "https://www.clipmyhorse.tv/en_EU/ondemand/event/17103/competition/402780?start_at=15378549"
              },
              {
                "classCode": "22",
                "classTitle": "22 - HAMEL NHS 3'3\\" EQ CHAMP",
                "classUrl": "https://www.usef.org/search/competitions/class/BGrAJ7IFbG8",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "168",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "813",
                "dressagePercentage": null,
                "clipmyhorse_url": "https://www.clipmyhorse.tv/en_EU/ondemand/event/17103/competition/402800?start_at=15405477"
              },
              {
                "classCode": "3",
                "classTitle": "3 - UNDER 14 EQ O/F",
                "classUrl": "https://www.usef.org/search/competitions/class/uIwiSf1uoeI",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "19",
                "placing": "7",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "813",
                "dressagePercentage": null,
                "clipmyhorse_url": "https://www.clipmyhorse.tv/en_EU/ondemand/event/17103/competition/402781?start_at=15390943"
              }
            ]
          }
        ]
      },
      {
        "competitionId": "6489",
        "competitionName": "EQUESTRIAN SPORT PRODUCTIONS, LLC. FALL \\"A\\" CIRCUIT II (6489)",
        "id": "6489",
        "name": "EQUESTRIAN SPORT PRODUCTIONS, LLC. FALL \\"A\\" CIRCUIT II (6489)",
        "startDate": "10/16/2025",
        "endDate": "10/19/2025",
        "start": "2025-10-16T04:00:00.000Z",
        "end": "2025-10-19T04:00:00.000Z",
        "year": 2025,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/PNV4_gDm1Rw",
        "sections": [
          {
            "sectionId": "2050",
            "sectionName": "USHJA HUNTER",
            "classes": [
              {
                "classCode": "182",
                "classTitle": "182 - USHJA Hunter 2'/2'3 - FP",
                "classUrl": "https://www.usef.org/search/competitions/class/HW0NzGtwMEM",
                "horse": {
                  "name": "TROUBLESHOOT",
                  "usefHorseId": "5859450",
                  "link": "https://www.usef.org/search/horses/display/Q4kCSFHIKFs?year=2025"
                },
                "entries": "5",
                "placing": "1",
                "natlPoints": "15.00",
                "zonePoints": "15.00",
                "backNumber": "475",
                "dressagePercentage": null
              },
              {
                "classCode": "183",
                "classTitle": "183 - USHJA Hunter 2'/2'3",
                "classUrl": "https://www.usef.org/search/competitions/class/2sbc_nWnlG0",
                "horse": {
                  "name": "TROUBLESHOOT",
                  "usefHorseId": "5859450",
                  "link": "https://www.usef.org/search/horses/display/Q4kCSFHIKFs?year=2025"
                },
                "entries": "4",
                "placing": "4",
                "natlPoints": "6.00",
                "zonePoints": "6.00",
                "backNumber": "475",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3100",
            "sectionName": "MISC. HUNTER (No points earned)",
            "classes": [
              {
                "classCode": "401",
                "classTitle": "401 - Schooling Pony",
                "classUrl": "https://www.usef.org/search/competitions/class/NyMPD9fXMj0",
                "horse": {
                  "name": "AMONG US",
                  "usefHorseId": "5728380",
                  "link": "https://www.usef.org/search/horses/display/yHzUbq6py6M?year=2025"
                },
                "entries": "3",
                "placing": "3",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "469",
                "dressagePercentage": null
              },
              {
                "classCode": "654",
                "classTitle": "654 - Warm Up Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/0-fYzN_HFQs",
                "horse": {
                  "name": "TROUBLESHOOT",
                  "usefHorseId": "5859450",
                  "link": "https://www.usef.org/search/horses/display/Q4kCSFHIKFs?year=2025"
                },
                "entries": "3",
                "placing": "3",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "475",
                "dressagePercentage": null
              },
              {
                "classCode": "656",
                "classTitle": "656 - Warm Up Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/gAKGt6DKLRc",
                "horse": {
                  "name": "TROUBLESHOOT",
                  "usefHorseId": "5859450",
                  "link": "https://www.usef.org/search/horses/display/Q4kCSFHIKFs?year=2025"
                },
                "entries": "7",
                "placing": "1",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "475",
                "dressagePercentage": null
              },
              {
                "classCode": "657",
                "classTitle": "657 - Warm Up Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/12dM1_HspKo",
                "horse": {
                  "name": "NAVIGATOR",
                  "usefHorseId": "5805986",
                  "link": "https://www.usef.org/search/horses/display/b6b6Wpbu1MA?year=2025"
                },
                "entries": "6",
                "placing": "3",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "471",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "279067",
        "competitionName": "CAPITAL CHALLENGE EQUITATION (279067)",
        "id": "279067",
        "name": "CAPITAL CHALLENGE EQUITATION (279067)",
        "startDate": "9/24/2025",
        "endDate": "9/28/2025",
        "start": "2025-09-24T04:00:00.000Z",
        "end": "2025-09-28T04:00:00.000Z",
        "year": 2025,
        "state": "MD",
        "zone": "3",
        "viewUrl": "https://www.usef.org/search/competitions/display/8eHYrN5AQvs",
        "sections": [
          {
            "sectionId": "3102",
            "sectionName": "HUNTER EQUITATION 14&U",
            "classes": [
              {
                "classCode": "144",
                "classTitle": "144 - 13-14 YR OLD EQUITATION O/F  \\"A\\"",
                "classUrl": "https://www.usef.org/search/competitions/class/ctnuqrEY3u0",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "22",
                "placing": "3",
                "natlPoints": "0.00",
                "zonePoints": "10.00",
                "backNumber": "904",
                "dressagePercentage": null,
                "clipmyhorse_url": "https://www.clipmyhorse.tv/en_EU/ondemand/event/16994/competition/396113?start_at=15138952"
              },
              {
                "classCode": "145",
                "classTitle": "145 - 13-14 YR OLD EQUITATION O/F  \\"A\\"",
                "classUrl": "https://www.usef.org/search/competitions/class/0yL-2Sg9LcU",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "21",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "904",
                "dressagePercentage": null,
                "clipmyhorse_url": "https://www.clipmyhorse.tv/en_EU/ondemand/event/16994/competition/396296?start_at=15138911"
              },
              {
                "classCode": "146",
                "classTitle": "146 - 13-14 YR OLD EQUITATION FLAT \\"A\\"",
                "classUrl": "https://www.usef.org/search/competitions/class/rBkQ-5At0JU",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "20",
                "placing": "5",
                "natlPoints": "0.00",
                "zonePoints": "5.00",
                "backNumber": "904",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3199",
            "sectionName": "Misc Equitation",
            "classes": [
              {
                "classCode": "20",
                "classTitle": "20 - USHJA 3'3 JUMPING SEAT MEDAL FINALS",
                "classUrl": "https://www.usef.org/search/competitions/class/4bOkSEAyuiM",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "201",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "904",
                "dressagePercentage": null
              },
              {
                "classCode": "2001",
                "classTitle": "2001 - USHJA 3'3\\" JUMPING SEAT MEDAL FLAT",
                "classUrl": "https://www.usef.org/search/competitions/class/hAsVln4t05s",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "201",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "904",
                "dressagePercentage": null,
                "clipmyhorse_url": "https://www.clipmyhorse.tv/en_EU/ondemand/event/16994/competition/396139?start_at=15127537"
              },
              {
                "classCode": "2002",
                "classTitle": "2002 - USHJA 3'3\\" JUMPING SEAT MEDAL GYMNASTICS",
                "classUrl": "https://www.usef.org/search/competitions/class/7K8Y943eSlc",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "200",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "904",
                "dressagePercentage": null,
                "clipmyhorse_url": "https://www.clipmyhorse.tv/en_EU/ondemand/event/16994/competition/396140?start_at=15137863"
              },
              {
                "classCode": "2003",
                "classTitle": "2003 - USHJA 3'3\\" JUMPING SEAT MEDAL JUMPING",
                "classUrl": "https://www.usef.org/search/competitions/class/KXkN-97-E2c",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "199",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "904",
                "dressagePercentage": null,
                "clipmyhorse_url": "https://www.clipmyhorse.tv/en_EU/ondemand/event/16994/competition/396141?start_at=15155474"
              },
              {
                "classCode": "2016",
                "classTitle": "2016 - USHJA 3'3\\" JUMPING SEAT MEDAL FLAT 6",
                "classUrl": "https://www.usef.org/search/competitions/class/Q7GDsX6nusk",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "12",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "904",
                "dressagePercentage": null
              },
              {
                "classCode": "662",
                "classTitle": "662 - OPEN EQ 3'3 (ONLY JUMP SEAT AND ADULT EQ RIDERS)",
                "classUrl": "https://www.usef.org/search/competitions/class/TRA099cgxZU",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "151",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "904",
                "dressagePercentage": null,
                "clipmyhorse_url": "https://www.clipmyhorse.tv/en_EU/ondemand/event/16994/competition/396369?start_at=15135236"
              }
            ]
          },
          {
            "sectionId": "6349",
            "sectionName": "USHJA 3'3 JUMPING SEAT MEDAL",
            "classes": [
              {
                "classCode": "20030",
                "classTitle": "20030 - USHJA 3'3\\" JUMPING SEAT OVERALL (FINAL)",
                "classUrl": "https://www.usef.org/search/competitions/class/2GAUBEGbYTQ",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "199",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "904",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "2807",
        "competitionName": "EQUESTRIAN SPORT PRODUCTIONS, LLC. FLORIDA STATE FALL (2807)",
        "id": "2807",
        "name": "EQUESTRIAN SPORT PRODUCTIONS, LLC. FLORIDA STATE FALL (2807)",
        "startDate": "9/18/2025",
        "endDate": "9/21/2025",
        "start": "2025-09-18T04:00:00.000Z",
        "end": "2025-09-21T04:00:00.000Z",
        "year": 2025,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/RVjzteXC9dc",
        "sections": [
          {
            "sectionId": "3199",
            "sectionName": "Misc Equitation",
            "classes": [
              {
                "classCode": "570",
                "classTitle": "570 - ASPCA Maclay",
                "classUrl": "https://www.usef.org/search/competitions/class/iW9PR2XwlBI",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "11",
                "placing": "1",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "133",
                "dressagePercentage": null
              },
              {
                "classCode": "830",
                "classTitle": "830 - Region 10 NHSAA/Maclay Regional Championship",
                "classUrl": "https://www.usef.org/search/competitions/class/jA-wX9mnFDE",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "15",
                "placing": "12",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "133",
                "dressagePercentage": null
              },
              {
                "classCode": "850",
                "classTitle": "850 - Hamel Foundation NHS 3'3  Area Championship",
                "classUrl": "https://www.usef.org/search/competitions/class/QvsloOCBRx4",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "20",
                "placing": "5",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "133",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "6100",
            "sectionName": "DOVER SADDLERY/USEF HUNTER SEAT MEDAL",
            "classes": [
              {
                "classCode": "550",
                "classTitle": "550 - Dover Saddlery/USEF Hunter Seat Medal",
                "classUrl": "https://www.usef.org/search/competitions/class/vSIc3TbHDqc",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "10",
                "placing": "6",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "133",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "6110",
            "sectionName": "PLATINUM PERFORMANCE/USEF SHOW JUMPING TALENT SEARCH",
            "classes": [
              {
                "classCode": "590",
                "classTitle": "590 - Platinum Performance/USEF Show Jumping Talent Search 1*",
                "classUrl": "https://www.usef.org/search/competitions/class/uLFtFjmDKuA",
                "horse": {
                  "name": "ODDUR VAN BEAUGAARDE",
                  "usefHorseId": "5782114",
                  "link": "https://www.usef.org/search/horses/display/PcqjirLOqXs?year=2025"
                },
                "entries": "4",
                "placing": "3",
                "natlPoints": "5.00",
                "zonePoints": "0.00",
                "backNumber": "133",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "7179",
        "competitionName": "EQUESTRIAN SPORT PRODUCTIONS, LLC. SPRING 4 (7179)",
        "id": "7179",
        "name": "EQUESTRIAN SPORT PRODUCTIONS, LLC. SPRING 4 (7179)",
        "startDate": "4/30/2026",
        "endDate": "5/3/2026",
        "start": "2026-04-30T04:00:00.000Z",
        "end": "2026-05-03T04:00:00.000Z",
        "year": 2026,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/Bxh-xz8cgqE",
        "sections": [
          {
            "sectionId": "3100",
            "sectionName": "MISC. HUNTER (No points earned)",
            "classes": [
              {
                "classCode": "401",
                "classTitle": "401 - Schooling Pony",
                "classUrl": "https://www.usef.org/search/competitions/class/AGbPn-LyfoU",
                "horse": {
                  "name": "FORT KNOX",
                  "usefHorseId": "6072529",
                  "link": "https://www.usef.org/search/horses/display/eQOXBC-5Pu4?year=2026"
                },
                "entries": "16",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "2815",
                "dressagePercentage": null
              },
              {
                "classCode": "981",
                "classTitle": "981 - Mulligan Class",
                "classUrl": "https://www.usef.org/search/competitions/class/HdFVE73Dlg0",
                "horse": {
                  "name": "SHELBY BLUE PS",
                  "usefHorseId": "6032538",
                  "link": "https://www.usef.org/search/horses/display/V1VFSWnV-dY?year=2026"
                },
                "entries": "3",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "3213",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3199",
            "sectionName": "Misc Equitation",
            "classes": [
              {
                "classCode": "570",
                "classTitle": "570 - ASPCA Maclay",
                "classUrl": "https://www.usef.org/search/competitions/class/zB545si636Q",
                "horse": {
                  "name": "SHELBY BLUE PS",
                  "usefHorseId": "6032538",
                  "link": "https://www.usef.org/search/horses/display/V1VFSWnV-dY?year=2026"
                },
                "entries": "8",
                "placing": "4",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "3213",
                "dressagePercentage": null
              },
              {
                "classCode": "580",
                "classTitle": "580 - WIHS Hunter Phase",
                "classUrl": "https://www.usef.org/search/competitions/class/tjAnxG88RqM",
                "horse": {
                  "name": "SHELBY BLUE PS",
                  "usefHorseId": "6032538",
                  "link": "https://www.usef.org/search/horses/display/V1VFSWnV-dY?year=2026"
                },
                "entries": "7",
                "placing": "6",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "3213",
                "dressagePercentage": null
              },
              {
                "classCode": "582",
                "classTitle": "582 - WIHS Overall",
                "classUrl": "https://www.usef.org/search/competitions/class/kEInxb4ejVk",
                "horse": {
                  "name": "SHELBY BLUE PS",
                  "usefHorseId": "6032538",
                  "link": "https://www.usef.org/search/horses/display/V1VFSWnV-dY?year=2026"
                },
                "entries": "7",
                "placing": "6",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "3213",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3800",
            "sectionName": "MISC JUMPER",
            "classes": [
              {
                "classCode": "780",
                "classTitle": "780 - Training Jumper (1.0m) II2d",
                "classUrl": "https://www.usef.org/search/competitions/class/mplmT7AMVPQ",
                "horse": {
                  "name": "SHELBY BLUE PS",
                  "usefHorseId": "6032538",
                  "link": "https://www.usef.org/search/horses/display/V1VFSWnV-dY?year=2026"
                },
                "entries": "23",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "3213",
                "dressagePercentage": null
              },
              {
                "classCode": "781",
                "classTitle": "781 - Training Jumper (1.0m) II2.1",
                "classUrl": "https://www.usef.org/search/competitions/class/OjxNvILHOSg",
                "horse": {
                  "name": "SHELBY BLUE PS",
                  "usefHorseId": "6032538",
                  "link": "https://www.usef.org/search/horses/display/V1VFSWnV-dY?year=2026"
                },
                "entries": "15",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "3213",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "6100",
            "sectionName": "DOVER SADDLERY/USEF HUNTER SEAT MEDAL",
            "classes": [
              {
                "classCode": "550",
                "classTitle": "550 - Dover Saddlery/USEF Hunter Seat Medal",
                "classUrl": "https://www.usef.org/search/competitions/class/gX9oYTos-WQ",
                "horse": {
                  "name": "SHELBY BLUE PS",
                  "usefHorseId": "6032538",
                  "link": "https://www.usef.org/search/horses/display/V1VFSWnV-dY?year=2026"
                },
                "entries": "7",
                "placing": "3",
                "natlPoints": "6.00",
                "zonePoints": "0.00",
                "backNumber": "3213",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "5028",
        "competitionName": "EQUESTRIAN SPORT PRODUCTIONS, LLC. SPRING 3 (5028)",
        "id": "5028",
        "name": "EQUESTRIAN SPORT PRODUCTIONS, LLC. SPRING 3 (5028)",
        "startDate": "4/15/2026",
        "endDate": "4/19/2026",
        "start": "2026-04-15T04:00:00.000Z",
        "end": "2026-04-19T04:00:00.000Z",
        "year": 2026,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/vjDlXrTaxAs",
        "sections": [
          {
            "sectionId": "3100",
            "sectionName": "MISC. HUNTER (No points earned)",
            "classes": [
              {
                "classCode": "401",
                "classTitle": "401 - Schooling Pony",
                "classUrl": "https://www.usef.org/search/competitions/class/0mCHkH_yqmY",
                "horse": {
                  "name": "FORT KNOX",
                  "usefHorseId": "6072529",
                  "link": "https://www.usef.org/search/horses/display/eQOXBC-5Pu4?year=2026"
                },
                "entries": "22",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "2815",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "233850",
        "competitionName": "EQUESTRIAN SPORT PRODUCTIONS, LLC. SPRING 2 (233850)",
        "id": "233850",
        "name": "EQUESTRIAN SPORT PRODUCTIONS, LLC. SPRING 2 (233850)",
        "startDate": "4/8/2026",
        "endDate": "4/12/2026",
        "start": "2026-04-08T04:00:00.000Z",
        "end": "2026-04-12T04:00:00.000Z",
        "year": 2026,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/S70bUCjX4AE",
        "sections": [
          {
            "sectionId": "3100",
            "sectionName": "MISC. HUNTER (No points earned)",
            "classes": [
              {
                "classCode": "401",
                "classTitle": "401 - Schooling Pony",
                "classUrl": "https://www.usef.org/search/competitions/class/PTNyCJbxHAE",
                "horse": {
                  "name": "FORT KNOX",
                  "usefHorseId": "6072529",
                  "link": "https://www.usef.org/search/horses/display/eQOXBC-5Pu4?year=2026"
                },
                "entries": "19",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "2815",
                "dressagePercentage": null
              },
              {
                "classCode": "402",
                "classTitle": "402 - Schooling Pony",
                "classUrl": "https://www.usef.org/search/competitions/class/rkiJzf0p9qc",
                "horse": {
                  "name": "FORT KNOX",
                  "usefHorseId": "6072529",
                  "link": "https://www.usef.org/search/horses/display/eQOXBC-5Pu4?year=2026"
                },
                "entries": "6",
                "placing": "3",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "2815",
                "dressagePercentage": null
              },
              {
                "classCode": "654",
                "classTitle": "654 - Warm Up Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/q5RN1VPz9v4",
                "horse": {
                  "name": "CHARMING BOY O",
                  "usefHorseId": "5615354",
                  "link": "https://www.usef.org/search/horses/display/_LpmjJWklsg?year=2026"
                },
                "entries": "11",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "2813",
                "dressagePercentage": null
              },
              {
                "classCode": "656",
                "classTitle": "656 - Warm Up Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/uYHRuYOPe8E",
                "horse": {
                  "name": "CARRY AWAY",
                  "usefHorseId": "5383606",
                  "link": "https://www.usef.org/search/horses/display/c21Mpgioik0?year=2026"
                },
                "entries": "7",
                "placing": "1",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "2810",
                "dressagePercentage": null
              },
              {
                "classCode": "656",
                "classTitle": "656 - Warm Up Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/uYHRuYOPe8E",
                "horse": {
                  "name": "CHARMING BOY O",
                  "usefHorseId": "5615354",
                  "link": "https://www.usef.org/search/horses/display/_LpmjJWklsg?year=2026"
                },
                "entries": "7",
                "placing": "3",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "2813",
                "dressagePercentage": null
              },
              {
                "classCode": "658",
                "classTitle": "658 - Warm Up Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/J7tEtSuWLfE",
                "horse": {
                  "name": "CHARMING BOY O",
                  "usefHorseId": "5615354",
                  "link": "https://www.usef.org/search/horses/display/_LpmjJWklsg?year=2026"
                },
                "entries": "22",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "2813",
                "dressagePercentage": null
              },
              {
                "classCode": "659",
                "classTitle": "659 - Warm Up Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/mKZKS0tW96k",
                "horse": {
                  "name": "CHARMING BOY O",
                  "usefHorseId": "5615354",
                  "link": "https://www.usef.org/search/horses/display/_LpmjJWklsg?year=2026"
                },
                "entries": "14",
                "placing": "6",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "2813",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "6542",
        "competitionName": "WEF 12 EQUESTRIAN SPORT PRODUCTIONS, LLC (6542)",
        "id": "6542",
        "name": "WEF 12 EQUESTRIAN SPORT PRODUCTIONS, LLC (6542)",
        "startDate": "3/24/2026",
        "endDate": "3/29/2026",
        "start": "2026-03-24T04:00:00.000Z",
        "end": "2026-03-29T04:00:00.000Z",
        "year": 2026,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/4BY0M_IOvPA",
        "sections": [
          {
            "sectionId": "2052",
            "sectionName": "USHJA HUNTER 2'3\\"",
            "classes": [
              {
                "classCode": "2129",
                "classTitle": "2129 - USHJA Hunter 2'3",
                "classUrl": "https://www.usef.org/search/competitions/class/IBSj4ucMZXM",
                "horse": {
                  "name": "FORT KNOX",
                  "usefHorseId": "6072529",
                  "link": "https://www.usef.org/search/horses/display/eQOXBC-5Pu4?year=2026"
                },
                "entries": "18",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1067",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "2604",
            "sectionName": "GREEN PONY HUNTER-SMALL",
            "classes": [
              {
                "classCode": "2947",
                "classTitle": "2947 - $400 Small Green Pony Hunter - FP",
                "classUrl": "https://www.usef.org/search/competitions/class/zgVEB5e60ug",
                "horse": {
                  "name": "FORT KNOX",
                  "usefHorseId": "6072529",
                  "link": "https://www.usef.org/search/horses/display/eQOXBC-5Pu4?year=2026"
                },
                "entries": "7",
                "placing": "6",
                "natlPoints": "6.00",
                "zonePoints": "6.00",
                "backNumber": "1067",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "6488",
        "competitionName": "WEF 11 (6488)",
        "id": "6488",
        "name": "WEF 11 (6488)",
        "startDate": "3/17/2026",
        "endDate": "3/22/2026",
        "start": "2026-03-17T04:00:00.000Z",
        "end": "2026-03-22T04:00:00.000Z",
        "year": 2026,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/7nd3XKiVizw",
        "sections": [
          {
            "sectionId": "2604",
            "sectionName": "GREEN PONY HUNTER-SMALL",
            "classes": [
              {
                "classCode": "2947",
                "classTitle": "2947 - $400 Small Green Pony Hunter - FP",
                "classUrl": "https://www.usef.org/search/competitions/class/NOEp5KFZSIg",
                "horse": {
                  "name": "FORT KNOX",
                  "usefHorseId": "6072529",
                  "link": "https://www.usef.org/search/horses/display/eQOXBC-5Pu4?year=2026"
                },
                "entries": "7",
                "placing": "5",
                "natlPoints": "7.00",
                "zonePoints": "7.00",
                "backNumber": "1067",
                "dressagePercentage": null
              },
              {
                "classCode": "2949",
                "classTitle": "2949 - $400 Small Green Pony Hunter",
                "classUrl": "https://www.usef.org/search/competitions/class/YqBAXm8rPso",
                "horse": {
                  "name": "FORT KNOX",
                  "usefHorseId": "6072529",
                  "link": "https://www.usef.org/search/horses/display/eQOXBC-5Pu4?year=2026"
                },
                "entries": "7",
                "placing": "4",
                "natlPoints": "8.00",
                "zonePoints": "8.00",
                "backNumber": "1067",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "3372",
        "competitionName": "WEF 10 (3372)",
        "id": "3372",
        "name": "WEF 10 (3372)",
        "startDate": "3/11/2026",
        "endDate": "3/15/2026",
        "start": "2026-03-11T04:00:00.000Z",
        "end": "2026-03-15T04:00:00.000Z",
        "year": 2026,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/3w8HoBU5wzE",
        "sections": [
          {
            "sectionId": "3199",
            "sectionName": "Misc Equitation",
            "classes": [
              {
                "classCode": "3036",
                "classTitle": "3036 - Hamel Foundation NHS 3'3 Medal Sec. A",
                "classUrl": "https://www.usef.org/search/competitions/class/umieE6bQAJ0",
                "horse": {
                  "name": "COMDINUS VAN BEEK Z",
                  "usefHorseId": "5804820",
                  "link": "https://www.usef.org/search/horses/display/Z_Bc76CWq9A?year=2026"
                },
                "entries": "21",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "3998",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3800",
            "sectionName": "MISC JUMPER",
            "classes": [
              {
                "classCode": "1111",
                "classTitle": "1111 - .90m Low Child/Adult Amateur Training Jumper 39 & Under II2d",
                "classUrl": "https://www.usef.org/search/competitions/class/sX5Wz8OEKro",
                "horse": {
                  "name": "OWIN",
                  "usefHorseId": "6099035",
                  "link": "https://www.usef.org/search/horses/display/_2YoHI9nhPc?year=2026"
                },
                "entries": "39",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "6446",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "139",
        "competitionName": "WEF 9 (139)",
        "id": "139",
        "name": "WEF 9 (139)",
        "startDate": "3/3/2026",
        "endDate": "3/8/2026",
        "start": "2026-03-03T05:00:00.000Z",
        "end": "2026-03-08T05:00:00.000Z",
        "year": 2026,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/gdZQYwPdcgk",
        "sections": [
          {
            "sectionId": "2502",
            "sectionName": "PONY HUNTER-MEDIUM",
            "classes": [
              {
                "classCode": "2917A",
                "classTitle": "2917A - $630 Medium Pony Hunter (Cali Split) - FP",
                "classUrl": "https://www.usef.org/search/competitions/class/rFIZ8QUzQsQ",
                "horse": {
                  "name": "PUPPY LOVE",
                  "usefHorseId": "5839111",
                  "link": "https://www.usef.org/search/horses/display/tlZz1vKqfNI?year=2026"
                },
                "entries": "20",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1084",
                "dressagePercentage": null
              },
              {
                "classCode": "2918A",
                "classTitle": "2918A - $500 Medium Pony Hunter (Cali Split)",
                "classUrl": "https://www.usef.org/search/competitions/class/f2g0hHW__30",
                "horse": {
                  "name": "PUPPY LOVE",
                  "usefHorseId": "5839111",
                  "link": "https://www.usef.org/search/horses/display/tlZz1vKqfNI?year=2026"
                },
                "entries": "20",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1084",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3199",
            "sectionName": "Misc Equitation",
            "classes": [
              {
                "classCode": "3075",
                "classTitle": "3075 - SFHJA Junior Hunter Seat Medal 14 & Under (Flat Phase)",
                "classUrl": "https://www.usef.org/search/competitions/class/Eb__Ag4mFS8",
                "horse": {
                  "name": "COMDINUS VAN BEEK Z",
                  "usefHorseId": "5804820",
                  "link": "https://www.usef.org/search/horses/display/Z_Bc76CWq9A?year=2026"
                },
                "entries": "12",
                "placing": "4",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "3998",
                "dressagePercentage": null
              },
              {
                "classCode": "3080",
                "classTitle": "3080 - THIS Children's Medal 14 & Under",
                "classUrl": "https://www.usef.org/search/competitions/class/oiegNNpIfO8",
                "horse": {
                  "name": "COMDINUS VAN BEEK Z",
                  "usefHorseId": "5804820",
                  "link": "https://www.usef.org/search/horses/display/Z_Bc76CWq9A?year=2026"
                },
                "entries": "37",
                "placing": "4",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "3998",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "6350",
            "sectionName": "USHJA 3'3\\" JUNIOR JUMPING SEAT MEDAL",
            "classes": [
              {
                "classCode": "3035",
                "classTitle": "3035 - Marshall + Sterling USHJA 3'3 Junior Jumping Seat Medal Sec A",
                "classUrl": "https://www.usef.org/search/competitions/class/t3ylsS218aI",
                "horse": {
                  "name": "COMDINUS VAN BEEK Z",
                  "usefHorseId": "5804820",
                  "link": "https://www.usef.org/search/horses/display/Z_Bc76CWq9A?year=2026"
                },
                "entries": "25",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "3998",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "3122",
        "competitionName": "WEF 8  (3122)",
        "id": "3122",
        "name": "WEF 8  (3122)",
        "startDate": "2/24/2026",
        "endDate": "3/1/2026",
        "start": "2026-02-24T05:00:00.000Z",
        "end": "2026-03-01T05:00:00.000Z",
        "year": 2026,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/QrcEvNvq01Q",
        "sections": [
          {
            "sectionId": "2053",
            "sectionName": "USHJA HUNTER 2'6\\"",
            "classes": [
              {
                "classCode": "4019B",
                "classTitle": "4019B - USHJA Hunter 2'6 (Cali Split)",
                "classUrl": "https://www.usef.org/search/competitions/class/A0JLR4OCNzs",
                "horse": {
                  "name": "CHARMING BOY O",
                  "usefHorseId": "5615354",
                  "link": "https://www.usef.org/search/horses/display/_LpmjJWklsg?year=2026"
                },
                "entries": "19",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "1063",
                "dressagePercentage": null
              }
            ]
          }
        ]
      },
      {
        "competitionId": "1918",
        "competitionName": "WEF 7  (1918)",
        "id": "1918",
        "name": "WEF 7  (1918)",
        "startDate": "2/17/2026",
        "endDate": "2/22/2026",
        "start": "2026-02-17T05:00:00.000Z",
        "end": "2026-02-22T05:00:00.000Z",
        "year": 2026,
        "state": "FL",
        "zone": "4",
        "viewUrl": "https://www.usef.org/search/competitions/display/iLa6qi8D1oo",
        "sections": [
          {
            "sectionId": "2052",
            "sectionName": "USHJA HUNTER 2'3\\"",
            "classes": [
              {
                "classCode": "2129",
                "classTitle": "2129 - USHJA Hunter 2'3",
                "classUrl": "https://www.usef.org/search/competitions/class/V-2s_9MUNso",
                "horse": {
                  "name": "PUPPY LOVE",
                  "usefHorseId": "5839111",
                  "link": "https://www.usef.org/search/horses/display/tlZz1vKqfNI?year=2026"
                },
                "entries": "16",
                "placing": "8",
                "natlPoints": "10.00",
                "zonePoints": "10.00",
                "backNumber": "1084",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3199",
            "sectionName": "Misc Equitation",
            "classes": [
              {
                "classCode": "3036",
                "classTitle": "3036 - Hamel Foundation NHS 3'3 Medal Sec. A",
                "classUrl": "https://www.usef.org/search/competitions/class/lByWxW8Peoo",
                "horse": {
                  "name": "OWIN",
                  "usefHorseId": "6099035",
                  "link": "https://www.usef.org/search/horses/display/_2YoHI9nhPc?year=2026"
                },
                "entries": "24",
                "placing": "3",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "6446",
                "dressagePercentage": null
              }
            ]
          },
          {
            "sectionId": "3800",
            "sectionName": "MISC JUMPER",
            "classes": [
              {
                "classCode": "1111",
                "classTitle": "1111 - .90m Low Child/Adult Amateur Training Jumper 39 & Under II2d",
                "classUrl": "https://www.usef.org/search/competitions/class/fwU_bNcCIJs",
                "horse": {
                  "name": "OWIN",
                  "usefHorseId": "6099035",
                  "link": "https://www.usef.org/search/horses/display/_2YoHI9nhPc?year=2026"
                },
                "entries": "33",
                "placing": "DNP",
                "natlPoints": "0.00",
                "zonePoints": "0.00",
                "backNumber": "6446",
                "dressagePercentage": null
              }
            ]
          }
        ]
      }
    ],
    "usefNumber": "5550974",
    "horseId": "",
    "videosFetched": true,
    "dataMode": "person",
    "personName": "LAINEY POSA",
    "dataLoadedAt": 1779137493303
  },
  "version": 0
}`;
function GET() {
  return new Response(historyJson, {
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "public, max-age=60"
    }
  });
}
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  GET
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page
};
