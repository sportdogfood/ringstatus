globalThis.process ??= {};
globalThis.process.env ??= {};
import { w } from "./chunks/worker-entry_DfrWfVDm.mjs";
import "cloudflare:workers";
export {
  w as default
};
